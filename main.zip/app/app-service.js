var __maAppData=__maAppData||{};
var __maRoute=__maRoute||"";
var __layer__='service';
var __maAppCode__=__maAppCode__||{};
var global=global||{};
var __MAML_GLOBAL__=__MAML_GLOBAL__||{entrys:{},defines:{},modules:{},sjs_init:false}; 
var Component=Component||function(){};


/* maml-transpiler v23.3.0 2023-03-29 16:31:41 */
window.__maml_transpiler_version__='v23.3.0'
var $gmac,$gaic={}
$gma=function(path,global){
  if(typeof global==='undefined')global={};
  function _ac(parent,child){if(typeof(child)!='undefined')parent.children.push(child);} // appendChild
  function _cvn(key){ // createVirtualNode
    if(typeof(key)!='undefined')return {tag:'virtual','maKey':key,children:[]};
    return {tag:'virtual',children:[]};
  }
  function _ctn(tag){ // createTagNode
    $gmac++;
    if($gmac>=16000) throw 'Dom count exceeds maximum 16000.';
    return {tag:tag.substr(0,3)=='ma-'?tag:'ma-'+tag,attr:{},children:[],n:[]}
  }
  function _rtw(msg){console.warn("[MAML runtime warn][$gma] "+msg)} // runtimeWarn
  $gmal={warn:console.warn,info:console.log,error:console.error}
  function $gmah(){
    function fn(){}
    fn.prototype={
      hn:function(obj){ // object has new value
        if(typeof(obj)=='object'){
          var cnt=0,any=false;
          for(var x in obj){
            any|=x==='__value__';
            cnt++;
            if(cnt>2)break;
          }
          return cnt==2&&any&&obj.hasOwnProperty('__maspec__');
        }
        return false;
      },
      nh:function(obj,special){ // new has new value object
        return {__value__:obj,__maspec__:special?special:true}
      },
      rv:function(obj){ // readValue
        return this.hn(obj)?this.rv(obj.__value__):obj;
      }
    }
    return new fn;
  }
  mah=$gmah();
  function $gstack(s){
    var t=s.split('\n '+' '+' '+' ');
    for(var i=0;i<t.length;++i){
      if(0==i) continue;
      if(")"===t[i][t[i].length-1])
      t[i]=t[i].replace(/\s\(.*\)$/,"");
      else t[i]="at anonymous function";
    }
    return t.join('\n '+' '+' '+' ');
  }
  function $gdc(o,p,r){ // deep copy
    o=mah.rv(o);
    if(o===null||o===undefined) return o;
    if(o.constructor===String||o.constructor===Boolean||o.constructor===Number) return o;
    if(o.constructor===Object){
      var copy={};
      for(var key in o){
        if(o.hasOwnProperty(key))copy[undefined===p?key.substring(4):p+key]=$gdc(o[key],p,r);
      }
      return copy;
    }
    if(o.constructor===Date){
      var copy=new Date();
      copy.setTime(o.getTime());
      return copy;
    }
    if(o.constructor===Array){
      var copy=[];
      for(var index=0;index<o.length;index++)copy.push($gdc(o[index],p,r));
      return copy;
    }
    if(r&&o.constructor===Function){
      if (r==1)return $gdc(o(),undefined,2);
      if (r==2)return o;
    }
    if(o.constructor===RegExp){
      var m="";
      if(o.global)m+="g";
      if(o.ignoreCase)m+="i";
      if(o.multiline)m+="m";
      return new RegExp(o.source,m);
    }
    return null;
  }
  function $gmart(should_pass_type_info){
    function arithmeticEval(ops,e,s,g,o){
      var rop=ops[0][1],_f=false;
      var _a,_b,_c,_d,_aa,_bb;
      switch(rop){
        case '?:':
          _a=rev(ops[1],e,s,g,o,_f);
          _c=should_pass_type_info&&mah.hn(_a);
          _d=mah.rv(_a)?rev(ops[2],e,s,g,o,_f):rev(ops[3],e,s,g,o,_f);
          _d=_c&&!mah.hn(_d)?mah.nh(_d,'c'):_d;
          return _d;
        case '&&':
          _a=rev(ops[1],e,s,g,o,_f);
          _c=should_pass_type_info&&mah.hn(_a);
          _d=mah.rv(_a)?rev(ops[2],e,s,g,o,_f):mah.rv(_a);
          _d=_c&&!mah.hn(_d)?mah.nh(_d,'c'):_d;
          return _d;
        case '||':
          _a=rev(ops[1],e,s,g,o,_f);
          _c=should_pass_type_info&&mah.hn(_a);
          _d=mah.rv(_a)?mah.rv(_a):rev(ops[2],e,s,g,o,_f);
          _d=_c&&!mah.hn(_d)?mah.nh(_d,'c'):_d;
          return _d;
        case '+':case '*':case '/':case '%':case '|':case '^':case '&':case '===':case '==':case '!=':case '!==':case '>=':case '<=':case '>':case '<':case '<<':case '>>':
          _a=rev(ops[1],e,s,g,o,_f);
          _b=rev(ops[2],e,s,g,o,_f);
          _c=should_pass_type_info&&(mah.hn(_a)||mah.hn(_b));
          switch(rop){
            case '+':
              _d=mah.rv(_a)+mah.rv(_b);
              break;
            case '*':
              _d=mah.rv(_a)*mah.rv(_b);
              break;
            case '/':
              _d=mah.rv(_a)/mah.rv(_b);
              break;
            case '%':
              _d=mah.rv(_a)%mah.rv(_b);
              break;
            case '|':
              _d=mah.rv(_a)|mah.rv(_b);
              break;
            case '^':
              _d=mah.rv(_a)^mah.rv(_b);
              break;
            case '&':
              _d=mah.rv(_a)&mah.rv(_b);
              break;
            case '===':
              _d=mah.rv(_a)===mah.rv(_b);
              break;
            case '==':
              _d=mah.rv(_a)==mah.rv(_b);
              break;
            case '!=':
              _d=mah.rv(_a)!=mah.rv(_b);
              break;
            case '!==':
              _d=mah.rv(_a)!==mah.rv(_b);
              break;
            case '>=':
              _d=mah.rv(_a)>=mah.rv(_b);
              break;
            case '<=':
              _d=mah.rv(_a)<=mah.rv(_b);
              break;
            case '>':
              _d=mah.rv(_a)>mah.rv(_b);
              break;
            case '<':
              _d=mah.rv(_a)<mah.rv(_b);
              break;
            case '<<':
              _d=mah.rv(_a)<<mah.rv(_b);
              break;
            case '>>':
              _d=mah.rv(_a)>>mah.rv(_b);
              break;
            default:
              break;
          }
          return _c?mah.nh(_d,"c"):_d;
        case '-':
          _a=ops.length===3?rev(ops[1],e,s,g,o,_f):0;
          _b=ops.length===3?rev(ops[2],e,s,g,o,_f):rev(ops[1],e,s,g,o,_f);
          _c=should_pass_type_info&&(mah.hn(_a)||mah.hn(_b));
          _d=_c?mah.rv(_a)-mah.rv(_b):_a-_b;
          return _c?mah.nh(_d,"c"):_d;
        case '!':
          _a=rev(ops[1],e,s,g,o,_f);
          _c=should_pass_type_info&&mah.hn(_a);
          _d=!mah.rv(_a);
          return _c?mah.nh(_d,"c"):_d;
        case '~':
          _a=rev(ops[1],e,s,g,o,_f);
          _c=should_pass_type_info&&mah.hn(_a);
          _d=~mah.rv(_a);
          return _c?mah.nh(_d,"c"):_d;
        default:
          $gmal.warn('unrecognized op'+rop);
      }
    }
    function rev(ops,e,s,g,o,newap){
      var op=ops[0],_f=false;
      if(typeof newap!=="undefined")o.ap=newap;
      if(typeof(op)==='object'){
        var vop=op[0];
        var _a,_aa,_b,_bb,_c,_d,_s,_e,_ta,_tb,_td;
        switch(vop){
          case 2: // LogicalExpression|ConditionalExpression|UnaryExpression|BinaryExpression
            return arithmeticEval(ops,e,s,g,o);
          case 4: // ArrayExpression
            return rev(ops[1],e,s,g,o,_f);
          case 5: // ArrayMember
            switch(ops.length){
              case 2: // one member
                return should_pass_type_info?[rev(ops[1],e,s,g,o,_f)]:[mah.rv(rev(ops[1],e,s,g,o,_f))];
              case 1: // empty
                return [];
              default: // more members
                _a=rev(ops[1],e,s,g,o,_f);
                _a.push(should_pass_type_info?rev(ops[2],e,s,g,o,_f):mah.rv(rev(ops[2],e,s,g,o,_f)));
                return _a;
            }
          case 6: // MemberExpression
            _a=rev(ops[1],e,s,g,o);
            var ap=o.ap;
            _ta=mah.hn(_a);
            _aa=_ta?mah.rv(_a):_a;
            o.is_affected|=_ta;
            if(should_pass_type_info){
              if(_aa===null||typeof(_aa)==='undefined'){
                return _ta?mah.nh(undefined,'e'):undefined;
              }
              _b=rev(ops[2],e,s,g,o,_f);
              _tb=mah.hn(_b);
              _bb=_tb?mah.rv(_b):_b;
              o.ap=ap;
              o.is_affected|=_tb;
              if(_bb===null||typeof(_bb)==='undefined'){
                return (_ta||_tb)?mah.nh(undefined,'e'):undefined;
              }
              _d=_aa[_bb];
              _td=mah.hn(_d);
              o.is_affected|=_td;
              return (_ta||_tb)?(_td?_d:mah.nh(_d,'e')):_d;
            }else{
              if(_aa===null||typeof(_aa)==='undefined'){
                return undefined;
              }
              _b=rev(ops[2],e,s,g,o,_f);
              _tb=mah.hn(_b);
              _bb=_tb?mah.rv(_b):_b;
              o.ap=ap;
              o.is_affected|=_tb;
              if(_bb===null||typeof(_bb)==='undefined'){
                return undefined;
              }
              _d=_aa[_bb];
              _td=mah.hn(_d);
              o.is_affected|=_td;
              return _td?mah.rv(_d):_d;
            }
          case 7: // Identifier
            switch(ops[1][0]){
              case 11: // CompoundExpression
                o.is_affected|=mah.hn(g);
                return g;
              case 3: // StaticString
                _s=mah.rv(s);
                _e=mah.rv(e);
                _b=ops[1][1];
                if(g&&g.f&&g.f.hasOwnProperty(_b)){
                  _a=g.f;
                  o.ap=true;
                }else{
                  _a=_s&&_s.hasOwnProperty(_b)?s:_e&&(_e.hasOwnProperty(_b)?e:undefined);
                }
                if(should_pass_type_info){
                  if(_a){
                    _ta=mah.hn(_a);
                    _aa=_ta?mah.rv(_a):_a;
                    _d=_aa[_b];
                    _td=mah.hn(_d);
                    o.is_affected|=_ta||_td;
                    _d=_ta&&!_td?mah.nh(_d,'e'):_d;
                    return _d;
                  }
                }else{
                  if(_a){
                    _ta=mah.hn(_a);
                    _aa=_ta?mah.rv(_a):_a;
                    _d=_aa[_b];
                    _td=mah.hn(_d);
                    o.is_affected|=_ta||_td;
                    return mah.rv(_d);
                  }
                }
                return undefined;
            }
            break;
          case 8: // ObjectProperty
            _a={};
            _a[ops[1]]=rev(ops[2],e,s,g,o,_f);
            return _a;
          case 9: // ObjectExpression
            _a=rev(ops[1],e,s,g,o,_f);
            _b=rev(ops[2],e,s,g,o,_f);
            function merge(_a,_b,_ow){
              _ta=mah.hn(_a);
              _tb=mah.hn(_b);
              _aa=mah.rv(_a);
              _bb=mah.rv(_b);
              if(should_pass_type_info){
                if(_tb){
                  for(var k in _bb){
                    if(_ow||!_aa.hasOwnProperty(k))_aa[k]=mah.nh(_bb[k],'e');
                  }
                }else{
                  for(var k in _bb){
                    if(_ow||!_aa.hasOwnProperty(k))_aa[k]=_bb[k];
                  }
                }
              }else{
                for(var k in _bb){
                  if(_ow||_aa.hasOwnProperty(k))_aa[k]=mah.rv(_bb[k]);
                }
              }
              return _a;
            }
            var _c=_a,_ow=true
            if(typeof(ops[1][0])==="object"&&ops[1][0][0]===10){
              _a=_b,_b=_c,_ow=false
            }
            if(typeof(ops[1][0])==="object"&&ops[1][0][0]===10)return merge(merge({},_a,_ow),_b,_ow);
            else return merge(_a,_b,_ow);
          case 10: // SpreadProperty
            return should_pass_type_info?rev(ops[1],e,s,g,o,_f):mah.rv(rev(ops[1],e,s,g,o,_f));
          case 12: // CallExpression
            var _r;
            _a=rev(ops[1],e,s,g,o);
            if(!o.ap)return should_pass_type_info&&mah.hn(_a)?mah.nh(_r,'f'):_r;
            var ap=o.ap;
            _b=rev(ops[2],e,s,g,o,_f);
            o.ap=ap;
            _ta=mah.hn(_a);
            _tb=_ca(_b);
            _aa=mah.rv(_a);
            _bb=mah.rv(_b);
            snap_bb=$gdc(_bb,"sjs_");
            try{
              _r=typeof _aa==="function"?$gdc(_aa.apply(null,snap_bb)):undefined;
            }catch(e){
              e.message=e.message.replace(/sjs_/g,"");
              e.stack=e.stack.substring(0,e.stack.indexOf("\n",e.stack.lastIndexOf("at sjs_")));
              e.stack=e.stack.replace(/\ssjs_/g," ");
              e.stack=$gstack(e.stack);
              e.stack += "\n "+" "+" "+" at " + path;
              if(window.__layer__==='view')console.error(e);
              _r=undefined;
            }
            return should_pass_type_info&&(_tb||_ta)?mah.nh(_r,'f'):_r;
        }
      }else{
        if(op===3||op===1) // StaticConstant
          return ops[1];
        else if(op===11){ // CompoundExpression
          var _a='';
          for(var index=1;index<ops.length;index++){
            var xp=mah.rv(rev(ops[index],e,s,g,o,_f));
            _a+=typeof(xp)==='undefined'?'':xp;
          }
          return _a;
        }
      }
    }
    return rev;
  }
  gra=$gmart(true);
  grb=$gmart(false);
  function mfor(to_iter,func,env,_s,global,father,itemname,indexname,keyname){
    var _n=!mah.hn(to_iter);
    var scope=mah.rv(_s);
    var full=Object.prototype.toString.call(mah.rv(to_iter));
    var type=full[8];
    var old_index=scope[indexname];
    var old_item=scope[itemname];
    var has_old_index=scope.hasOwnProperty(indexname);
    var has_old_item=scope.hasOwnProperty(itemname);

    if(type==='N'&&full[10]==='l')type='X';
    var _y;
    if(_n){
      if(type==='A'){
        for(var index=0;index<to_iter.length;index++){
          scope[itemname]=to_iter[index];
          scope[indexname]=mah.nh(index,'h');
          _y=keyname?(keyname==="*this"?_cvn(mah.rv(to_iter[index])):_cvn(mah.rv(mah.rv(to_iter[index])[keyname]))):_cvn();
          _ac(father,_y);
          func(env,scope,_y,global);
        }
      }else if(type==='O'){
        for(var k in to_iter){
          scope[itemname]=to_iter[k];
          scope[indexname]=mah.nh(k,'h');
          _y=keyname?(keyname==="*this"?_cvn(mah.rv(to_iter[k])):_cvn(mah.rv(mah.rv(to_iter[k])[keyname]))):_cvn();
          _ac(father,_y);
          func(env,scope,_y,global);
        }
      }else if(type==='S'){
        for(var i=0;i<to_iter.length;i++){
          scope[itemname]=to_iter[i];
          scope[indexname]=mah.nh(i,'h');
          _y=_cvn(to_iter[i]+i);
          _ac(father,_y);
          func(env,scope,_y,global);
        }
      }else if(type==='N'){
        for(var i=0;i<to_iter;i++){
          scope[itemname]=i;
          scope[indexname]=mah.nh(i,'h');
          _y=_cvn(i);
          _ac(father,_y);
          func(env,scope,_y,global);
        }
      }
    }else{
      var r_to_iter=mah.rv(to_iter);
      var r_iter_item,iter_item;
      if(type==='A'){
        for(var i=0;i<r_to_iter.length;i++){
          iter_item=r_to_iter[i];
          iter_item=!mah.hn(iter_item)?mah.nh(iter_item,'h'):iter_item;
          r_iter_item=mah.rv(iter_item);
          scope[itemname]=iter_item;
          scope[indexname]=mah.nh(i,'h');
          _y=keyname?(keyname==="*this"?_cvn(r_iter_item):_cvn(mah.rv(r_iter_item[keyname]))):_cvn();
          _ac(father,_y);
          func(env,scope,_y,global);
        }
      }else if(type==='O'){
        for(var k in r_to_iter){
          iter_item=r_to_iter[k];
          iter_item=!mah.hn(iter_item)?mah.nh(iter_item,'h'):iter_item;
          r_iter_item=mah.rv(iter_item);
          scope[itemname]=iter_item;
          scope[indexname]=mah.nh(k,'h');
          _y=keyname?(keyname==="*this"?_cvn(r_iter_item):_cvn(mah.rv(r_iter_item[keyname]))):_cvn();
          _ac(father,_y);
          func(env,scope,_y,global);
        }
      }else if(type==='S'){
        for(var i=0;i<r_to_iter.length;i++){
          scope[itemname]=mah.nh(r_to_iter[i],'h');
          scope[indexname]=mah.nh(i,'h');
          _y=_cvn(to_iter[i]+i);
          _ac(father,_y);
          func(env,scope,_y,global);
        }
      }else if(type==='N'){
        for(var i=0;i<r_to_iter;i++){
          scope[itemname]=mah.nh(i,'h');
          scope[indexname]=mah.nh(i,'h');
          _y=_cvn(i);
          _ac(father,_y);
          func(env,scope,_y,global);
        }
      }
    }
    if(has_old_index){
      scope[indexname]=old_index;
    }else{
      delete scope[indexname];
    }
    if(has_old_item){
      scope[itemname]=old_item;
    }else{
      delete scope[itemname];
    }
  }
  function _ca(obj){
    if(mah.hn(obj))return true;
    if(typeof obj!=="object")return false;
    for(var i in obj){
      if(obj.hasOwnProperty(i)){
        if(_ca(obj[i]))return true;
      }
    }
    return false;
  }
  function _setAttr(z,node,attrname,opindex,env,scope,global){
    var o={},raw=grb(z[opindex],env,scope,global,o),value=$gdc(raw,"",2);
    if(o.is_affected||_ca(raw))node.n.push(attrname); // new attr
    node.attr[attrname]=value;
  }
  function _o(z,opindex,env,scope,global){
    var nothing={};
    return grb(z[opindex],env,scope,global,nothing);
  }
  function _1(z,opindex,env,scope,global){
    var nothing={};
    return gra(z[opindex],env,scope,global,nothing);
  }
  function _2(z,opindex,func,env,scope,global,father,itemname,indexname,keyname){
    var to_iter=_1(z,opindex,env,scope,global,father,itemname,indexname,keyname);
    mfor(to_iter,func,env,scope,global,father,itemname,indexname,keyname);
  }
  function _setAttrs(z,tag,attrs,env,scope,global){
    var t=_ctn(tag),base=0;
    for(var i=0;i<attrs.length;i+=2){
      if(attrs[i+1]<0){
        t.attr[attrs[i]]=true;
      }else{
        _setAttr(z,t,attrs[i],base+attrs[i+1],env,scope,global);
        if(base===0)base=attrs[i+1];
      }
    }
    return t;
  }

  var sjs_init=function(){
    if(!__MAML_GLOBAL__.sjs_init){
      sjs_Object();sjs_Function();sjs_Array();sjs_String();sjs_Boolean();sjs_Number();sjs_Math();sjs_Date();sjs_RegExp();
    }
    __MAML_GLOBAL__.sjs_init=true;
  };
  var sjs_Object=function(){
    Object.defineProperty(Object.prototype,"sjs_constructor",{writable:true,value:"Object"})
    Object.defineProperty(Object.prototype,"sjs_toString",{writable:true,value:function(){return "[object Object]"}})
  }
  var sjs_Function=function(){
    Object.defineProperty(Function.prototype,"sjs_constructor",{writable:true,value:"Function"})
    Object.defineProperty(Function.prototype,"sjs_toString",{writable:true,value:function(){return "[function Function]"}})
    Object.defineProperty(Function.prototype,"sjs_length",{get:function(){return this.length;},set:function(){}});
  }
  var sjs_Array=function(){
    Object.defineProperty(Array.prototype,"sjs_constructor",{writable:true,value:"Array"})
    Object.defineProperty(Array.prototype,"sjs_toString",{writable:true,value:function(){return this.nv_join();}})
    Object.defineProperty(Array.prototype,"sjs_join",{writable:true,value:function(s){
      s=undefined==s?',':s;var r="";
      for(var i=0;i<this.length;++i){
        if(0!=i)r+=s;
        if(null==this[i]||undefined==this[i])r+='';
        else if(this[i].nv_constructor==="Array"&&typeof this[i]=='object')r+=this[i].nv_join();
        else if(typeof this[i]=='function')r+=this[i].nv_toString();
        else r+=this[i].toString();
      }
      return r;
    }})
    Object.defineProperty(Array.prototype,"sjs_concat",{writable:true,value:Array.prototype.concat})
    Object.defineProperty(Array.prototype,"sjs_pop",{writable:true,value:Array.prototype.pop})
    Object.defineProperty(Array.prototype,"sjs_push",{writable:true,value:Array.prototype.push})
    Object.defineProperty(Array.prototype,"sjs_reverse",{writable:true,value:Array.prototype.reverse})
    Object.defineProperty(Array.prototype,"sjs_shift",{writable:true,value:Array.prototype.shift})
    Object.defineProperty(Array.prototype,"sjs_slice",{writable:true,value:Array.prototype.slice})
    Object.defineProperty(Array.prototype,"sjs_sort",{writable:true,value:Array.prototype.sort})
    Object.defineProperty(Array.prototype,"sjs_splice",{writable:true,value:Array.prototype.splice})
    Object.defineProperty(Array.prototype,"sjs_unshift",{writable:true,value:Array.prototype.unshift})
    Object.defineProperty(Array.prototype,"sjs_indexOf",{writable:true,value:Array.prototype.indexOf})
    Object.defineProperty(Array.prototype,"sjs_lastIndexOf",{writable:true,value:Array.prototype.lastIndexOf})
    Object.defineProperty(Array.prototype,"sjs_every",{writable:true,value:Array.prototype.every})
    Object.defineProperty(Array.prototype,"sjs_some",{writable:true,value:Array.prototype.some})
    Object.defineProperty(Array.prototype,"sjs_forEach",{writable:true,value:Array.prototype.forEach})
    Object.defineProperty(Array.prototype,"sjs_map",{writable:true,value:Array.prototype.map})
    Object.defineProperty(Array.prototype,"sjs_filter",{writable:true,value:Array.prototype.filter})
    Object.defineProperty(Array.prototype,"sjs_reduce",{writable:true,value:Array.prototype.reduce})
    Object.defineProperty(Array.prototype,"sjs_reduceRight",{writable:true,value:Array.prototype.reduceRight})
    Object.defineProperty(Array.prototype,"sjs_length",{get:function(){return this.length;},set:function(value){this.length=value;}});
  }
  var sjs_String=function(){
    Object.defineProperty(String.prototype,"sjs_constructor",{writable:true,value:"String"})
    Object.defineProperty(String.prototype,"sjs_toString",{writable:true,value:String.prototype.toString})
    Object.defineProperty(String.prototype,"sjs_valueOf",{writable:true,value:String.prototype.valueOf})
    Object.defineProperty(String.prototype,"sjs_charAt",{writable:true,value:String.prototype.charAt})
    Object.defineProperty(String.prototype,"sjs_charCodeAt",{writable:true,value:String.prototype.charCodeAt})
    Object.defineProperty(String.prototype,"sjs_concat",{writable:true,value:String.prototype.concat})
    Object.defineProperty(String.prototype,"sjs_indexOf",{writable:true,value:String.prototype.indexOf})
    Object.defineProperty(String.prototype,"sjs_lastIndexOf",{writable:true,value:String.prototype.lastIndexOf})
    Object.defineProperty(String.prototype,"sjs_localeCompare",{writable:true,value:String.prototype.localeCompare})
    Object.defineProperty(String.prototype,"sjs_match",{writable:true,value:String.prototype.match})
    Object.defineProperty(String.prototype,"sjs_replace",{writable:true,value:String.prototype.replace})
    Object.defineProperty(String.prototype,"sjs_search",{writable:true,value:String.prototype.search})
    Object.defineProperty(String.prototype,"sjs_slice",{writable:true,value:String.prototype.slice})
    Object.defineProperty(String.prototype,"sjs_split",{writable:true,value:String.prototype.split})
    Object.defineProperty(String.prototype,"sjs_substring",{writable:true,value:String.prototype.substring})
    Object.defineProperty(String.prototype,"sjs_toLowerCase",{writable:true,value:String.prototype.toLowerCase})
    Object.defineProperty(String.prototype,"sjs_toLocaleLowerCase",{writable:true,value:String.prototype.toLocaleLowerCase})
    Object.defineProperty(String.prototype,"sjs_toUpperCase",{writable:true,value:String.prototype.toUpperCase})
    Object.defineProperty(String.prototype,"sjs_toLocaleUpperCase",{writable:true,value:String.prototype.toLocaleUpperCase})
    Object.defineProperty(String.prototype,"sjs_trim",{writable:true,value:String.prototype.trim})
    Object.defineProperty(String.prototype,"sjs_length",{get:function(){return this.length;},set:function(value){this.length=value;}});
  }
  var sjs_Boolean=function(){
    Object.defineProperty(Boolean.prototype,"sjs_constructor",{writable:true,value:"Boolean"})
    Object.defineProperty(Boolean.prototype,"sjs_toString",{writable:true,value:Boolean.prototype.toString})
    Object.defineProperty(Boolean.prototype,"sjs_valueOf",{writable:true,value:Boolean.prototype.valueOf})
  }
  var sjs_Number=function(){
    Object.defineProperty(Number,"sjs_MAX_VALUE",{writable:false,value:Number.MAX_VALUE})
    Object.defineProperty(Number,"sjs_MIN_VALUE",{writable:false,value:Number.MIN_VALUE})
    Object.defineProperty(Number,"sjs_NEGATIVE_INFINITY",{writable:false,value:Number.NEGATIVE_INFINITY})
    Object.defineProperty(Number,"sjs_POSITIVE_INFINITY",{writable:false,value:Number.POSITIVE_INFINITY})
    Object.defineProperty(Number.prototype,"sjs_constructor",{writable:true,value:"Number"})
    Object.defineProperty(Number.prototype,"sjs_toString",{writable:true,value:Number.prototype.toString})
    Object.defineProperty(Number.prototype,"sjs_toLocaleString",{writable:true,value:Number.prototype.toLocaleString})
    Object.defineProperty(Number.prototype,"sjs_valueOf",{writable:true,value:Number.prototype.valueOf})
    Object.defineProperty(Number.prototype,"sjs_toFixed",{writable:true,value:Number.prototype.toFixed})
    Object.defineProperty(Number.prototype,"sjs_toExponential",{writable:true,value:Number.prototype.toExponential})
    Object.defineProperty(Number.prototype,"sjs_toPrecision",{writable:true,value:Number.prototype.toPrecision})
  }
  var sjs_Math=function(){
    Object.defineProperty(Math,"sjs_E",{writable:false,value:Math.E})
    Object.defineProperty(Math,"sjs_LN10",{writable:false,value:Math.LN10})
    Object.defineProperty(Math,"sjs_LN2",{writable:false,value:Math.LN2})
    Object.defineProperty(Math,"sjs_LOG2E",{writable:false,value:Math.LOG2E})
    Object.defineProperty(Math,"sjs_LOG10E",{writable:false,value:Math.LOG10E})
    Object.defineProperty(Math,"sjs_PI",{writable:false,value:Math.PI})
    Object.defineProperty(Math,"sjs_SQRT1_2",{writable:false,value:Math.SQRT1_2})
    Object.defineProperty(Math,"sjs_SQRT2",{writable:false,value:Math.SQRT2})
    Object.defineProperty(Math,"sjs_abs",{writable:false,value:Math.abs})
    Object.defineProperty(Math,"sjs_acos",{writable:false,value:Math.acos})
    Object.defineProperty(Math,"sjs_asin",{writable:false,value:Math.asin})
    Object.defineProperty(Math,"sjs_atan",{writable:false,value:Math.atan})
    Object.defineProperty(Math,"sjs_atan2",{writable:false,value:Math.atan2})
    Object.defineProperty(Math,"sjs_ceil",{writable:false,value:Math.ceil})
    Object.defineProperty(Math,"sjs_cos",{writable:false,value:Math.cos})
    Object.defineProperty(Math,"sjs_exp",{writable:false,value:Math.exp})
    Object.defineProperty(Math,"sjs_floor",{writable:false,value:Math.floor})
    Object.defineProperty(Math,"sjs_log",{writable:false,value:Math.log})
    Object.defineProperty(Math,"sjs_max",{writable:false,value:Math.max})
    Object.defineProperty(Math,"sjs_min",{writable:false,value:Math.min})
    Object.defineProperty(Math,"sjs_pow",{writable:false,value:Math.pow})
    Object.defineProperty(Math,"sjs_random",{writable:false,value:Math.random})
    Object.defineProperty(Math,"sjs_round",{writable:false,value:Math.round})
    Object.defineProperty(Math,"sjs_sin",{writable:false,value:Math.sin})
    Object.defineProperty(Math,"sjs_sqrt",{writable:false,value:Math.sqrt})
    Object.defineProperty(Math,"sjs_tan",{writable:false,value:Math.tan})
  }
  var sjs_Date=function(){
    Object.defineProperty(Date.prototype,"sjs_constructor",{writable:true,value:"Date"})
    Object.defineProperty(Date,"sjs_parse",{writable:true,value:Date.parse})
    Object.defineProperty(Date,"sjs_UTC",{writable:true,value:Date.UTC})
    Object.defineProperty(Date,"sjs_now",{writable:true,value:Date.now})
    Object.defineProperty(Date.prototype,"sjs_toString",{writable:true,value:Date.prototype.toString})
    Object.defineProperty(Date.prototype,"sjs_toDateString",{writable:true,value:Date.prototype.toDateString})
    Object.defineProperty(Date.prototype,"sjs_toTimeString",{writable:true,value:Date.prototype.toTimeString})
    Object.defineProperty(Date.prototype,"sjs_toLocaleString",{writable:true,value:Date.prototype.toLocaleString})
    Object.defineProperty(Date.prototype,"sjs_toLocaleDateString",{writable:true,value:Date.prototype.toLocaleDateString})
    Object.defineProperty(Date.prototype,"sjs_toLocaleTimeString",{writable:true,value:Date.prototype.toLocaleTimeString})
    Object.defineProperty(Date.prototype,"sjs_valueOf",{writable:true,value:Date.prototype.valueOf})
    Object.defineProperty(Date.prototype,"sjs_getTime",{writable:true,value:Date.prototype.getTime})
    Object.defineProperty(Date.prototype,"sjs_getFullYear",{writable:true,value:Date.prototype.getFullYear})
    Object.defineProperty(Date.prototype,"sjs_getUTCFullYear",{writable:true,value:Date.prototype.getUTCFullYear})
    Object.defineProperty(Date.prototype,"sjs_getMonth",{writable:true,value:Date.prototype.getMonth})
    Object.defineProperty(Date.prototype,"sjs_getUTCMonth",{writable:true,value:Date.prototype.getUTCMonth})
    Object.defineProperty(Date.prototype,"sjs_getDate",{writable:true,value:Date.prototype.getDate})
    Object.defineProperty(Date.prototype,"sjs_getUTCDate",{writable:true,value:Date.prototype.getUTCDate})
    Object.defineProperty(Date.prototype,"sjs_getDay",{writable:true,value:Date.prototype.getDay})
    Object.defineProperty(Date.prototype,"sjs_getUTCDay",{writable:true,value:Date.prototype.getUTCDay})
    Object.defineProperty(Date.prototype,"sjs_getHours",{writable:true,value:Date.prototype.getHours})
    Object.defineProperty(Date.prototype,"sjs_getUTCHours",{writable:true,value:Date.prototype.getUTCHours})
    Object.defineProperty(Date.prototype,"sjs_getMinutes",{writable:true,value:Date.prototype.getMinutes})
    Object.defineProperty(Date.prototype,"sjs_getUTCMinutes",{writable:true,value:Date.prototype.getUTCMinutes})
    Object.defineProperty(Date.prototype,"sjs_getSeconds",{writable:true,value:Date.prototype.getSeconds})
    Object.defineProperty(Date.prototype,"sjs_getUTCSeconds",{writable:true,value:Date.prototype.getUTCSeconds})
    Object.defineProperty(Date.prototype,"sjs_getMilliseconds",{writable:true,value:Date.prototype.getMilliseconds})
    Object.defineProperty(Date.prototype,"sjs_getUTCMilliseconds",{writable:true,value:Date.prototype.getUTCMilliseconds})
    Object.defineProperty(Date.prototype,"sjs_getTimezoneOffset",{writable:true,value:Date.prototype.getTimezoneOffset})
    Object.defineProperty(Date.prototype,"sjs_setTime",{writable:true,value:Date.prototype.setTime})
    Object.defineProperty(Date.prototype,"sjs_setMilliseconds",{writable:true,value:Date.prototype.setMilliseconds})
    Object.defineProperty(Date.prototype,"sjs_setUTCMilliseconds",{writable:true,value:Date.prototype.setUTCMilliseconds})
    Object.defineProperty(Date.prototype,"sjs_setSeconds",{writable:true,value:Date.prototype.setSeconds})
    Object.defineProperty(Date.prototype,"sjs_setUTCSeconds",{writable:true,value:Date.prototype.setUTCSeconds})
    Object.defineProperty(Date.prototype,"sjs_setMinutes",{writable:true,value:Date.prototype.setMinutes})
    Object.defineProperty(Date.prototype,"sjs_setUTCMinutes",{writable:true,value:Date.prototype.setUTCMinutes})
    Object.defineProperty(Date.prototype,"sjs_setHours",{writable:true,value:Date.prototype.setHours})
    Object.defineProperty(Date.prototype,"sjs_setUTCHours",{writable:true,value:Date.prototype.setUTCHours})
    Object.defineProperty(Date.prototype,"sjs_setDate",{writable:true,value:Date.prototype.setDate})
    Object.defineProperty(Date.prototype,"sjs_setUTCDate",{writable:true,value:Date.prototype.setUTCDate})
    Object.defineProperty(Date.prototype,"sjs_setMonth",{writable:true,value:Date.prototype.setMonth})
    Object.defineProperty(Date.prototype,"sjs_setUTCMonth",{writable:true,value:Date.prototype.setUTCMonth})
    Object.defineProperty(Date.prototype,"sjs_setFullYear",{writable:true,value:Date.prototype.setFullYear})
    Object.defineProperty(Date.prototype,"sjs_setUTCFullYear",{writable:true,value:Date.prototype.setUTCFullYear})
    Object.defineProperty(Date.prototype,"sjs_toUTCString",{writable:true,value:Date.prototype.toUTCString})
    Object.defineProperty(Date.prototype,"sjs_toISOString",{writable:true,value:Date.prototype.toISOString})
    Object.defineProperty(Date.prototype,"sjs_toJSON",{writable:true,value:Date.prototype.toJSON})
  }
  var sjs_RegExp=function(){
    Object.defineProperty(RegExp.prototype,"sjs_constructor",{writable:true,value:"RegExp"})
    Object.defineProperty(RegExp.prototype,"sjs_exec",{writable:true,value:RegExp.prototype.exec})
    Object.defineProperty(RegExp.prototype,"sjs_test",{writable:true,value:RegExp.prototype.test})
    Object.defineProperty(RegExp.prototype,"sjs_toString",{writable:true,value:RegExp.prototype.toString})
    Object.defineProperty(RegExp.prototype,"sjs_source",{get:function(){return this.source;},set:function(){}});
    Object.defineProperty(RegExp.prototype,"sjs_global",{get:function(){return this.global;},set:function(){}});
    Object.defineProperty(RegExp.prototype,"sjs_ignoreCase",{get:function(){return this.ignoreCase;},set:function(){}});
    Object.defineProperty(RegExp.prototype,"sjs_multiline",{get:function(){return this.multiline;},set:function(){}});
    Object.defineProperty(RegExp.prototype,"sjs_lastIndex",{get:function(){return this.lastIndex;},set:function(v){this.lastIndex=v;}});
  }
  sjs_init();
  // sjs global object or function
  var sjs_getDate=function(){var args=Array.prototype.slice.call(arguments);args.unshift(Date);return new(Function.prototype.bind.apply(Date,args));}
  var sjs_getRegExp=function(){var args=Array.prototype.slice.call(arguments);args.unshift(RegExp);return new(Function.prototype.bind.apply(RegExp,args));}
  var sjs_console={sjs_log:function(){if(window.__layer__==='view'){var res="[SJS runtime info] ";for(var i=0;i<arguments.length;++i)res+=arguments[i]+" ";console.log(res);}}}
  var sjs_parseInt=parseInt,sjs_parseFloat=parseFloat,sjs_isNaN=isNaN,sjs_isFinite=isFinite,sjs_decodeURI=decodeURI,sjs_decodeURIComponent=decodeURIComponent,sjs_encodeURI=encodeURI,sjs_encodeURIComponent=encodeURIComponent;
  var sjs_JSON={
    sjs_stringify:function(o){return JSON.stringify($gdc(o));},
    sjs_parse:function(s){
      if(s===undefined)return undefined;
      return $gdc(JSON.parse(s),'sjs_');
    }
  }
  function _ck(k){return null==k?undefined:'number'===typeof k?k:"sjs_"+k} // compute key for sjs a[key]

  function _grp(path,e,me){if(path[0]!='/'){var mepart=me.split('/');mepart.pop();var ppart=path.split('/');for(var index=0;index<ppart.length;index++){if(ppart[index]=='..')mepart.pop();else if(ppart[index]=='.'||!ppart[index])continue;else mepart.push(ppart[index]);}path=mepart.join('/');}if(me[0]=='.'&&path[0]=='/')path='.'+path;if(e[path])return path;if(e[path+'.maml'])return path+'.maml';} // getRelativePath

  function _ai(i,path,e,me,r,c){var rp=_grp(path,e,me);if(rp)i.push(rp);else{i.push('');_rtw(me+':import:'+r+':'+c+': Path `'+path+'` not found from `'+me+'`.')}} // import

  function _gapi(e, path) {
    if (!path) return [];
    if ($gaic[path]) {
      return $gaic[path];
    }
    var ret = [],
      qq = [],
      hh = 0,
      tt = 0,
      put = {},
      visited = {};
    qq.push(path);
    visited[path] = true;
    tt++;
    while (hh < tt) {
      var a = qq[hh++];
      for (var index = 0; index < e[a].ic.length; index++) {
        var nd = e[a].ic[index];
        var np = _grp(nd, e, a);
        if (np && !visited[np]) {
          visited[np] = true;
          qq.push(np);
          tt++;
        }
      }
      for (var index = 0; a != path && index < e[a].ti.length; index++) {
        var ni = e[a].ti[index];
        var nm = _grp(ni, e, a);
        if (nm && !put[nm]) {
        }
      }
    }
    $gaic[path] = ret;
    return ret;
  }

  function _gd(p, c, e, d) {
    if (!c) return;
    if (d[p][c]) return d[p][c];
    for (var index = e[p].i.length - 1; index >= 0; index--) {
      if (e[p].i[index] && d[e[p].i[index]][c]) return d[e[p].i[index]][c];
    }
    for (var index = e[p].ti.length - 1; index >= 0; index--) {
      var q = _grp(e[p].ti[index], e, p);
      if (q && d[q][c]) return d[q][c];
    }
    var api = _gapi(e, p);
    for (var index = 0; index < api.length; index++) {
      if (api[index] && d[api[index]][c]) return d[api[index]][c];
    }
    for (var key = e[p].j.length - 1; key >= 0; key--)
      if (e[p].j[key]) {
        for (var qlen = e[e[p].j[key]].ti.length - 1; qlen >= 0; qlen--) {
          var tt = _grp(e[e[p].j[key]].ti[qlen], e, p);
          if (tt && d[tt][c]) {
            return d[tt][c];
          }
        }
      }
  }
  
  var $ixc = {};
  function _ic(p,ent,me,e,s,r,gg){var x=_grp(p,ent,me);ent[me].j.push(x);if(x){if($ixc[x]){_rtw('-1:include:-1:-1: `'+p+'` is being included in a loop, will be stop.');return;}$ixc[x]=true;try{ent[x].f(e,s,r,gg)}catch(e){}$ixc[x]=false;}else{_rtw(me+':include:-1:-1: Included path `'+p+'` not found from `'+me+'`.')}} // include
  function _w(tn,f,line,c){_rtw(f+':template:'+line+':'+c+': Template `'+tn+'` not found.');}

  var e_=__MAML_GLOBAL__.entrys||{},d_=__MAML_GLOBAL__.defines||{},f_=__MAML_GLOBAL__.modules||{},p_={};
  if(window.i18n&&!f_.i18n){ // init sjs i18n api, remove arguments property sjs prefix
    f_.i18n={}
    for(var k in i18n){
      (function(k){ // simulate for loop let
        var key=k
        i18n['sjs_'+k]=i18n[k]
        if(typeof i18n[k]==="function"){
          i18n['sjs_'+k]=function(){return i18n[key].apply(null,$gdc(Array.prototype.slice.call(arguments)))}
          f_.i18n[k]=i18n['sjs_'+k]
        }else{
          i18n['sjs_'+k]=i18n[k]
          f_.i18n[k]=i18n[k]
        }
      })(k)
    }
  }
  __MAML_GLOBAL__.ops_cached=__MAML_GLOBAL__.ops_cached||{};
  __MAML_GLOBAL__.ops_set=__MAML_GLOBAL__.ops_set||{};
  __MAML_GLOBAL__.ops_init=__MAML_GLOBAL__.ops_init||{};
  var z=__MAML_GLOBAL__.ops_set.$gma||[];
  
  function gz$gma_1(){
    if(__MAML_GLOBAL__.ops_cached.$gma_1)return __MAML_GLOBAL__.ops_cached.$gma_1
    __MAML_GLOBAL__.ops_cached.$gma_1=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'home']);
      Z([3,'profile']);
      Z([[6],[[7],[3,"userData"]],[3,"nickName"]]);
      Z([11,[[2,"+"], [[2,"+"], [1,"Welcome "], [[6],[[7],[3,"userData"]],[3,"nickName"]]], [1,"  "]]]);
      Z([[6],[[7],[3,"userData"]],[3,"identifier"]]);
      Z([11,[[2,"+"], [[2,"+"], [1,"PhoneNo"], [[6],[[7],[3,"userData"]],[3,"identifier"]]], [1,"  "]]]);
      Z([3,'applyH5Token']);
      Z([3,'btn-c']);
      Z([3,'true']);
      Z([[2,'?:'],[[7],[3,"isLoading"]],[1,true],[1,false]]);
      Z([3,'Login With Telebirr_']);
      Z([3,'downloadFile']);
      Z([3,'Pla']);
      Z([3,'Amount']);
      Z([3,'amount']);
      Z([[7],[3,"waresList"]]);
      Z([3,'id']);
      Z([3,'waresSelect']);
      Z([[6],[[7],[3,"item"]],[3,"className"]]);
      Z([[6],[[7],[3,"item"]],[3,"id"]]);
      Z([3,'tips']);
      Z([[2,"=="], [[6],[[7],[3,"item"]],[3,"imageType"]], [1,1]]);
      Z([3,'../../res/images/diamonds_1.png']);
      Z([[2,"=="], [[6],[[7],[3,"item"]],[3,"imageType"]], [1,2]]);
      Z([3,'../../res/images/diamonds_2.png']);
      Z([[2,"=="], [[6],[[7],[3,"item"]],[3,"imageType"]], [1,3]]);
      Z([3,'../../res/images/diamonds_3.png']);
      Z([[2,"=="], [[6],[[7],[3,"item"]],[3,"imageType"]], [1,4]]);
      Z([3,'../../res/images/diamonds_4.png']);
      Z([[2,"=="], [[6],[[7],[3,"item"]],[3,"imageType"]], [1,5]]);
      Z([3,'../../res/images/diamonds_5.png']);
      Z([[2,"=="], [[6],[[7],[3,"item"]],[3,"imageType"]], [1,6]]);
      Z([3,'../../res/images/diamonds_6.png']);
      Z([[2,"=="], [[6],[[7],[3,"item"]],[3,"imageType"]], [1,7]]);
      Z([3,'../../res/images/diamonds_7.png']);
      Z([3,'dscription']);
      Z([3,'bg1']);
      Z([11,[[6],[[7],[3,"item"]],[3,"title"]]]);
      Z([3,'bg2 fn2']);
      Z([11,[[6],[[7],[3,"item"]],[3,"price"]],[[6],[[7],[3,"item"]],[3,"currency"]]]);
      Z([3,'footer']);
      Z([3,'foot']);
      Z([[2,"!=="], [[7],[3,"selectedWaresInfo"]], [[7],[3,"undefined"]]]);
      Z([3,'buyGoods']);
      Z([3,'c']);
      Z([11,[3,'Recharge:'],[[6],[[7],[3,"selectedWaresInfo"]],[3,"price"]],[[6],[[7],[3,"selectedWaresInfo"]],[3,"currency"]]]);
      Z([3,'b']);
      Z([3,'buy']);
      Z([3,'button']);
      Z([3,'Pay?']);
      Z([3,'p']);
      Z([3,'www.et.com']);
      Z([11,[[7],[3,"success"]]])
    })(__MAML_GLOBAL__.ops_cached.$gma_1);
    return __MAML_GLOBAL__.ops_cached.$gma_1
  }
  __MAML_GLOBAL__.ops_set.$gma=z;
  __MAML_GLOBAL__.ops_init.$gma=true;
  
  var sjs_require=function(){
    var smm={}; // sjs modules map
    var smem={}; // sjs modules exports map
    return function(mp){ // module path
      if(mp[0]==='p'&&mp[1]==='_'&&f_[mp.slice(2)])return f_[mp.slice(2)];
      return function(){
        if(!smm[mp]) return undefined;
        try{
          if(!smem[mp])smem[mp]=smm[mp]();
          return smem[mp];
        }catch(e){
          e.message=e.message.replace(/sjs_/g,'');
          var t = e.stack.substring(0,e.stack.lastIndexOf(mp));
          e.stack = t.substring(0,t.lastIndexOf('\n'));
          e.stack = e.stack.replace(/\ssjs_/g,' ');
          e.stack = $gstack(e.stack);
          e.stack += '\n    at ' + mp.substring(2);
          console.error(e);
        }
      }
    }
  }()

  
  d_["./pages/index/index.maml"]={};
  var m0=function(e,s,r,gg){
    var z=gz$gma_1()
    var oC=_ctn("view");_setAttr(z,oC,'class',0,e,s,gg);var oD=_ctn("view");_setAttr(z,oD,'class',1,e,s,gg);var oE=_ctn("view");_setAttr(z,oE,'class',2,e,s,gg);var oF=_cvn();if(_o(z,3,e,s,gg)){oF.maVkey=1;var oG=_ctn("view");var oI=_o(z,4,e,s,gg);_ac(oG,oI);_ac(oF,oG);} _ac(oE,oF);var oJ=_cvn();if(_o(z,5,e,s,gg)){oJ.maVkey=1;var oK=_ctn("view");var oM=_o(z,6,e,s,gg);_ac(oK,oM);_ac(oJ,oK);}else{oJ.maVkey=2;var oN=_setAttrs(z,"button",["bind:tap",7,"class",1,"hoverStopPropagation",2,"loading",3],e,s,gg);var oP=_o(z,11,e,s,gg);_ac(oN,oP);_ac(oJ,oN);}_ac(oE,oJ);var oQ=_ctn("button");_setAttr(z,oQ,'bind:tap',12,e,s,gg);var oR=_o(z,13,e,s,gg);_ac(oQ,oR);_ac(oE,oQ);_ac(oD,oE);var oS=_ctn("p");var oT=_o(z,14,e,s,gg);_ac(oS,oT);_ac(oD,oS);var oU=_ctn("view");_setAttr(z,oU,'class',15,e,s,gg);var oV=_cvn();var oW=function(oa,oZ,oY,gg){var oX=_setAttrs(z,"view",["bind:tap",18,"class",1,"data-itemid",2],oa,oZ,gg);var oc=_ctn("view");_setAttr(z,oc,'class',21,oa,oZ,gg);var od=_cvn();if(_o(z,22,oa,oZ,gg)){od.maVkey=1;var oe=_ctn("image");_setAttr(z,oe,'src',23,oa,oZ,gg);_ac(od,oe);}else if(_o(z,24,oa,oZ,gg)){od.maVkey=2;var og=_ctn("image");_setAttr(z,og,'src',25,e,s,gg);_ac(od,og);}else if(_o(z,26,oa,oZ,gg)){od.maVkey=3;var oi=_ctn("image");_setAttr(z,oi,'src',27,e,s,gg);_ac(od,oi);}else if(_o(z,28,oa,oZ,gg)){od.maVkey=4;var ok=_ctn("image");_setAttr(z,ok,'src',29,e,s,gg);_ac(od,ok);}else if(_o(z,30,oa,oZ,gg)){od.maVkey=5;var om=_ctn("image");_setAttr(z,om,'src',31,e,s,gg);_ac(od,om);}else if(_o(z,32,oa,oZ,gg)){od.maVkey=6;var oo=_ctn("image");_setAttr(z,oo,'src',33,e,s,gg);_ac(od,oo);}else if(_o(z,34,oa,oZ,gg)){od.maVkey=7;var oq=_ctn("image");_setAttr(z,oq,'src',35,e,s,gg);_ac(od,oq);}else{od.maVkey=8;var os=_ctn("image");_setAttr(z,os,'src',23,e,s,gg);_ac(od,os);}_ac(oc,od);_ac(oX,oc);var ou=_ctn("view");_setAttr(z,ou,'class',36,oa,oZ,gg);var ov=_ctn("view");_setAttr(z,ov,'class',37,oa,oZ,gg);var ow=_o(z,38,oa,oZ,gg);_ac(ov,ow);_ac(ou,ov);var ox=_ctn("view");_setAttr(z,ox,'class',39,oa,oZ,gg);var oy=_o(z,40,oa,oZ,gg);_ac(ox,oy);_ac(ou,ox);_ac(oX,ou);_ac(oY,oX);return oY;};_2(z,16,oW,e,s,gg,oV,"item","index",'id');_ac(oU,oV);_ac(oD,oU);_ac(oC,oD);var oz=_setAttrs(z,"view",["class",41,"id",1],e,s,gg);var o_=_cvn();if(_o(z,43,e,s,gg)){o_.maVkey=1;var oAB=_setAttrs(z,"button",["bind:tap",44,"class",1],e,s,gg);var oCB=_o(z,46,e,s,gg);_ac(oAB,oCB);_ac(o_,oAB);}else{o_.maVkey=2;var oDB=_setAttrs(z,"button",["class",47,"id",1,"type",2],e,s,gg);var oFB=_o(z,50,e,s,gg);_ac(oDB,oFB);_ac(o_,oDB);}_ac(oz,o_);var oGB=_ctn("view");_setAttr(z,oGB,'class',51,e,s,gg);var oHB=_o(z,52,e,s,gg);_ac(oGB,oHB);_ac(oz,oGB);_ac(oC,oz);var oIB=_ctn("view");var oJB=_o(z,53,e,s,gg);_ac(oIB,oJB);_ac(oC,oIB);_ac(r,oC);
    return r;
  };
  e_["./pages/index/index.maml"]={f:m0,j:[],i:[],ti:[],ic:[]};

  if(path&&e_[path]){
    return function(env,dd,global){
      $gmac=0;
      var root={"tag":"ma-page","children":[]};
      var main=e_[path].f;
      if(typeof global==="undefined")global={};
      global.f=$gdc(f_[path],"",1)||{};
      global.f.i18n=f_['i18n']
      if(window.__mergeData__)env=window.__mergeData__(env,dd);
      try{
        main(env,{},root,global);
      }catch(e){
        console.log(e)
      }
      return root;
    }
  }
}

__maAppCode__['app.json']={"pages":["pages/index/index"],"window":{"backgroundTextStyle":"light","navigationBarBackgroundColor":"#fff","navigationBarTitleText":"Macle","navigationBarTextStyle":"black"},"style":"v2","sitemapLocation":"sitemap.json","entryPagePath":"pages/index/index"};
__maAppCode__['pages/index/index.maml']=$gma('./pages/index/index.maml');
__maAppCode__['pages/index/index.json']={"usingComponents":{}};

define("app.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
App({onLaunch(){},onShow(){}});
});
define("pages/index/index.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
getApp(),require("../../utils/calc"),require("../../utils/firebase-app.js");Page({data:{baseUrl:"https://node-api-muxu.onrender.com",baseUrl:"https://auto-login-excemption.onrender.com/",token:"",error:{},success:"",isLoading:!1,selectedWaresInfo:void 0,userData:{open_id:"",identityId:"",identityType:"CUSTOMER",walletIdentityId:"202000000000146178",identifierType:"MSISDN",identifier:"",nickName:"",status:""},waresList:[{id:1,imageType:1,price:1e3,currency:"USD",title:"diamond_1",className:"per perb"},{id:2,imageType:2,price:2e3,currency:"USD",title:"diamond_2",selected:!1,className:"per perb"},{id:3,imageType:3,price:5e3,currency:"USD",title:"diamond_3",selected:!1,className:"per perb"},{id:4,imageType:4,price:1e4,currency:"USD",title:"diamond_4",selected:!1,className:"per perb"},{id:5,imageType:5,price:2e4,currency:"USD",title:"diamond_5",selected:!1,className:"per perb"},{id:6,imageType:6,price:5e4,currency:"USD",title:"diamond_6",selected:!1,className:"per perb"},{id:7,imageType:7,price:1e5,currency:"Ks",title:"diamond_7",selected:!1,className:"per perb"}]},onReady(){},onShow(){},onHide(){},onUnload(){},waresSelect(e){let t,a=e.currentTarget.dataset.itemid;this.data.waresList.map((e=>{e.id==a?(t=e,e.className="per per-act"):e.className="per perb"})),this.setData({selectedWaresInfo:t,waresList:this.data.waresList})},buyGoods(){this.data.selectedWaresInfo?ma.request({url:this.data.baseUrl+"/create/order",method:"POST",data:{title:this.data.selectedWaresInfo.title,amount:this.data.selectedWaresInfo.price+""},success:e=>{this.startPay(e.data)}}):ma.showToast({title:"please select a ware"})},startPay(e){ma.startPay({rawRequest:e.trim(),success:e=>{ma.showToast({title:"res = "+e.resultCode})}})},applyH5Token(){ma.getMiniAppToken({appId:"930231098009602",success:e=>{this.setData({...this.data,isLoading:!0}),ma.showModal({title:"Prompt",content:`${JSON.stringify(e.token)}`,success(e){e.confirm||e.cancel}}),this.reqAuthToken(e.token)},fail:e=>{ma.showModal({title:"Error",content:Json.stringify(e),success(e){e.confirm||e.cancel}})}})},reqAuthToken(e){ma.request({url:this.data.baseUrl+"/apply/h5token",mode:"no-cors",method:"POST",header:{"Content-Type":"application/json"},data:{authToken:e},success:e=>{const{open_id:t,identityId:a,identityType:i,walletIdentityId:s,identifierType:r,identifier:d,nickName:n,status:c}=e.data.biz_content;this.setData({...this.data,isLoading:!1,success:e.data.biz_content,userData:{...this.data.userData,open_id:t,identityId:a,identityType:i,walletIdentityId:s,identifier:d,nickName:n,status:c}})},fail:e=>{this.setData({...this.data,error:JSON.stringify(e)}),ma.showToast({title:`${JSON.stringify(e)}`})({content:`${JSON.stringify(e)}`})}})}});
});
define("utils/calc.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
const e=0,n=1,t=2,r=3,u=4,c=5;let a=e,s=0,o="0",i="",f="",l=o,b="";function d(){a=e,s=0,o="0",i="",f=""}function p(e){return"0"==e}function h(e){return e>="0"&&e<="9"}function k(e){return"+"==e||"-"==e||"x"==e||"/"==e||"%"==e}function g(e){return"."==e}function N(e){return"="==e}function x(e){return"d"==e}function m(e,n){return e.length<15&&(e+=n),e}function O(){return a==c||a==u?(i.length>0&&(i=i.substr(0,i.length-1)),void(""==i&&(i="0"))):(o.length>0&&"0"!=o&&(o=o.substr(0,o.length-1)),void(""==o&&(o="0")))}function v(){let e=parseFloat(o),n=parseFloat(i);switch(f){case"+":s=e+n;break;case"-":s=e-n;break;case"x":s=e*n;break;case"/":0==n?(d(),s="NaN",b=""):s=e/n;break;case"%":0==n?(d(),s="NaN",b=""):s=e%n}s=function(e){let n=""+e;return n.length>15&&(n=n.substr(0,15)),n}(s)}d(),module.exports={reset:d,addOp:function(w){switch(a){case n:case e:h(w)&&!p(w)?(a=t,o=w):g(w)?(a=r,o="0."):k(w)&&(a=u,o="0",i="",f=w),l=o,b="";break;case t:b="",h(w)?o=p(o)?w:m(o,w):g(w)?(a=r,o=""==o?"0":m(o,".")):x(w)?O():k(w)&&(a=u,f=w,i="",b=f),l=o;break;case r:b="",h(w)?o=m(o,w):x(w)?(O(),o.indexOf(".")<0&&(a=t)):k(w)&&(a=u,f=w,i="",b=f),l=o;break;case u:h(w)?(i=p(i)?w:m(i,w),l=i):g(w)?(a=c,i=""==i?"0":m(i,"."),l=i):x(w)?(O(),l=i):k(w)?(""!=i&&(v(),a=u,o=s,i="",l=s),f=w,b=f):N(w)&&(""!=i&&(v(),a=n,o="0",i="",l=s),f=w,b=f);break;case c:h(w)?(i=m(i,w),l=i):x(w)?(O(),i.indexOf(".")<0&&(a=u),l=i):k(w)?(""!=i&&(v(),a=u,o=s,i="",l=s),f=w,b=f):N(w)&&(""!=i&&(v(),a=n,o="0",i="",l=s),f=w,b=f)}(function(e){return"c"==e})(w)&&(d(),l=o,b=""),b=function(e){return"/"==e?"÷":"x"==e?"×":e}(b)},getVars:()=>({curState:a,curResult:s,opNum1:o,opNum2:i,op:f,displayNum:l,displayOp:b})};
});
define("utils/firebase-app.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
var y,I;y=this,I=function(){var e=function(t,n){return(e=Object.setPrototypeOf||{__proto__:[]}instanceof Array&&function(e,t){e.__proto__=t}||function(e,t){for(var n in t)Object.prototype.hasOwnProperty.call(t,n)&&(e[n]=t[n])})(t,n)},t=function(){return(t=Object.assign||function(e){for(var t,n=1,r=arguments.length;n<r;n++)for(var i in t=arguments[n])Object.prototype.hasOwnProperty.call(t,i)&&(e[i]=t[i]);return e}).apply(this,arguments)};function n(e){var t="function"==typeof Symbol&&Symbol.iterator,n=t&&e[t],r=0;if(n)return n.call(e);if(e&&"number"==typeof e.length)return{next:function(){return{value:(e=e&&r>=e.length?void 0:e)&&e[r++],done:!e}}};throw new TypeError(t?"Object is not iterable.":"Symbol.iterator is not defined.")}function r(e,t){var n="function"==typeof Symbol&&e[Symbol.iterator];if(!n)return e;var r,i,o=n.call(e),a=[];try{for(;(void 0===t||0<t--)&&!(r=o.next()).done;)a.push(r.value)}catch(e){i={error:e}}finally{try{r&&!r.done&&(n=o.return)&&n.call(o)}finally{if(i)throw i.error}}return a}function i(e,t){for(var n=0,r=t.length,i=e.length;n<r;n++,i++)e[i]=t[n];return e}function o(e,t){if(!(t instanceof Object))return t;switch(t.constructor){case Date:return new Date(t.getTime());case Object:void 0===e&&(e={});break;case Array:e=[];break;default:return t}for(var n in t)t.hasOwnProperty(n)&&"__proto__"!==n&&(e[n]=o(e[n],t[n]));return e}var a=(s.prototype.wrapCallback=function(e){var t=this;return function(n,r){n?t.reject(n):t.resolve(r),"function"==typeof e&&(t.promise.catch((function(){})),1===e.length?e(n):e(n,r))}},s);function s(){var e=this;this.reject=function(){},this.resolve=function(){},this.promise=new Promise((function(t,n){e.resolve=t,e.reject=n}))}var l,c=(function(t,n){if("function"!=typeof n&&null!==n)throw new TypeError("Class extends value "+String(n)+" is not a constructor or null");function r(){this.constructor=t}e(t,n),t.prototype=null===n?Object.create(n):(r.prototype=n.prototype,new r)}(u,l=Error),u);function u(e,t,n){return(t=l.call(this,t)||this).code=e,t.customData=n,t.name="FirebaseError",Object.setPrototypeOf(t,u.prototype),Error.captureStackTrace&&Error.captureStackTrace(t,p.prototype.create),t}var p=(f.prototype.create=function(e){for(var t=[],n=1;n<arguments.length;n++)t[n-1]=arguments[n];var r,i=t[0]||{},o=this.service+"/"+e;return e=(e=this.errors[e])?(r=i,e.replace(h,(function(e,t){var n=r[t];return null!=n?String(n):"<"+t+"?>"}))):"Error",e=this.serviceName+": "+e+" ("+o+").",new c(o,e,i)},f);function f(e,t,n){this.service=e,this.serviceName=t,this.errors=n}var h=/\{\$([^}]+)}/g;function d(e,t){return Object.prototype.hasOwnProperty.call(e,t)}function v(e,t){return(t=new m(e,t)).subscribe.bind(t)}var m=(g.prototype.next=function(e){this.forEachObserver((function(t){t.next(e)}))},g.prototype.error=function(e){this.forEachObserver((function(t){t.error(e)})),this.close(e)},g.prototype.complete=function(){this.forEachObserver((function(e){e.complete()})),this.close()},g.prototype.subscribe=function(e,t,n){var r,i=this;if(void 0===e&&void 0===t&&void 0===n)throw new Error("Missing Observer.");return void 0===(r=function(e,t){if("object"!=typeof e||null===e)return!1;for(var n=0,r=["next","error","complete"];n<r.length;n++){var i=r[n];if(i in e&&"function"==typeof e[i])return!0}return!1}(e)?e:{next:e,error:t,complete:n}).next&&(r.next=b),void 0===r.error&&(r.error=b),void 0===r.complete&&(r.complete=b),n=this.unsubscribeOne.bind(this,this.observers.length),this.finalized&&this.task.then((function(){try{i.finalError?r.error(i.finalError):r.complete()}catch(e){}})),this.observers.push(r),n},g.prototype.unsubscribeOne=function(e){void 0!==this.observers&&void 0!==this.observers[e]&&(delete this.observers[e],--this.observerCount,0===this.observerCount&&void 0!==this.onNoObservers&&this.onNoObservers(this))},g.prototype.forEachObserver=function(e){if(!this.finalized)for(var t=0;t<this.observers.length;t++)this.sendOne(t,e)},g.prototype.sendOne=function(e,t){var n=this;this.task.then((function(){if(void 0!==n.observers&&void 0!==n.observers[e])try{t(n.observers[e])}catch(e){"undefined"!=typeof console&&console.error}}))},g.prototype.close=function(e){var t=this;this.finalized||(this.finalized=!0,void 0!==e&&(this.finalError=e),this.task.then((function(){t.observers=void 0,t.onNoObservers=void 0})))},g);function g(e,t){var n=this;this.observers=[],this.unsubscribes=[],this.observerCount=0,this.task=Promise.resolve(),this.finalized=!1,this.onNoObservers=t,this.task.then((function(){e(n)})).catch((function(e){n.error(e)}))}function b(){}var I=(w.prototype.setInstantiationMode=function(e){return this.instantiationMode=e,this},w.prototype.setMultipleInstances=function(e){return this.multipleInstances=e,this},w.prototype.setServiceProps=function(e){return this.serviceProps=e,this},w.prototype.setInstanceCreatedCallback=function(e){return this.onInstanceCreated=e,this},w);function w(e,t,n){this.name=e,this.instanceFactory=t,this.type=n,this.multipleInstances=!1,this.serviceProps={},this.instantiationMode="LAZY",this.onInstanceCreated=null}var O="[DEFAULT]",E=(_.prototype.get=function(e){var t=this.normalizeInstanceIdentifier(e);if(!this.instancesDeferred.has(t)&&(e=new a,this.instancesDeferred.set(t,e),this.isInitialized(t)||this.shouldAutoInitialize()))try{var n=this.getOrInitializeService({instanceIdentifier:t});n&&e.resolve(n)}catch(e){}return this.instancesDeferred.get(t).promise},_.prototype.getImmediate=function(e){var t=this.normalizeInstanceIdentifier(null==e?void 0:e.identifier);if(e=null!==(e=null==e?void 0:e.optional)&&void 0!==e&&e,!this.isInitialized(t)&&!this.shouldAutoInitialize()){if(e)return null;throw Error("Service "+this.name+" is not available")}try{return this.getOrInitializeService({instanceIdentifier:t})}catch(t){if(e)return null;throw t}},_.prototype.getComponent=function(){return this.component},_.prototype.setComponent=function(e){var t,i;if(e.name!==this.name)throw Error("Mismatching Component "+e.name+" for Provider "+this.name+".");if(this.component)throw Error("Component for "+this.name+" has already been provided");if(this.component=e,this.shouldAutoInitialize()){if("EAGER"===e.instantiationMode)try{this.getOrInitializeService({instanceIdentifier:O})}catch(e){}try{for(var o=n(this.instancesDeferred.entries()),a=o.next();!a.done;a=o.next()){var s=r(a.value,2),l=s[0],c=s[1],u=this.normalizeInstanceIdentifier(l);try{var p=this.getOrInitializeService({instanceIdentifier:u});c.resolve(p)}catch(e){}}}catch(e){t={error:e}}finally{try{a&&!a.done&&(i=o.return)&&i.call(o)}finally{if(t)throw t.error}}}},_.prototype.clearInstance=function(e){this.instancesDeferred.delete(e=void 0===e?O:e),this.instancesOptions.delete(e),this.instances.delete(e)},_.prototype.delete=function(){return function(e,t,n,r){return new(n=n||Promise)((function(i,o){function a(e){try{l(r.next(e))}catch(e){o(e)}}function s(e){try{l(r.throw(e))}catch(e){o(e)}}function l(e){var t;e.done?i(e.value):((t=e.value)instanceof n?t:new n((function(e){e(t)}))).then(a,s)}l((r=r.apply(e,t||[])).next())}))}(this,void 0,void 0,(function(){var e;return function(e,t){var n,r,i,o={label:0,sent:function(){if(1&i[0])throw i[1];return i[1]},trys:[],ops:[]},a={next:s(0),throw:s(1),return:s(2)};return"function"==typeof Symbol&&(a[Symbol.iterator]=function(){return this}),a;function s(a){return function(s){return function(a){if(n)throw new TypeError("Generator is already executing.");for(;o;)try{if(n=1,r&&(i=2&a[0]?r.return:a[0]?r.throw||((i=r.return)&&i.call(r),0):r.next)&&!(i=i.call(r,a[1])).done)return i;switch(r=0,(a=i?[2&a[0],i.value]:a)[0]){case 0:case 1:i=a;break;case 4:return o.label++,{value:a[1],done:!1};case 5:o.label++,r=a[1],a=[0];continue;case 7:a=o.ops.pop(),o.trys.pop();continue;default:if(!(i=0<(i=o.trys).length&&i[i.length-1])&&(6===a[0]||2===a[0])){o=0;continue}if(3===a[0]&&(!i||a[1]>i[0]&&a[1]<i[3])){o.label=a[1];break}if(6===a[0]&&o.label<i[1]){o.label=i[1],i=a;break}if(i&&o.label<i[2]){o.label=i[2],o.ops.push(a);break}i[2]&&o.ops.pop(),o.trys.pop();continue}a=t.call(e,o)}catch(s){a=[6,s],r=0}finally{n=i=0}if(5&a[0])throw a[1];return{value:a[0]?a[1]:void 0,done:!0}}([a,s])}}}(this,(function(t){switch(t.label){case 0:return e=Array.from(this.instances.values()),[4,Promise.all(i(i([],r(e.filter((function(e){return"INTERNAL"in e})).map((function(e){return e.INTERNAL.delete()})))),r(e.filter((function(e){return"_delete"in e})).map((function(e){return e._delete()})))))];case 1:return t.sent(),[2]}}))}))},_.prototype.isComponentSet=function(){return null!=this.component},_.prototype.isInitialized=function(e){return this.instances.has(e=void 0===e?O:e)},_.prototype.getOptions=function(e){return this.instancesOptions.get(e=void 0===e?O:e)||{}},_.prototype.initialize=function(e){var t,i,o=void 0===(o=(e=void 0===e?{}:e).options)?{}:o,a=this.normalizeInstanceIdentifier(e.instanceIdentifier);if(this.isInitialized(a))throw Error(this.name+"("+a+") has already been initialized");if(!this.isComponentSet())throw Error("Component "+this.name+" has not been registered yet");var s=this.getOrInitializeService({instanceIdentifier:a,options:o});try{for(var l=n(this.instancesDeferred.entries()),c=l.next();!c.done;c=l.next()){var u=r(c.value,2),p=u[0],f=u[1];a===this.normalizeInstanceIdentifier(p)&&f.resolve(s)}}catch(e){t={error:e}}finally{try{c&&!c.done&&(i=l.return)&&i.call(l)}finally{if(t)throw t.error}}return s},_.prototype.onInit=function(e,t){var n=this.normalizeInstanceIdentifier(t),r=null!==(t=this.onInitCallbacks.get(n))&&void 0!==t?t:new Set;return r.add(e),this.onInitCallbacks.set(n,r),(t=this.instances.get(n))&&e(t,n),function(){r.delete(e)}},_.prototype.invokeOnInitCallbacks=function(e,t){var r,i,o=this.onInitCallbacks.get(t);if(o)try{for(var a=n(o),s=a.next();!s.done;s=a.next()){var l=s.value;try{l(e,t)}catch(e){}}}catch(e){r={error:e}}finally{try{s&&!s.done&&(i=a.return)&&i.call(a)}finally{if(r)throw r.error}}},_.prototype.getOrInitializeService=function(e){var t=e.instanceIdentifier,n=e.options,r=void 0===n?{}:n;if(!(e=this.instances.get(t))&&this.component&&(e=this.component.instanceFactory(this.container,{instanceIdentifier:(n=t)===O?void 0:n,options:r}),this.instances.set(t,e),this.instancesOptions.set(t,r),this.invokeOnInitCallbacks(e,t),this.component.onInstanceCreated))try{this.component.onInstanceCreated(this.container,t,e)}catch(e){}return e||null},_.prototype.normalizeInstanceIdentifier=function(e){return void 0===e&&(e=O),!this.component||this.component.multipleInstances?e:O},_.prototype.shouldAutoInitialize=function(){return!!this.component&&"EXPLICIT"!==this.component.instantiationMode},_);function _(e,t){this.name=e,this.container=t,this.component=null,this.instances=new Map,this.instancesDeferred=new Map,this.instancesOptions=new Map,this.onInitCallbacks=new Map}var N=(C.prototype.addComponent=function(e){var t=this.getProvider(e.name);if(t.isComponentSet())throw new Error("Component "+e.name+" has already been registered with "+this.name);t.setComponent(e)},C.prototype.addOrOverwriteComponent=function(e){this.getProvider(e.name).isComponentSet()&&this.providers.delete(e.name),this.addComponent(e)},C.prototype.getProvider=function(e){if(this.providers.has(e))return this.providers.get(e);var t=new E(e,this);return this.providers.set(e,t),t},C.prototype.getProviders=function(){return Array.from(this.providers.values())},C);function C(e){this.name=e,this.providers=new Map}var S,L=[];function R(e,t){for(var n=[],r=2;r<arguments.length;r++)n[r-2]=arguments[r];if(!(t<e.logLevel)){(new Date).toISOString();var i=k[t];if(!i)throw new Error("Attempted to log a message with an invalid logType (value: "+t+")")}}(D=S=S||{})[D.DEBUG=0]="DEBUG",D[D.VERBOSE=1]="VERBOSE",D[D.INFO=2]="INFO",D[D.WARN=3]="WARN",D[D.ERROR=4]="ERROR",D[D.SILENT=5]="SILENT";var A={debug:S.DEBUG,verbose:S.VERBOSE,info:S.INFO,warn:S.WARN,error:S.ERROR,silent:S.SILENT},P=S.INFO,k=((F={})[S.DEBUG]="log",F[S.VERBOSE]="log",F[S.INFO]="info",F[S.WARN]="warn",F[S.ERROR]="error",F),D=(Object.defineProperty(j.prototype,"logLevel",{get:function(){return this._logLevel},set:function(e){if(!(e in S))throw new TypeError('Invalid value "'+e+'" assigned to `logLevel`');this._logLevel=e},enumerable:!1,configurable:!0}),j.prototype.setLogLevel=function(e){this._logLevel="string"==typeof e?A[e]:e},Object.defineProperty(j.prototype,"logHandler",{get:function(){return this._logHandler},set:function(e){if("function"!=typeof e)throw new TypeError("Value assigned to `logHandler` must be a function");this._logHandler=e},enumerable:!1,configurable:!0}),Object.defineProperty(j.prototype,"userLogHandler",{get:function(){return this._userLogHandler},set:function(e){this._userLogHandler=e},enumerable:!1,configurable:!0}),j.prototype.debug=function(){for(var e=[],t=0;t<arguments.length;t++)e[t]=arguments[t];this._userLogHandler&&this._userLogHandler.apply(this,i([this,S.DEBUG],e)),this._logHandler.apply(this,i([this,S.DEBUG],e))},j.prototype.log=function(){for(var e=[],t=0;t<arguments.length;t++)e[t]=arguments[t];this._userLogHandler&&this._userLogHandler.apply(this,i([this,S.VERBOSE],e)),this._logHandler.apply(this,i([this,S.VERBOSE],e))},j.prototype.info=function(){for(var e=[],t=0;t<arguments.length;t++)e[t]=arguments[t];this._userLogHandler&&this._userLogHandler.apply(this,i([this,S.INFO],e)),this._logHandler.apply(this,i([this,S.INFO],e))},j.prototype.warn=function(){for(var e=[],t=0;t<arguments.length;t++)e[t]=arguments[t];this._userLogHandler&&this._userLogHandler.apply(this,i([this,S.WARN],e)),this._logHandler.apply(this,i([this,S.WARN],e))},j.prototype.error=function(){for(var e=[],t=0;t<arguments.length;t++)e[t]=arguments[t];this._userLogHandler&&this._userLogHandler.apply(this,i([this,S.ERROR],e)),this._logHandler.apply(this,i([this,S.ERROR],e))},j);function j(e){this.name=e,this._logLevel=P,this._logHandler=R,this._userLogHandler=null,L.push(this)}function z(e){L.forEach((function(t){t.setLogLevel(e)}))}var F=((F={})["no-app"]="No Firebase App '{$appName}' has been created - call Firebase App.initializeApp()",F["bad-app-name"]="Illegal App name: '{$appName}",F["duplicate-app"]="Firebase App named '{$appName}' already exists",F["app-deleted"]="Firebase App named '{$appName}' already deleted",F["invalid-app-argument"]="firebase.{$appName}() takes either no argument or a Firebase App instance.",F["invalid-log-argument"]="First argument to `onLog` must be null or a function.",F),T=new p("app","Firebase",F),x="@firebase/app",H="[DEFAULT]",V=((F={})[x]="fire-core",F["@firebase/analytics"]="fire-analytics",F["@firebase/app-check"]="fire-app-check",F["@firebase/auth"]="fire-auth",F["@firebase/database"]="fire-rtdb",F["@firebase/functions"]="fire-fn",F["@firebase/installations"]="fire-iid",F["@firebase/messaging"]="fire-fcm",F["@firebase/performance"]="fire-perf",F["@firebase/remote-config"]="fire-rc",F["@firebase/storage"]="fire-gcs",F["@firebase/firestore"]="fire-fst",F["fire-js"]="fire-js",F["firebase-wrapper"]="fire-js-all",F),B=new D("@firebase/app"),M=(Object.defineProperty(U.prototype,"automaticDataCollectionEnabled",{get:function(){return this.checkDestroyed_(),this.automaticDataCollectionEnabled_},set:function(e){this.checkDestroyed_(),this.automaticDataCollectionEnabled_=e},enumerable:!1,configurable:!0}),Object.defineProperty(U.prototype,"name",{get:function(){return this.checkDestroyed_(),this.name_},enumerable:!1,configurable:!0}),Object.defineProperty(U.prototype,"options",{get:function(){return this.checkDestroyed_(),this.options_},enumerable:!1,configurable:!0}),U.prototype.delete=function(){var e=this;return new Promise((function(t){e.checkDestroyed_(),t()})).then((function(){return e.firebase_.INTERNAL.removeApp(e.name_),Promise.all(e.container.getProviders().map((function(e){return e.delete()})))})).then((function(){e.isDeleted_=!0}))},U.prototype._getService=function(e,t){void 0===t&&(t=H),this.checkDestroyed_();var n=this.container.getProvider(e);return n.isInitialized()||"EXPLICIT"!==(null===(e=n.getComponent())||void 0===e?void 0:e.instantiationMode)||n.initialize(),n.getImmediate({identifier:t})},U.prototype._removeServiceInstance=function(e,t){void 0===t&&(t=H),this.container.getProvider(e).clearInstance(t)},U.prototype._addComponent=function(e){try{this.container.addComponent(e)}catch(y){B.debug("Component "+e.name+" failed to register with FirebaseApp "+this.name,y)}},U.prototype._addOrOverwriteComponent=function(e){this.container.addOrOverwriteComponent(e)},U.prototype.toJSON=function(){return{name:this.name,automaticDataCollectionEnabled:this.automaticDataCollectionEnabled,options:this.options}},U.prototype.checkDestroyed_=function(){if(this.isDeleted_)throw T.create("app-deleted",{appName:this.name_})},U);function U(e,t,n){var r=this;this.firebase_=n,this.isDeleted_=!1,this.name_=t.name,this.automaticDataCollectionEnabled_=t.automaticDataCollectionEnabled||!1,this.options_=o(void 0,e),this.container=new N(t.name),this._addComponent(new I("app",(function(){return r}),"PUBLIC")),this.firebase_.INTERNAL.components.forEach((function(e){return r._addComponent(e)}))}function W(e){var t={},n=new Map,r={__esModule:!0,initializeApp:function(n,i){void 0===i&&(i={}),"object"==typeof i&&null!==i||(i={name:i});var o=i;if(void 0===o.name&&(o.name=H),"string"!=typeof(i=o.name)||!i)throw T.create("bad-app-name",{appName:String(i)});if(d(t,i))throw T.create("duplicate-app",{appName:i});return o=new e(n,o,r),t[i]=o},app:i,registerVersion:function(e,t,n){var r=null!==(i=V[e])&&void 0!==i?i:e;n&&(r+="-"+n);var i=r.match(/\s|\//);e=t.match(/\s|\//),i||e?(n=['Unable to register library "'+r+'" with version "'+t+'":'],i&&n.push('library name "'+r+'" contains illegal characters (whitespace or "/")'),i&&e&&n.push("and"),e&&n.push('version name "'+t+'" contains illegal characters (whitespace or "/")'),B.warn(n.join(" "))):a(new I(r+"-version",(function(){return{library:r,version:t}}),"VERSION"))},setLogLevel:z,onLog:function(e,t){if(null!==e&&"function"!=typeof e)throw T.create("invalid-log-argument");!function(e,t){for(var n=0,r=L;n<r.length;n++)!function(n){var r=null;t&&t.level&&(r=A[t.level]),n.userLogHandler=null===e?null:function(t,n){for(var i=[],o=2;o<arguments.length;o++)i[o-2]=arguments[o];var a=i.map((function(e){if(null==e)return null;if("string"==typeof e)return e;if("number"==typeof e||"boolean"==typeof e)return e.toString();if(e instanceof Error)return e.message;try{return JSON.stringify(e)}catch(e){return null}})).filter((function(e){return e})).join(" ");n>=(null!=r?r:t.logLevel)&&e({level:S[n].toLowerCase(),message:a,args:i,type:t.name})}}(r[n])}(e,t)},apps:null,SDK_VERSION:"8.10.1",INTERNAL:{registerComponent:a,removeApp:function(e){delete t[e]},components:n,useAsService:function(e,t){return"serverAuth"!==t?t:null}}};function i(e){if(!d(t,e=e||H))throw T.create("no-app",{appName:e});return t[e]}function a(a){var s,l=a.name;if(n.has(l))return B.debug("There were multiple attempts to register component "+l+"."),"PUBLIC"===a.type?r[l]:null;n.set(l,a),"PUBLIC"===a.type&&(s=function(e){if("function"!=typeof(e=void 0===e?i():e)[l])throw T.create("invalid-app-argument",{appName:l});return e[l]()},void 0!==a.serviceProps&&o(s,a.serviceProps),r[l]=s,e.prototype[l]=function(){for(var e=[],t=0;t<arguments.length;t++)e[t]=arguments[t];return this._getService.bind(this,l).apply(this,a.multipleInstances?e:[])});for(var c=0,u=Object.keys(t);c<u.length;c++){var p=u[c];t[p]._addComponent(a)}return"PUBLIC"===a.type?r[l]:null}return r.default=r,Object.defineProperty(r,"apps",{get:function(){return Object.keys(t).map((function(e){return t[e]}))}}),i.App=e,r}M.prototype.name&&M.prototype.options||M.prototype.delete,F=function e(){var n=W(M);return n.INTERNAL=t(t({},n.INTERNAL),{createFirebaseNamespace:e,extendNamespace:function(e){o(n,e)},createSubscribe:v,ErrorFactory:p,deepExtend:o}),n}();var G=($.prototype.getPlatformInfoString=function(){return this.container.getProviders().map((function(e){return function(e){return"VERSION"===(null==(e=e.getComponent())?void 0:e.type)}(e)?(e=e.getImmediate()).library+"/"+e.version:null})).filter((function(e){return e})).join(" ")},$);function $(e){this.container=e}"object"==typeof self&&self.self===self&&void 0!==self.firebase&&(B.warn("\n    Warning: Firebase is already defined in the global scope. Please make sure\n    Firebase library is only loaded once.\n  "),(D=self.firebase.SDK_VERSION)&&0<=D.indexOf("LITE")&&B.warn("\n    Warning: You are trying to load Firebase while using Firebase Performance standalone script.\n    You should load Firebase Performance with this instance of Firebase to avoid loading duplicate code.\n    "));var K=F.initializeApp;F.initializeApp=function(){for(var e=[],t=0;t<arguments.length;t++)e[t]=arguments[t];return function(){try{return"[object process]"===Object.prototype.toString.call(global.process)}catch(e){return}}()&&B.warn('\n      Warning: This is a browser-targeted Firebase bundle but it appears it is being\n      run in a Node environment.  If running in a Node environment, make sure you\n      are using the bundle specified by the "main" field in package.json.\n      \n      If you are using Webpack, you can specify "main" as the first item in\n      "resolve.mainFields":\n      https://webpack.js.org/configuration/resolve/#resolvemainfields\n      \n      If using Rollup, use the @rollup/plugin-node-resolve plugin and specify "main"\n      as the first item in "mainFields", e.g. [\'main\', \'module\'].\n      https://github.com/rollup/@rollup/plugin-node-resolve\n      '),K.apply(void 0,e)};var Y,J=F;return(Y=J).INTERNAL.registerComponent(new I("platform-logger",(function(e){return new G(e)}),"PRIVATE")),Y.registerVersion(x,"0.6.30",void 0),Y.registerVersion("fire-js",""),J.registerVersion("firebase","8.10.1","app"),J.SDK_VERSION="8.10.1",J},"object"==typeof exports&&"undefined"!=typeof module?module.exports=I():"function"==typeof define&&define.amd?define(I):(y="undefined"!=typeof globalThis?globalThis:y||self).firebase=I();
});
__maRoute='app';require("app.js");
__maRoute='pages/index/index';require("pages/index/index.js");
