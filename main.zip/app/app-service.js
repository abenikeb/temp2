var __maAppData=__maAppData||{};
var __maRoute=__maRoute||"";
var __layer__='service';
var __maAppCode__=__maAppCode__||{};
var global=global||{};
var __MAML_GLOBAL__=__MAML_GLOBAL__||{entrys:{},defines:{},modules:{},sjs_init:false}; 
var Component=Component||function(){};
var __maI18nResource__=__maI18nResource__||{};
(function (i18nRes) {
  // Merge i18n resource in subpackage scenario
  var newI18nRes={"am":{"choose_delevery_type":"የመርክቢያ መንገድዎን ይምረጡ","phone_verification":"ማረጋገጫ ቁጥር ያስገቡ","enter_phone_number":"የስልክ ቁጥር ያስገቡ","enter_code":"ወደ ስልክዎ የሚላከውን ሚስጥር ቁጥር ያስገቡ","menu":"ማውጫ","loan_balance":"የብድር ቀሪ ሂሳብ","first_string":"አበበ","second_string":"ከበደ","you_can_change_language_after1":"ቋንቋውን ወደ መዋቅሩ ሲገቡ ለመቀየር ይችላሉ","you_can_change_language_after":"ቋንቋውን ወደ ቅንብሩ ከገቡ በኋላ መቅየር ይችላሉ።","anything_you_need_at_your_finger_tips":"የሚሹትን ነገር  ቅርብዎ እንዲያገኙ እናደርጋለን","real_discount_from_packages":"ተመጣጣኝ ቅናሽ በየጥቅሉ ላይ ማድረጋችንን እርግጠኞች ነን","delivered_to_your_door":"እበርዎ ድረስ  እናቀርብሎታለን","get_started":"መነሻዎ ይሄ ነው","name":"ስም","price":"የዕቃው ዋጋ","detail":"የምርቱ ዝርዝር ሁኔታ","delivery_type":"ያሉበእት ቦታ የምናደርስበት ዘዴ","total_price":"ጠቅላላ ሂሳብ","order_date":"የታዘዘበት ዕለት","birr":"ብር","product_added":"እቃው ተጨምሯል","product_added_description1":"ምርቱ ወደ ቅርጫትዎ ስለመግባቱ \nምርቱ ወደ ቅርጫትዎ ስለመከተቱ  መግለጫ ወይም ማብራሪያ፣ ምርመራ","product_added_description":"ወደ ቅርጫትዎ ተጨምሯል","product_removed1":"ምርቱ ተቀንሷል\nምርቱ ከቅርጫትዎ ወጥቷል\nምርቱ ከቅርጫትዎ ተነስቷል\nምርቱ ከቅርጫትዎ እንዲቀነስ ተደርጓል  ","product_removed":"እቃው ተቀንሷል","product_removed_description1":"ምርቱ ስለመቀነሱ \nምርቱ ከቅርጫትዎ ስለመውጣቱ\nምርቱ ከቅርጫትዎ ስለመነሳቱ\nምርቱ ከቅርጫትዎ እንዲቀነስ ስለመደረጉ  መግለጫ ወይም ማብራሪያ፣ ምርመራ","product_removed_description":"ከቅርጫትዎ ተቀንሷል","package_added":"ጥቅሉ ወደ ቅርጫትዎ ታክሏል","package_added_description":"ጥቅሉ በጭማሪነት ወደ ቅርጫትዎ ስለመግባቱ  መግለጫ ","package_removed":"ጥቅሉ እንዲቀነስ ተደርጓል","package_removed_description":"እሽጉ ስለመቀነሱ መግለጫ ወይም ማብራሪያ፣ ምርመራ","try_again_later":"በድጋሚ ይሞክሩ","something_went_wrong":"የተወሰነ ችግር  ተፈጥሯል ","connection_error1":"የመገናኛ መስመር ስህተት አለ\nየመገናኛ መስመር ችግር አለ\nየመገናኛ መስመር ህፀፅ ይታያል","connection_error":"የመገናኛ መስመር ስህተት","check_internet_connection":"የመገናኛ መስመርዎ በትክክል መኖር አለመኖሩን ያጣሩ","you_ve_logged_out":"ከመገልገያው መድረክ  ውጪ ነዎት","hope_to_see_you_soon":"በድጋሚ እንደምናገኝዎ ተስፋ አለን","profile_edit_successful":"ያካሄዱት እርማት ስኬታማ ነው","profile_edit_successful_description":"የዕርማትዎ መግለጫ ስኬታማ ነው ","added_to_wish_list1":"ከሚሹት ዕቃ ዝርዝር ወደ መፈለጊያው ሠሌዳ ገብተዋል \n/መፈለጊያው አውድ ውስጥ ገብተዋል።","added_to_wish_list":"ወደ ተወዳጅ ዕቃ ዝርዝር አስገብተዋል","added_to_wish_list_description":"የሚሹትን ዕቃ ዝርዝር መግለጫ","removed_from_wish_list1":"ከሚሹት ዕቃ ዝርዝር  ሠሌዳ ወጥተዋል \n/ከሚሹት ዕቃ ከመፈለጊያው  አውድ ወጥተዋል ።","removed_from_wish_list":"ከተወዳጅ ዕቃ ዝርዝር አስወጥተዋል","removed_from_wish_list_description":"ከሚሹትን ዕቃ ዝርዝር መግለጫ ሠሌዳ ወጥተዋል","cart":"ዘንቢል","no_items_in_cart":"በዘንቢልዎ ውስጥ ምንም እቃዎች የለም","no_items_in_cart_description":"ለመግዛት ከፈለጉ እቃዎችን ወደ ዘንቢልዎ ያስገቡ","checkout":"ግዢውን ይፈጽሙ","checkout_second":"ዳግመኛ ግዢ ያካሂዱ","sub_total":"ከፊል ድምር","tax":"ታክስ","delivery":"አቅርቦት","next_page":"ቀጣዩን ገጽ ይመልከቱ","total":"ጠቅላላ ድምር","shop_by_suppliers":"በምርቱ አቅራቢዎች መገበያየት","skip":"ዝለል","no_items_via_this_filter":"ያሹት ዕቃ ዓይነት የለም","no_products":"ማናቸውም ዕቃ ለጊዜው የለንም","all":"ሁሉም ዕቃ ","basic_info":"መሰረታዊ መረጃ","next":"ይቀጥሉ","convenience":"ምቾት","delivered_in_one_week":"በ1 ሣምንት ጊዜ ውስጥ የምናቀብልዎ","basic":"መሰረታዊ","delivered_in_business_days1":"ከሁለት እስከ ሦስት የሥራ ቀን (የሥራ ቀናት) ቅስጥ የሚረከቡት","delivered_in_business_days":"ከ2 እስከ 3 የስራ ቀን የሚደረስ","seregela_fast":"ሰረገላ ፈጣን","delivered_in_one_day":"የሚረከቡት","payment":"ክፍያ","credit":"ክሬዲት","others":"ሌሎች","choose_payment_method":"የሚፈልጉትን ክፍያ ዓይነት ይምረጡ","request_more":"ተጨማሪ ይጠይቁ","before_purchase":"ከመግዛቶ በፊት","after_purchase":"ከግዢ በኋላ","finish":"ጨርስ","not_corporate":"የኮርፖሬቱ አባል አይደሉም","not_corporate_description":"የድርጅት መለያ እንደሚያስፈልግዎ ይወቁ","no_loan_balance":"የብድር ቀሪ ሂሳብ ሊኖርዎ ይገባል","no_loan_balance_description":"የብድር ቀሪ ሂሳብ እንደሌለዎ መግለጫ","insufficient_balance":"ሂሳብዎ በቂ አይደለም","insufficient_balance_description":"ሂሳብዎ በቂ አይደለም መግለጫ","pay_with_credit1":"በታሳቢ ይክፈሉ","pay_with_credit":"በብድር ይክፈሉ","pay_the_difference":"ቀሪውን በሌላ መንገድ ይክፈሉ","pay_the_difference1":"ቀሪውን ልዩነት በሌላ ዘዴ ይክፈሉ\nቀሪውን ልዩነት በሌላ ዘዴ መክፈል ይችላሉ","you_can_pay_with_credit_if_you_have_corporate_id":"የኮርፖሬት አባልነት መታወቂያ ካለዎ በብድር መክፈል ይችላሉ","pay_with_others":"በሌሎች መንገዶች ይክፈሉ","telebirr_awashbirr_cbebirr":"ቴሌብር ፣ አዋሽብር ፣ ሲቢኢ ብር","cbebirr":"ሲቢኢ ብር","cbe_mobile_banking":"ሲቢኢ","have_your_phone_in_your_hand":"ስልክዎን በእጅዎ ይያዙ","steps_tofollow_cbe_mobile_banking":"የሲቢኢ የስልክ መተግበሪያ ወይም *889# መመሪያዎች","enter_your_pin":"የሲቢኢ የስልክ መተግበሪያ የምስጢር ቁጥር ያስገቡ","navigate_utilities1":"ለ navigate towards the \"Utilities\" ፈቃድ ከሰጡ በኋላ ሠረገላ ገባያን ይምረጡ","navigate_utilities":"ወደ ሲቢኢ ከገቡ በኋላ \"Utilities\" ውስጥ በመግባት ሠረገላ ገባያን ይምረጡ","enter_order_id":"ከዚህ በታች የተመለከውን የትዕዛዝ መለያ ቁጥር ያስገቡ","press_the_button_below":"ክፍያዎን ከጨረሱ በኋላ ከዚህ በታች የተመለከውን ይቀጥሉን ይጫኑ","cbe_card_pay":"ሲቢኢ ካርድ ፔይ","approve_delivery":"ማድረሻ ማረጋገጫ","approve_delivery1":"በትክክል እንደደረስዎ ማረጋገጫ","approve_and_pay":"እርግጠኛ ሲሆኑ ይክፈሉ","approve":"እርግጠኛ ይሁኑ","approve_title":"ማረጋገጫ","cancel":"ይሰረዝ","product_ordered_successfully":"በታዕዛዝዎ ስኬታማ ይሁኑ","go_home":"ወደ መነሻ ገጽ ያምሩ","go_to_home_page":"ወደ መጀመሪያ ገጽ ይመለሱ","yes":"አዎ\nአይደለም/ በእምቢታ መልሰዋል\nአዎንታ\nአሉታ","no":"አይ","edit_profile":"የተጠቃሚ መረጃ ማስተካከያ","delete_profile":"የተጠቃሚ መረጃ ያስወግዱ","what_do_you_need":"ምን ይሻሉ?","take_your_groceries2":"የገዟቸውን ቁሶች ይውሰዱ","take_your_groceries":"አስቤዛዎን ይውሰዱ","pay_later":"በኋላ ይክፈሉ ","learn_more":"የበለጠ ያውቁ ዘንድ","categories":"ተጨማሪ ክፍሎች","frequently_purchased_items":"በየጊዜው የተገዙ ተወዳጅ ዕቃዎች","packages":"እሽጎች","for_you":"ለእርስዎ ብቻ የተመረጡ","more1":"ታካይ ዝርዝሮች","more":"ተጨማሪ","language":"ቋንቋ","amharic":"አማርኛ","english":"እንግሊዝኛ","help_center2":"የእገዛ እልፍኝ","help_center":"የእርዳታ ማዕከል","problem_try_again_later":"ችግር አለ፤ ዳግመኛ ይሞክሩ","order_list":"የትዕዛዝዎ ቅደም ተከተል","orders":"ትዕዛዞችዎ","notifications":"ማሳሰቢያዎች","couldnt_fetch_notifications":"ማሳሰቢያዎችን ማግኘት አልተቻለም","settings":"ውስጠ-ነገራት","change_password1":"የግል ሚስጥር ቁጥርን መለወጫ\nየሚስጥር ቁጥርዎን ቁልፍ ይጫኑ","change_password":"የሚስጥች ቁጥር መቀየሪያ","back":"ይመለሱ","left_in_stock":"ከክምችት የቀሩ","out_of_stock":"ከመጋዘን ያለቀ ዕቃ ","not_available_in_stock":"መጋዘናችን ውስጥ ለጊዜው የሌለ","add_to_cart":"ጋሪ ላይ ይጫኑ","description":"ዝርዝር ማብራሪያ","wish_list":"የሚሹትን ዕቃ ማሳያ ቅደም-ተከተል","no_items_in_wish_list":"ምንም ዕቃ ያሹት የቅደም-ተከተል አልጨመሩም","password_change_successful":"የሚስጥር ቁጥርዎን ቀይረዋል?","password_change_successful_description":"የሚስጥር ቁጥርዎን በትክክል ቀይረዋል","change":"እንዲለወጥ ይዘዙ\nእንዲቀየር ይዘዙ","login":"ወደ መገልገያዎ እንዲገባ ይዘዙ","forgot_password":"የሚስጥር ቁጥርዎን ዘንግተዋል?","new_to_seregela_majet":"ለሠረገላ ገባያ እንግዳ ነዎት?","login_successful1":"ወደ ዋናው መገልገያ መድረክ በመግባት ስኬታማ ሆነዋል\nወደ ዋናው መገልገያ ሰሌዳ እንኳን ደህና መጡ!","login_successful":"ወደ ዋና መጠቀሚያው ገብተዋል","login_successful_description":"የስኬትዎ መግለጫ እነሆ","personal_info":"ግል-መረጃዎ\nስለራስዎ እነሆ\nራስዎን ያስተዋውቁ","this_information_is_needed_for_delivery_service":"ይህ መረጃ ባቅርቦት አገልግሎት ዋና ፋይዳ ያለው ነው","register1":"በሁነኛ መልኩ ይመዝገቡ\nከዚህ ቀደም የሠረገላ አባል ሆነው ያውቃሉ?/ነበሩ?","register":"ይመዝገቡ","already_a_member":"የሰረገላ ገበያ አባል ነዎት?","registration_successful":"በትክክል  ተመዝግበዋል","log_in":"ወደ ገበታው ይግቡ","log_out":"ከገበታው ይውጡ","home":"መግቢያ","email_hint":"የኢሜል አድራሻ ኣለም አቀፍ መገናኛ አድራሻ","email_error":"የተሳሳተ የኢሜል አድራሻ ተጠቅመዋል","password_hint":"የሚስጥር መለያ ቁጥር","password_empty1":"የሚስጥር መለያ ቁጥር መሙላት አለብዎ\nመሙያው ቦታ ላይ ምንም ቁጥር አላስገቡም","password_empty":"የሚስጥር ቁጥር መሙላት አለብዎ","old_password_hint":"ይህ የዱሮ ሚስጥር ቁጥርዎ ነው","old_password_empty":"የዱሮ ሚስጥር ቁጥርዎን ያስገቡ","new_password_hint":"አዲሱ ሚስጥር ቁጥር የራስዎ መሆኑን ያረጋግጡ","new_password_empty":"አዲስ ሚስጥር ቁጥር ማረጋገጫ ማስገባት አለብዎት","password_confirm_hint":"ቁጥርዎ ከላይ ካስገቡት አዲስ የሚስጥር ጋር መመሳሰሉን ያረጋገጡ","password_confirm_empty":"አዲስ ሚስጥር ቁጥር ማረጋገጫ ማስገባት አለብዎ","password_confirm_error":"ከላይ ካስገቡት አዲስ የሚስጥር ቁጥር ጋር አይመሳሰልም","user_name_hint1":"የተጠቃሚው ከሚለው ቦታ ፊትለፊት ስም/ ስሞትን ይሙሉ\nየተገልጋዩ ስም በሚለው ቦታ ይሙሉ","user_name_hint":"የተተቃሚ ስም","user_name_empty":"ምንም ዓይነት ባዶ ስፍራ አይተዉ","user_name_error":"ምንም አይነት ክፍተት አይጠቀሙ","first_name_hint":"የመጀመሪያ ስም","first_name_empty":"የመጀመሪያ ስም መግባት አለበት","last_name_hint":"የአባት ስም","last_name_empty":"የአባት ስም መሙላት ግዴታ ነው","phone_no_hint":"ስልክ ቁጥርዎን ያስገቡ","phone_no_empty":"የስልክ ቁጥርዎን መሙላት ይኖርቦታል","phone_no_error":"ትክክለኛ ስልክ ቁጥር አልሞሉም በሚከተለው ዓይነት ይሙሉ\n2519XXXXXXXX","password_length_error":"ስምንት ውይም ከስምንት በላይ አሐዝ መጠቀም ይኖርቦታል","city_hint":"ከተማ","city_empty":"ከተማውን መሙላት አለብዎት","sub_city_hint":"ክፍለ ከተማ","sub_city_empty":"ክፍለ ከተማውን መሙላት አለብዎት","woreda_hint":"ወረዳ እዚህጋ ይገባል","woreda_empty":"ወረዳዎትን ይሙሉ ወረዳዎን እዚህ ቦታ ይጻፉ","neighborhood_hint":"ሰፈር እዚህጋ ይጻፉ","neighborhood_empty":"ሰፈርዎን እዚህጋ ይሙሉ","house_no_hint":"የቤት ቁጥርዎን እዚህ ያስፍሩ","house_no_empty":"የቤት ቁጥርዎ አስፈላጊ ነው","quantity":"ብዛት","seregela":"ሠረገላ","majet":"ገበያ","invalid_phone_number":"እባክዎን ትክክለኛ ቁጥርዎን ያስገቡ","pay":"ይክፈሉ","payment_unsuccessful":"ክፍያ አላጠናቀቁም","process_service_request_successfully":"ትዕዛዝዎ በተሳካ ሁኔታ ተሳክቷል","payment_successful":"ክፍያዎ ተሳክቷል","customer_canceled_or_session_time_out":"ደንበኛው አቋርጣል ፤ ጊዜ አልቋል","payment_unsuccessful_description":"ክፍያ እንዳጠናቀቁ እርግጠኛ ከሆኑ ወደ እርዳታ ማዕከል በመደወል ያረጋግጡ","low_order_cost_for_seregela_fast":"ያዘዙት ክፍያ መጠን ለሰረገላ ፈጣን አይሆንም","low_order_cost_for_basic":"ያዘዙት ክፍያ መጠን ለሰረገላ መሰረታዊ አይሆንም","low_order_cost_for_convenience":"ያዘዙት ክፍያ መጠን ለሰረገላ ምቾት አይሆንም","low_Order_cost_for_seregela_fast_description":"የሰረገላ ፈጣንን ማድረሻ መንገድ ለመጠቀም ያዘዙት ክፍያ መጠን ከ500 ብር በላይ መሆን አለበት","low_Order_cost_for_basic_description":"የሰረገላ መሰረታዊ ማድረሻ መንገድ ለመጠቀም ያዘዙት ክፍያ መጠን ከ500 ብር በላይ መሆን አለበት","low_Order_cost_for_convenience_description":"የሰረገላ ምቾት ማድረሻ መንገድ ለመጠቀም ያዘዙት ክፍያ መጠን ከ500 ብር በላይ መሆን አለበት","Initiator_authentication_error":"ማረጋገጫ ስህተት አጋጥሟል","identifier_does_not_exist":"የCBE birr አካውንት የሎትም","transaction_amount_should_not_be_less_than_10_birr":"የመግዣ ዋጋ ከ10 ብር ማነስ የለበትም","balance_insufficient":"ቀሪ  ሒሳብዎ አነስተኛ ነው","successful_proceess_response":"Transaction successful","error_occured_due_to_client_provided_wrong_data":"Error occured due to client provided wrong data","api_service_is_not_responding":"api service is not responding","customer_provided_wrong_information":"customer provided wrong information","continue":"ይቀጥሉ","payment_finished_cbe_birr":"ስልኮት ላይ የCBE Birr መክፈያ ይመጣል።  ክፍያ ሲጨርሱ እባኮት ከስር ያለውን በመጫን ይቀጥሉ።","payment_finished_cbe":"ስልኮት ላይ የCBE መክፈያ ይመጣል።  ክፍያ ሲጨርሱ እባኮት ከስር ያለውን በመጫን ይቀጥሉ።","too_many_requests":"Too many requests"},"en":{"first_string":"Abebe","second_string":"Kebede","you_can_change_language_after":"You can change language after loggedIn.","anything_you_need_at_your_finger_tips":"Anything you need at your finger tips","real_discount_from_packages":"Real discount from Packages","delivered_to_your_door":"Delivered to your Door","get_started":"Get Started","name":"Name","enter_phone_number":"Enter Phone Number","enter_code":"Enter the code sent by sms to you","phone_verification":"Phone Verification","verification_code_sent_to":"verification cede sent to","choose_delevery_type":"Choose delevery type","price":"Price","detail":"Detail","delivery_type":"Delivery Type","total_price":"Total Price","order_date":"Order Date","birr":"Birr","product_added":"Product Added","product_added_description":"have been added to cart","product_removed":"Product Removed","product_removed_description":"have been removed from cart","package_added":"Package Added","package_added_description":"have been added to cart","package_removed":"Package Removed","package_removed_description":"have been removed from cart","try_again_later":"Try again later","something_went_wrong":"Something went wrong","connection_error":"Connection error","check_internet_connection":"Check your internet connection","you_ve_logged_out":"You've logged out","hope_to_see_you_soon":"Hope to see you soon","profile_edit_successful":"Profile edit successful","profile_edit_successful_description":"Your profile have successfully been edited","added_to_wish_list":"Added to wish list","added_to_wish_list_description":"have been added to wish list","removed_from_wish_list":"Removed from wish list","removed_from_wish_list_description":"have been removed from wish list","cart":"Cart","no_items_in_cart":"No items in your cart","no_items_in_cart_description":"You have to add products in your cart to checkout","checkout":"Checkout","checkout_second":"checkout","sub_total":"Sub total","tax":"Tax","delivery":"Delivery","next_page":"next page","total":"Total","shop_by_suppliers":"Shop by suppliers","skip":"Skip","menu":"Menu","no_items_via_this_filter":"No items via this filter","no_products":"No Products","all":"All","basic_info":"Basic Info","next":"Next","convenience":"Convenience","delivered_in_one_week":"Delivered in 1 week","basic":"Basic","delivered_in_business_days":"Delivered in 2 to 3 business days","seregela_fast":"Seregela fast","delivered_in_one_day":"Delivered in 1 day","payment":"Payment","credit":"Credit","others":"Others","choose_payment_method":"Choose payment method","request_more":"Request more","before_purchase":"Before purchase","after_purchase":"After purchase","finish":"Finish","not_corporate":"Not Corporate","not_corporate_description":"To use pay with credit feature, you have to have a corporate id","no_loan_balance":"No loan balance","loan_balance":"Loan Balance","no_loan_balance_description":"You have no loan balance to make the purchase","insufficient_balance":"Insufficient balance","insufficient_balance_description":"Your balance is insufficient. Your balance: ","pay_with_credit":"Pay with credit","pay_the_difference":"Pay the difference with other methods","you_can_pay_with_credit_if_you_have_corporate_id":"You can pay with credit if you have corporate id","pay_with_others":"Pay with others","telebirr_awashbirr_cbebirr":"Telebirr, Awashbirr, CBEbirr","cbebirr":"CBE Birr","cbe_mobile_banking":"CBE Mobile Banking","have_your_phone_in_your_hand":"Have your phone in your hand","steps_tofollow_cbe_mobile_banking":"Steps to follow when inside the CBE Mobile Banking  or *889#","enter_your_pin":"Enter your pin","navigate_utilities":"After gaining access navigate towards the \"Utilities\" menu select Seregela Gebeya","enter_order_id":"Enter the order id displayed below","press_the_button_below":"After completing the payment press the button below to continue","cbe_card_pay":"CBE Card pay","approve_delivery":"Approve Delivery","approve_and_pay":"Approve and Pay","approve":"Approve","approve_title":"Approve","cancel":"Cancel","product_ordered_successfully":"Products ordered successfully","go_home":"Go home","go_to_home_page":"Go to home page?","yes":"Yes","no":"No","edit_profile":"Edit profile","delete_profile":"Delete Account","what_do_you_need":"What do you need?","what_are_you_looking_for":"What are you looking for?","take_your_groceries":"Take your groceries","pay_later":"Pay later","learn_more":"Learn more","categories":"Categories","frequently_purchased_items":"Frequently purchased items","packages":"Packages","for_you":"For you","more":"More","language":"Language","amharic":"Amharic","english":"English","help_center":"Help Center","problem_try_again_later":"There seems to be a problem. Try again later.","order_list":"Orders list","orders":"Orders","notifications":"Notifications","couldnt_fetch_notifications":"Couldn't fetch notifications","settings":"Settings","change_password":"Change password","back":"Back","left_in_stock":"Left in stock","out_of_stock":"Out of stock","not_available_in_stock":"is not available in stock at the moment","add_to_cart":"Add to cart","description":"Description","wish_list":"Wish List","no_items_in_wish_list":"No items in wish list","password_change_successful":"Password change successful","password_change_successful_description":"You have successfully changed your password","change":"Change","login":"Login","forgot_password":"Forgot password?","new_to_seregela_majet":"New to Seregela Gebeya?","login_successful":"Login Successful","login_successful_description":"Welcome to Seregela Gebeya!","personal_info":"Personal Information","this_information_is_needed_for_delivery_service":"This information is needed for delivery service","register":"Register","already_a_member":"Already a member?","registration_successful":"Registration Successful","log_in":"LogIn","log_out":"LogOut","home":"Home","email_hint":"Email","email_error":"Incorrect email address (*****@*****.com)","password_hint":"Password","password_empty":"Fill your password","old_password_hint":"Old Password","old_password_empty":"Fill your old password","new_password_hint":"New Password","new_password_empty":"Fil your new password","password_confirm_hint":"Confirm Password","password_confirm_empty":"You need to confirm your password","password_confirm_error":"Password confirmation is wrong","user_name_hint":"User Name","user_name_empty":"Fill your username","user_name_error":"No space is allowed","first_name_hint":"First Name","first_name_empty":"Fill your first name","last_name_hint":"Last Name","last_name_empty":"Fill your last name","phone_no_hint":"Phone Number","phone_no_empty":"Fill your phone number","phone_no_error":"Phone format not correct(2519********)","password_length_error":"8 or more characters","city_hint":"City","city_empty":"Fill your city","sub_city_hint":"Sub-city","sub_city_empty":"Fill your sub-city","woreda_hint":"Woreda","woreda_empty":"Fill your woreda","neighborhood_hint":"Neighborhood","neighborhood_empty":"Fill your neighborhood","house_no_hint":"House Number","house_no_empty":"Fill your house number","quantity":"Quantity","seregela":"Seregela","majet":"Gebeya","invalid_phone_number":"Invalid phone number","pay":"Pay","payment_unsuccessful":"Payment unsuccessful","payment_successful":"Payment Successful","process_service_request_successfully":"Payment Successful","customer_canceled_or_session_time_out":"Customer canceled or session time out","payment_unsuccessful_description":"Payment was unsuccessful. If you are certain you made the payment, call the help center for verification. ","low_order_cost_for_seregela_fast":"Low order cost for seregela fast","low_Order_cost_for_seregela_fast_description":"You can only use seregela fast for order cost higher than 500 birr","low_order_cost_for_basic":"Low order cost for seregela basic","low_Order_cost_for_basic_description":"You can only use seregela basic for order cost higher than 500 birr","low_order_cost_for_convenience":"Low order cost for seregela convenience","low_Order_cost_for_convenience_description":"You can only use seregela convenience for order cost higher than 500 birr","Initiator_authentication_error":"Initiator authentication error","identifier_does_not_exist":"Identifier does not exist","transaction_amount_should_not_be_less_than_10_birr":"transaction amount should not be less than 10 birr","balance_insufficient":"Balance Insufficient","successful_proceess_response":"Transaction successful","error_occured_due_to_client_provided_wrong_data":"Error occured due to client provided wrong data","api_service_is_not_responding":"api service is not responding","customer_provided_wrong_information":"customer provided wrong information","continue":"Continue","payment_finished_cbe":"A popup will be sent to your phone. when you finish paying on CBE please press the button below to continue","payment_finished_cbe_birr":"A popup will be sent to your phone. when you finish paying on CBE birr please press the button below to continue","too_many_requests":"Too many requests"}};
  for(var locale in newI18nRes){
    if(i18nRes[locale]){
      for(var key in newI18nRes[locale]){
        i18nRes[locale][key] = newI18nRes[locale][key];
      }
    }else{
      i18nRes[locale]=newI18nRes[locale];
    }
  }
})(__maI18nResource__)

/* maml-transpiler v0.0.20 2022-09-23 20:04:41 */
window.__maml_transpiler_version__='v0.0.20'
var $gmac,$gaic={}
$gma=function(path,global){
  if(typeof global==='undefined')global={};
  function _ac(parent,child){if(typeof(child)!='undefined')parent.children.push(child);} // appendChild
  function _cvn(key){ // createVirtualNode
    if(typeof(key)!='undefined')return {tag:'virtual','maKey':key,children:[]};
    return {tag:'virtual',children:[]};
  }
  function _ctn(tag){ // createTagNode
    $gmac++;
    if($gmac>=16000) throw 'Dom count exceeds maximum 16000.';
    return {tag:tag.substr(0,3)=='ma-'?tag:'ma-'+tag,attr:{},children:[],n:[]}
  }
  function _rtw(msg){console.warn("[MAML runtime warn][$gma] "+msg)} // runtimeWarn
  $gmal={warn:console.warn,info:console.log,error:console.error}
  function $gmah(){
    function fn(){}
    fn.prototype={
      hn:function(obj){ // object has new value
        if(typeof(obj)=='object'){
          var cnt=0,any=false;
          for(var x in obj){
            any|=x==='__value__';
            cnt++;
            if(cnt>2)break;
          }
          return cnt==2&&any&&obj.hasOwnProperty('__maspec__');
        }
        return false;
      },
      nh:function(obj,special){ // new has new value object
        return {__value__:obj,__maspec__:special?special:true}
      },
      rv:function(obj){ // readValue
        return this.hn(obj)?this.rv(obj.__value__):obj;
      }
    }
    return new fn;
  }
  mah=$gmah();
  function $gstack(s){
    var t=s.split('\n '+' '+' '+' ');
    for(var i=0;i<t.length;++i){
      if(0==i) continue;
      if(")"===t[i][t[i].length-1])
      t[i]=t[i].replace(/\s\(.*\)$/,"");
      else t[i]="at anonymous function";
    }
    return t.join('\n '+' '+' '+' ');
  }
  function $gdc(o,p,r){ // deep copy
    o=mah.rv(o);
    if(o===null||o===undefined) return o;
    if(o.constructor===String||o.constructor===Boolean||o.constructor===Number) return o;
    if(o.constructor===Object){
      var copy={};
      for(var key in o){
        if(o.hasOwnProperty(key))copy[undefined===p?key.substring(4):p+key]=$gdc(o[key],p,r);
      }
      return copy;
    }
    if(o.constructor===Date){
      var copy=new Date();
      copy.setTime(o.getTime());
      return copy;
    }
    if(o.constructor===Array){
      var copy=[];
      for(var index=0;index<o.length;index++)copy.push($gdc(o[index],p,r));
      return copy;
    }
    if(r&&o.constructor===Function){
      if (r==1)return $gdc(o(),undefined,2);
      if (r==2)return o;
    }
    if(o.constructor===RegExp){
      var m="";
      if(o.global)m+="g";
      if(o.ignoreCase)m+="i";
      if(o.multiline)m+="m";
      return new RegExp(o.source,m);
    }
    return null;
  }
  function $gmart(should_pass_type_info){
    function arithmeticEval(ops,e,s,g,o){
      var rop=ops[0][1],_f=false;
      var _a,_b,_c,_d,_aa,_bb;
      switch(rop){
        case '?:':
          _a=rev(ops[1],e,s,g,o,_f);
          _c=should_pass_type_info&&mah.hn(_a);
          _d=mah.rv(_a)?rev(ops[2],e,s,g,o,_f):rev(ops[3],e,s,g,o,_f);
          _d=_c&&!mah.hn(_d)?mah.nh(_d,'c'):_d;
          return _d;
        case '&&':
          _a=rev(ops[1],e,s,g,o,_f);
          _c=should_pass_type_info&&mah.hn(_a);
          _d=mah.rv(_a)?rev(ops[2],e,s,g,o,_f):mah.rv(_a);
          _d=_c&&!mah.hn(_d)?mah.nh(_d,'c'):_d;
          return _d;
        case '||':
          _a=rev(ops[1],e,s,g,o,_f);
          _c=should_pass_type_info&&mah.hn(_a);
          _d=mah.rv(_a)?mah.rv(_a):rev(ops[2],e,s,g,o,_f);
          _d=_c&&!mah.hn(_d)?mah.nh(_d,'c'):_d;
          return _d;
        case '+':case '*':case '/':case '%':case '|':case '^':case '&':case '===':case '==':case '!=':case '!==':case '>=':case '<=':case '>':case '<':case '<<':case '>>':
          _a=rev(ops[1],e,s,g,o,_f);
          _b=rev(ops[2],e,s,g,o,_f);
          _c=should_pass_type_info&&(mah.hn(_a)||mah.hn(_b));
          switch(rop){
            case '+':
              _d=mah.rv(_a)+mah.rv(_b);
              break;
            case '*':
              _d=mah.rv(_a)*mah.rv(_b);
              break;
            case '/':
              _d=mah.rv(_a)/mah.rv(_b);
              break;
            case '%':
              _d=mah.rv(_a)%mah.rv(_b);
              break;
            case '|':
              _d=mah.rv(_a)|mah.rv(_b);
              break;
            case '^':
              _d=mah.rv(_a)^mah.rv(_b);
              break;
            case '&':
              _d=mah.rv(_a)&mah.rv(_b);
              break;
            case '===':
              _d=mah.rv(_a)===mah.rv(_b);
              break;
            case '==':
              _d=mah.rv(_a)==mah.rv(_b);
              break;
            case '!=':
              _d=mah.rv(_a)!=mah.rv(_b);
              break;
            case '!==':
              _d=mah.rv(_a)!==mah.rv(_b);
              break;
            case '>=':
              _d=mah.rv(_a)>=mah.rv(_b);
              break;
            case '<=':
              _d=mah.rv(_a)<=mah.rv(_b);
              break;
            case '>':
              _d=mah.rv(_a)>mah.rv(_b);
              break;
            case '<':
              _d=mah.rv(_a)<mah.rv(_b);
              break;
            case '<<':
              _d=mah.rv(_a)<<mah.rv(_b);
              break;
            case '>>':
              _d=mah.rv(_a)>>mah.rv(_b);
              break;
            default:
              break;
          }
          return _c?mah.nh(_d,"c"):_d;
        case '-':
          _a=ops.length===3?rev(ops[1],e,s,g,o,_f):0;
          _b=ops.length===3?rev(ops[2],e,s,g,o,_f):rev(ops[1],e,s,g,o,_f);
          _c=should_pass_type_info&&(mah.hn(_a)||mah.hn(_b));
          _d=_c?mah.rv(_a)-mah.rv(_b):_a-_b;
          return _c?mah.nh(_d,"c"):_d;
        case '!':
          _a=rev(ops[1],e,s,g,o,_f);
          _c=should_pass_type_info&&mah.hn(_a);
          _d=!mah.rv(_a);
          return _c?mah.nh(_d,"c"):_d;
        case '~':
          _a=rev(ops[1],e,s,g,o,_f);
          _c=should_pass_type_info&&mah.hn(_a);
          _d=~mah.rv(_a);
          return _c?mah.nh(_d,"c"):_d;
        default:
          $gmal.warn('unrecognized op'+rop);
      }
    }
    function rev(ops,e,s,g,o,newap){
      var op=ops[0],_f=false;
      if(typeof newap!=="undefined")o.ap=newap;
      if(typeof(op)==='object'){
        var vop=op[0];
        var _a,_aa,_b,_bb,_c,_d,_s,_e,_ta,_tb,_td;
        switch(vop){
          case 2: // LogicalExpression|ConditionalExpression|UnaryExpression|BinaryExpression
            return arithmeticEval(ops,e,s,g,o);
          case 4: // ArrayExpression
            return rev(ops[1],e,s,g,o,_f);
          case 5: // ArrayMember
            switch(ops.length){
              case 2: // one member
                return should_pass_type_info?[rev(ops[1],e,s,g,o,_f)]:[mah.rv(rev(ops[1],e,s,g,o,_f))];
              case 1: // empty
                return [];
              default: // more members
                _a=rev(ops[1],e,s,g,o,_f);
                _a.push(should_pass_type_info?rev(ops[2],e,s,g,o,_f):mah.rv(rev(ops[2],e,s,g,o,_f)));
                return _a;
            }
          case 6: // MemberExpression
            _a=rev(ops[1],e,s,g,o);
            var ap=o.ap;
            _ta=mah.hn(_a);
            _aa=_ta?mah.rv(_a):_a;
            o.is_affected|=_ta;
            if(should_pass_type_info){
              if(_aa===null||typeof(_aa)==='undefined'){
                return _ta?mah.nh(undefined,'e'):undefined;
              }
              _b=rev(ops[2],e,s,g,o,_f);
              _tb=mah.hn(_b);
              _bb=_tb?mah.rv(_b):_b;
              o.ap=ap;
              o.is_affected|=_tb;
              if(_bb===null||typeof(_bb)==='undefined'){
                return (_ta||_tb)?mah.nh(undefined,'e'):undefined;
              }
              _d=_aa[_bb];
              _td=mah.hn(_d);
              o.is_affected|=_td;
              return (_ta||_tb)?(_td?_d:mah.nh(_d,'e')):_d;
            }else{
              if(_aa===null||typeof(_aa)==='undefined'){
                return undefined;
              }
              _b=rev(ops[2],e,s,g,o,_f);
              _tb=mah.hn(_b);
              _bb=_tb?mah.rv(_b):_b;
              o.ap=ap;
              o.is_affected|=_tb;
              if(_bb===null||typeof(_bb)==='undefined'){
                return undefined;
              }
              _d=_aa[_bb];
              _td=mah.hn(_d);
              o.is_affected|=_td;
              return _td?mah.rv(_d):_d;
            }
          case 7: // Identifier
            switch(ops[1][0]){
              case 11: // CompoundExpression
                o.is_affected|=mah.hn(g);
                return g;
              case 3: // StaticString
                _s=mah.rv(s);
                _e=mah.rv(e);
                _b=ops[1][1];
                if(g&&g.f&&g.f.hasOwnProperty(_b)){
                  _a=g.f;
                  o.ap=true;
                }else{
                  _a=_s&&_s.hasOwnProperty(_b)?s:_e&&(_e.hasOwnProperty(_b)?e:undefined);
                }
                if(should_pass_type_info){
                  if(_a){
                    _ta=mah.hn(_a);
                    _aa=_ta?mah.rv(_a):_a;
                    _d=_aa[_b];
                    _td=mah.hn(_d);
                    o.is_affected|=_ta||_td;
                    _d=_ta&&!_td?mah.nh(_d,'e'):_d;
                    return _d;
                  }
                }else{
                  if(_a){
                    _ta=mah.hn(_a);
                    _aa=_ta?mah.rv(_a):_a;
                    _d=_aa[_b];
                    _td=mah.hn(_d);
                    o.is_affected|=_ta||_td;
                    return mah.rv(_d);
                  }
                }
                return undefined;
            }
            break;
          case 8: // ObjectProperty
            _a={};
            _a[ops[1]]=rev(ops[2],e,s,g,o,_f);
            return _a;
          case 9: // ObjectExpression
            _a=rev(ops[1],e,s,g,o,_f);
            _b=rev(ops[2],e,s,g,o,_f);
            function merge(_a,_b,_ow){
              _ta=mah.hn(_a);
              _tb=mah.hn(_b);
              _aa=mah.rv(_a);
              _bb=mah.rv(_b);
              if(should_pass_type_info){
                if(_tb){
                  for(var k in _bb){
                    if(_ow||!_aa.hasOwnProperty(k))_aa[k]=mah.nh(_bb[k],'e');
                  }
                }else{
                  for(var k in _bb){
                    if(_ow||!_aa.hasOwnProperty(k))_aa[k]=_bb[k];
                  }
                }
              }else{
                for(var k in _bb){
                  if(_ow||_aa.hasOwnProperty(k))_aa[k]=mah.rv(_bb[k]);
                }
              }
              return _a;
            }
            var _c=_a,_ow=true
            if(typeof(ops[1][0])==="object"&&ops[1][0][0]===10){
              _a=_b,_b=_c,_ow=false
            }
            if(typeof(ops[1][0])==="object"&&ops[1][0][0]===10)return merge(merge({},_a,_ow),_b,_ow);
            else return merge(_a,_b,_ow);
          case 10: // SpreadProperty
            return should_pass_type_info?rev(ops[1],e,s,g,o,_f):mah.rv(rev(ops[1],e,s,g,o,_f));
          case 12: // CallExpression
            var _r;
            _a=rev(ops[1],e,s,g,o);
            if(!o.ap)return should_pass_type_info&&mah.hn(_a)?mah.nh(_r,'f'):_r;
            var ap=o.ap;
            _b=rev(ops[2],e,s,g,o,_f);
            o.ap=ap;
            _ta=mah.hn(_a);
            _tb=_ca(_b);
            _aa=mah.rv(_a);
            _bb=mah.rv(_b);
            snap_bb=$gdc(_bb,"sjs_");
            try{
              _r=typeof _aa==="function"?$gdc(_aa.apply(null,snap_bb)):undefined;
            }catch(e){
              e.message=e.message.replace(/sjs_/g,"");
              e.stack=e.stack.substring(0,e.stack.indexOf("\n",e.stack.lastIndexOf("at sjs_")));
              e.stack=e.stack.replace(/\ssjs_/g," ");
              e.stack=$gstack(e.stack);
              e.stack += "\n "+" "+" "+" at " + path;
              if(window.__layer__==='view')console.error(e);
              _r=undefined;
            }
            return should_pass_type_info&&(_tb||_ta)?mah.nh(_r,'f'):_r;
        }
      }else{
        if(op===3||op===1) // StaticConstant
          return ops[1];
        else if(op===11){ // CompoundExpression
          var _a='';
          for(var index=1;index<ops.length;index++){
            var xp=mah.rv(rev(ops[index],e,s,g,o,_f));
            _a+=typeof(xp)==='undefined'?'':xp;
          }
          return _a;
        }
      }
    }
    return rev;
  }
  gra=$gmart(true);
  grb=$gmart(false);
  function mfor(to_iter,func,env,_s,global,father,itemname,indexname,keyname){
    var _n=!mah.hn(to_iter);
    var scope=mah.rv(_s);
    var full=Object.prototype.toString.call(mah.rv(to_iter));
    var type=full[8];
    var old_index=scope[indexname];
    var old_item=scope[itemname];
    var has_old_index=scope.hasOwnProperty(indexname);
    var has_old_item=scope.hasOwnProperty(itemname);

    if(type==='N'&&full[10]==='l')type='X';
    var _y;
    if(_n){
      if(type==='A'){
        for(var index=0;index<to_iter.length;index++){
          scope[itemname]=to_iter[index];
          scope[indexname]=mah.nh(index,'h');
          _y=keyname?(keyname==="*this"?_cvn(mah.rv(to_iter[index])):_cvn(mah.rv(mah.rv(to_iter[index])[keyname]))):_cvn();
          _ac(father,_y);
          func(env,scope,_y,global);
        }
      }else if(type==='O'){
        for(var k in to_iter){
          scope[itemname]=to_iter[k];
          scope[indexname]=mah.nh(k,'h');
          _y=keyname?(keyname==="*this"?_cvn(mah.rv(to_iter[k])):_cvn(mah.rv(mah.rv(to_iter[k])[keyname]))):_cvn();
          _ac(father,_y);
          func(env,scope,_y,global);
        }
      }else if(type==='S'){
        for(var i=0;i<to_iter.length;i++){
          scope[itemname]=to_iter[i];
          scope[indexname]=mah.nh(i,'h');
          _y=_cvn(to_iter[i]+i);
          _ac(father,_y);
          func(env,scope,_y,global);
        }
      }else if(type==='N'){
        for(var i=0;i<to_iter;i++){
          scope[itemname]=i;
          scope[indexname]=mah.nh(i,'h');
          _y=_cvn(i);
          _ac(father,_y);
          func(env,scope,_y,global);
        }
      }
    }else{
      var r_to_iter=mah.rv(to_iter);
      var r_iter_item,iter_item;
      if(type==='A'){
        for(var i=0;i<r_to_iter.length;i++){
          iter_item=r_to_iter[i];
          iter_item=!mah.hn(iter_item)?mah.nh(iter_item,'h'):iter_item;
          r_iter_item=mah.rv(iter_item);
          scope[itemname]=iter_item;
          scope[indexname]=mah.nh(i,'h');
          _y=keyname?(keyname==="*this"?_cvn(r_iter_item):_cvn(mah.rv(r_iter_item[keyname]))):_cvn();
          _ac(father,_y);
          func(env,scope,_y,global);
        }
      }else if(type==='O'){
        for(var k in r_to_iter){
          iter_item=r_to_iter[k];
          iter_item=!mah.hn(iter_item)?mah.nh(iter_item,'h'):iter_item;
          r_iter_item=mah.rv(iter_item);
          scope[itemname]=iter_item;
          scope[indexname]=mah.nh(k,'h');
          _y=keyname?(keyname==="*this"?_cvn(r_iter_item):_cvn(mah.rv(r_iter_item[keyname]))):_cvn();
          _ac(father,_y);
          func(env,scope,_y,global);
        }
      }else if(type==='S'){
        for(var i=0;i<r_to_iter.length;i++){
          scope[itemname]=mah.nh(r_to_iter[i],'h');
          scope[indexname]=mah.nh(i,'h');
          _y=_cvn(to_iter[i]+i);
          _ac(father,_y);
          func(env,scope,_y,global);
        }
      }else if(type==='N'){
        for(var i=0;i<r_to_iter;i++){
          scope[itemname]=mah.nh(i,'h');
          scope[indexname]=mah.nh(i,'h');
          _y=_cvn(i);
          _ac(father,_y);
          func(env,scope,_y,global);
        }
      }
    }
    if(has_old_index){
      scope[indexname]=old_index;
    }else{
      delete scope[indexname];
    }
    if(has_old_item){
      scope[itemname]=old_item;
    }else{
      delete scope[itemname];
    }
  }
  function _ca(obj){
    if(mah.hn(obj))return true;
    if(typeof obj!=="object")return false;
    for(var i in obj){
      if(obj.hasOwnProperty(i)){
        if(_ca(obj[i]))return true;
      }
    }
    return false;
  }
  function _setAttr(z,node,attrname,opindex,env,scope,global){
    var o={},raw=grb(z[opindex],env,scope,global,o),value=$gdc(raw,"",2);
    if(o.is_affected||_ca(raw))node.n.push(attrname); // new attr
    node.attr[attrname]=value;
  }
  function _o(z,opindex,env,scope,global){
    var nothing={};
    return grb(z[opindex],env,scope,global,nothing);
  }
  function _1(z,opindex,env,scope,global){
    var nothing={};
    return gra(z[opindex],env,scope,global,nothing);
  }
  function _2(z,opindex,func,env,scope,global,father,itemname,indexname,keyname){
    var to_iter=_1(z,opindex,env,scope,global,father,itemname,indexname,keyname);
    mfor(to_iter,func,env,scope,global,father,itemname,indexname,keyname);
  }
  function _setAttrs(z,tag,attrs,env,scope,global){
    var t=_ctn(tag),base=0;
    for(var i=0;i<attrs.length;i+=2){
      if(attrs[i+1]<0){
        t.attr[attrs[i]]=true;
      }else{
        _setAttr(z,t,attrs[i],base+attrs[i+1],env,scope,global);
        if(base===0)base=attrs[i+1];
      }
    }
    return t;
  }

  var sjs_init=function(){
    if(!__MAML_GLOBAL__.sjs_init){
      sjs_Object();sjs_Function();sjs_Array();sjs_String();sjs_Boolean();sjs_Number();sjs_Math();sjs_Date();sjs_RegExp();
    }
    __MAML_GLOBAL__.sjs_init=true;
  };
  var sjs_Object=function(){
    Object.defineProperty(Object.prototype,"sjs_constructor",{writable:true,value:"Object"})
    Object.defineProperty(Object.prototype,"sjs_toString",{writable:true,value:function(){return "[object Object]"}})
  }
  var sjs_Function=function(){
    Object.defineProperty(Function.prototype,"sjs_constructor",{writable:true,value:"Function"})
    Object.defineProperty(Function.prototype,"sjs_toString",{writable:true,value:function(){return "[function Function]"}})
    Object.defineProperty(Function.prototype,"sjs_length",{get:function(){return this.length;},set:function(){}});
  }
  var sjs_Array=function(){
    Object.defineProperty(Array.prototype,"sjs_constructor",{writable:true,value:"Array"})
    Object.defineProperty(Array.prototype,"sjs_toString",{writable:true,value:function(){return this.nv_join();}})
    Object.defineProperty(Array.prototype,"sjs_join",{writable:true,value:function(s){
      s=undefined==s?',':s;var r="";
      for(var i=0;i<this.length;++i){
        if(0!=i)r+=s;
        if(null==this[i]||undefined==this[i])r+='';
        else if(typeof this[i]=='function')r+=this[i].nv_toString();
        else if(typeof this[i]=='object'&&this[i].nv_constructor==="Array")r+=this[i].nv_join();
        else r+=this[i].toString();
      }
      return r;
    }})
    Object.defineProperty(Array.prototype,"sjs_concat",{writable:true,value:Array.prototype.concat})
    Object.defineProperty(Array.prototype,"sjs_pop",{writable:true,value:Array.prototype.pop})
    Object.defineProperty(Array.prototype,"sjs_push",{writable:true,value:Array.prototype.push})
    Object.defineProperty(Array.prototype,"sjs_reverse",{writable:true,value:Array.prototype.reverse})
    Object.defineProperty(Array.prototype,"sjs_shift",{writable:true,value:Array.prototype.shift})
    Object.defineProperty(Array.prototype,"sjs_slice",{writable:true,value:Array.prototype.slice})
    Object.defineProperty(Array.prototype,"sjs_sort",{writable:true,value:Array.prototype.sort})
    Object.defineProperty(Array.prototype,"sjs_splice",{writable:true,value:Array.prototype.splice})
    Object.defineProperty(Array.prototype,"sjs_unshift",{writable:true,value:Array.prototype.unshift})
    Object.defineProperty(Array.prototype,"sjs_indexOf",{writable:true,value:Array.prototype.indexOf})
    Object.defineProperty(Array.prototype,"sjs_lastIndexOf",{writable:true,value:Array.prototype.lastIndexOf})
    Object.defineProperty(Array.prototype,"sjs_every",{writable:true,value:Array.prototype.every})
    Object.defineProperty(Array.prototype,"sjs_some",{writable:true,value:Array.prototype.some})
    Object.defineProperty(Array.prototype,"sjs_forEach",{writable:true,value:Array.prototype.forEach})
    Object.defineProperty(Array.prototype,"sjs_map",{writable:true,value:Array.prototype.map})
    Object.defineProperty(Array.prototype,"sjs_filter",{writable:true,value:Array.prototype.filter})
    Object.defineProperty(Array.prototype,"sjs_reduce",{writable:true,value:Array.prototype.reduce})
    Object.defineProperty(Array.prototype,"sjs_reduceRight",{writable:true,value:Array.prototype.reduceRight})
    Object.defineProperty(Array.prototype,"sjs_length",{get:function(){return this.length;},set:function(value){this.length=value;}});
  }
  var sjs_String=function(){
    Object.defineProperty(String.prototype,"sjs_constructor",{writable:true,value:"String"})
    Object.defineProperty(String.prototype,"sjs_toString",{writable:true,value:String.prototype.toString})
    Object.defineProperty(String.prototype,"sjs_valueOf",{writable:true,value:String.prototype.valueOf})
    Object.defineProperty(String.prototype,"sjs_charAt",{writable:true,value:String.prototype.charAt})
    Object.defineProperty(String.prototype,"sjs_charCodeAt",{writable:true,value:String.prototype.charCodeAt})
    Object.defineProperty(String.prototype,"sjs_concat",{writable:true,value:String.prototype.concat})
    Object.defineProperty(String.prototype,"sjs_indexOf",{writable:true,value:String.prototype.indexOf})
    Object.defineProperty(String.prototype,"sjs_lastIndexOf",{writable:true,value:String.prototype.lastIndexOf})
    Object.defineProperty(String.prototype,"sjs_localeCompare",{writable:true,value:String.prototype.localeCompare})
    Object.defineProperty(String.prototype,"sjs_match",{writable:true,value:String.prototype.match})
    Object.defineProperty(String.prototype,"sjs_replace",{writable:true,value:String.prototype.replace})
    Object.defineProperty(String.prototype,"sjs_search",{writable:true,value:String.prototype.search})
    Object.defineProperty(String.prototype,"sjs_slice",{writable:true,value:String.prototype.slice})
    Object.defineProperty(String.prototype,"sjs_split",{writable:true,value:String.prototype.split})
    Object.defineProperty(String.prototype,"sjs_substring",{writable:true,value:String.prototype.substring})
    Object.defineProperty(String.prototype,"sjs_toLowerCase",{writable:true,value:String.prototype.toLowerCase})
    Object.defineProperty(String.prototype,"sjs_toLocaleLowerCase",{writable:true,value:String.prototype.toLocaleLowerCase})
    Object.defineProperty(String.prototype,"sjs_toUpperCase",{writable:true,value:String.prototype.toUpperCase})
    Object.defineProperty(String.prototype,"sjs_toLocaleUpperCase",{writable:true,value:String.prototype.toLocaleUpperCase})
    Object.defineProperty(String.prototype,"sjs_trim",{writable:true,value:String.prototype.trim})
    Object.defineProperty(String.prototype,"sjs_length",{get:function(){return this.length;},set:function(value){this.length=value;}});
  }
  var sjs_Boolean=function(){
    Object.defineProperty(Boolean.prototype,"sjs_constructor",{writable:true,value:"Boolean"})
    Object.defineProperty(Boolean.prototype,"sjs_toString",{writable:true,value:Boolean.prototype.toString})
    Object.defineProperty(Boolean.prototype,"sjs_valueOf",{writable:true,value:Boolean.prototype.valueOf})
  }
  var sjs_Number=function(){
    Object.defineProperty(Number,"sjs_MAX_VALUE",{writable:false,value:Number.MAX_VALUE})
    Object.defineProperty(Number,"sjs_MIN_VALUE",{writable:false,value:Number.MIN_VALUE})
    Object.defineProperty(Number,"sjs_NEGATIVE_INFINITY",{writable:false,value:Number.NEGATIVE_INFINITY})
    Object.defineProperty(Number,"sjs_POSITIVE_INFINITY",{writable:false,value:Number.POSITIVE_INFINITY})
    Object.defineProperty(Number.prototype,"sjs_constructor",{writable:true,value:"Number"})
    Object.defineProperty(Number.prototype,"sjs_toString",{writable:true,value:Number.prototype.toString})
    Object.defineProperty(Number.prototype,"sjs_toLocaleString",{writable:true,value:Number.prototype.toLocaleString})
    Object.defineProperty(Number.prototype,"sjs_valueOf",{writable:true,value:Number.prototype.valueOf})
    Object.defineProperty(Number.prototype,"sjs_toFixed",{writable:true,value:Number.prototype.toFixed})
    Object.defineProperty(Number.prototype,"sjs_toExponential",{writable:true,value:Number.prototype.toExponential})
    Object.defineProperty(Number.prototype,"sjs_toPrecision",{writable:true,value:Number.prototype.toPrecision})
  }
  var sjs_Math=function(){
    Object.defineProperty(Math,"sjs_E",{writable:false,value:Math.E})
    Object.defineProperty(Math,"sjs_LN10",{writable:false,value:Math.LN10})
    Object.defineProperty(Math,"sjs_LN2",{writable:false,value:Math.LN2})
    Object.defineProperty(Math,"sjs_LOG2E",{writable:false,value:Math.LOG2E})
    Object.defineProperty(Math,"sjs_LOG10E",{writable:false,value:Math.LOG10E})
    Object.defineProperty(Math,"sjs_PI",{writable:false,value:Math.PI})
    Object.defineProperty(Math,"sjs_SQRT1_2",{writable:false,value:Math.SQRT1_2})
    Object.defineProperty(Math,"sjs_SQRT2",{writable:false,value:Math.SQRT2})
    Object.defineProperty(Math,"sjs_abs",{writable:false,value:Math.abs})
    Object.defineProperty(Math,"sjs_acos",{writable:false,value:Math.acos})
    Object.defineProperty(Math,"sjs_asin",{writable:false,value:Math.asin})
    Object.defineProperty(Math,"sjs_atan",{writable:false,value:Math.atan})
    Object.defineProperty(Math,"sjs_atan2",{writable:false,value:Math.atan2})
    Object.defineProperty(Math,"sjs_ceil",{writable:false,value:Math.ceil})
    Object.defineProperty(Math,"sjs_cos",{writable:false,value:Math.cos})
    Object.defineProperty(Math,"sjs_exp",{writable:false,value:Math.exp})
    Object.defineProperty(Math,"sjs_floor",{writable:false,value:Math.floor})
    Object.defineProperty(Math,"sjs_log",{writable:false,value:Math.log})
    Object.defineProperty(Math,"sjs_max",{writable:false,value:Math.max})
    Object.defineProperty(Math,"sjs_min",{writable:false,value:Math.min})
    Object.defineProperty(Math,"sjs_pow",{writable:false,value:Math.pow})
    Object.defineProperty(Math,"sjs_random",{writable:false,value:Math.random})
    Object.defineProperty(Math,"sjs_round",{writable:false,value:Math.round})
    Object.defineProperty(Math,"sjs_sin",{writable:false,value:Math.sin})
    Object.defineProperty(Math,"sjs_sqrt",{writable:false,value:Math.sqrt})
    Object.defineProperty(Math,"sjs_tan",{writable:false,value:Math.tan})
  }
  var sjs_Date=function(){
    Object.defineProperty(Date.prototype,"sjs_constructor",{writable:true,value:"Date"})
    Object.defineProperty(Date,"sjs_parse",{writable:true,value:Date.parse})
    Object.defineProperty(Date,"sjs_UTC",{writable:true,value:Date.UTC})
    Object.defineProperty(Date,"sjs_now",{writable:true,value:Date.now})
    Object.defineProperty(Date.prototype,"sjs_toString",{writable:true,value:Date.prototype.toString})
    Object.defineProperty(Date.prototype,"sjs_toDateString",{writable:true,value:Date.prototype.toDateString})
    Object.defineProperty(Date.prototype,"sjs_toTimeString",{writable:true,value:Date.prototype.toTimeString})
    Object.defineProperty(Date.prototype,"sjs_toLocaleString",{writable:true,value:Date.prototype.toLocaleString})
    Object.defineProperty(Date.prototype,"sjs_toLocaleDateString",{writable:true,value:Date.prototype.toLocaleDateString})
    Object.defineProperty(Date.prototype,"sjs_toLocaleTimeString",{writable:true,value:Date.prototype.toLocaleTimeString})
    Object.defineProperty(Date.prototype,"sjs_valueOf",{writable:true,value:Date.prototype.valueOf})
    Object.defineProperty(Date.prototype,"sjs_getTime",{writable:true,value:Date.prototype.getTime})
    Object.defineProperty(Date.prototype,"sjs_getFullYear",{writable:true,value:Date.prototype.getFullYear})
    Object.defineProperty(Date.prototype,"sjs_getUTCFullYear",{writable:true,value:Date.prototype.getUTCFullYear})
    Object.defineProperty(Date.prototype,"sjs_getMonth",{writable:true,value:Date.prototype.getMonth})
    Object.defineProperty(Date.prototype,"sjs_getUTCMonth",{writable:true,value:Date.prototype.getUTCMonth})
    Object.defineProperty(Date.prototype,"sjs_getDate",{writable:true,value:Date.prototype.getDate})
    Object.defineProperty(Date.prototype,"sjs_getUTCDate",{writable:true,value:Date.prototype.getUTCDate})
    Object.defineProperty(Date.prototype,"sjs_getDay",{writable:true,value:Date.prototype.getDay})
    Object.defineProperty(Date.prototype,"sjs_getUTCDay",{writable:true,value:Date.prototype.getUTCDay})
    Object.defineProperty(Date.prototype,"sjs_getHours",{writable:true,value:Date.prototype.getHours})
    Object.defineProperty(Date.prototype,"sjs_getUTCHours",{writable:true,value:Date.prototype.getUTCHours})
    Object.defineProperty(Date.prototype,"sjs_getMinutes",{writable:true,value:Date.prototype.getMinutes})
    Object.defineProperty(Date.prototype,"sjs_getUTCMinutes",{writable:true,value:Date.prototype.getUTCMinutes})
    Object.defineProperty(Date.prototype,"sjs_getSeconds",{writable:true,value:Date.prototype.getSeconds})
    Object.defineProperty(Date.prototype,"sjs_getUTCSeconds",{writable:true,value:Date.prototype.getUTCSeconds})
    Object.defineProperty(Date.prototype,"sjs_getMilliseconds",{writable:true,value:Date.prototype.getMilliseconds})
    Object.defineProperty(Date.prototype,"sjs_getUTCMilliseconds",{writable:true,value:Date.prototype.getUTCMilliseconds})
    Object.defineProperty(Date.prototype,"sjs_getTimezoneOffset",{writable:true,value:Date.prototype.getTimezoneOffset})
    Object.defineProperty(Date.prototype,"sjs_setTime",{writable:true,value:Date.prototype.setTime})
    Object.defineProperty(Date.prototype,"sjs_setMilliseconds",{writable:true,value:Date.prototype.setMilliseconds})
    Object.defineProperty(Date.prototype,"sjs_setUTCMilliseconds",{writable:true,value:Date.prototype.setUTCMilliseconds})
    Object.defineProperty(Date.prototype,"sjs_setSeconds",{writable:true,value:Date.prototype.setSeconds})
    Object.defineProperty(Date.prototype,"sjs_setUTCSeconds",{writable:true,value:Date.prototype.setUTCSeconds})
    Object.defineProperty(Date.prototype,"sjs_setMinutes",{writable:true,value:Date.prototype.setMinutes})
    Object.defineProperty(Date.prototype,"sjs_setUTCMinutes",{writable:true,value:Date.prototype.setUTCMinutes})
    Object.defineProperty(Date.prototype,"sjs_setHours",{writable:true,value:Date.prototype.setHours})
    Object.defineProperty(Date.prototype,"sjs_setUTCHours",{writable:true,value:Date.prototype.setUTCHours})
    Object.defineProperty(Date.prototype,"sjs_setDate",{writable:true,value:Date.prototype.setDate})
    Object.defineProperty(Date.prototype,"sjs_setUTCDate",{writable:true,value:Date.prototype.setUTCDate})
    Object.defineProperty(Date.prototype,"sjs_setMonth",{writable:true,value:Date.prototype.setMonth})
    Object.defineProperty(Date.prototype,"sjs_setUTCMonth",{writable:true,value:Date.prototype.setUTCMonth})
    Object.defineProperty(Date.prototype,"sjs_setFullYear",{writable:true,value:Date.prototype.setFullYear})
    Object.defineProperty(Date.prototype,"sjs_setUTCFullYear",{writable:true,value:Date.prototype.setUTCFullYear})
    Object.defineProperty(Date.prototype,"sjs_toUTCString",{writable:true,value:Date.prototype.toUTCString})
    Object.defineProperty(Date.prototype,"sjs_toISOString",{writable:true,value:Date.prototype.toISOString})
    Object.defineProperty(Date.prototype,"sjs_toJSON",{writable:true,value:Date.prototype.toJSON})
  }
  var sjs_RegExp=function(){
    Object.defineProperty(RegExp.prototype,"sjs_constructor",{writable:true,value:"RegExp"})
    Object.defineProperty(RegExp.prototype,"sjs_exec",{writable:true,value:RegExp.prototype.exec})
    Object.defineProperty(RegExp.prototype,"sjs_test",{writable:true,value:RegExp.prototype.test})
    Object.defineProperty(RegExp.prototype,"sjs_toString",{writable:true,value:RegExp.prototype.toString})
    Object.defineProperty(RegExp.prototype,"sjs_source",{get:function(){return this.source;},set:function(){}});
    Object.defineProperty(RegExp.prototype,"sjs_global",{get:function(){return this.global;},set:function(){}});
    Object.defineProperty(RegExp.prototype,"sjs_ignoreCase",{get:function(){return this.ignoreCase;},set:function(){}});
    Object.defineProperty(RegExp.prototype,"sjs_multiline",{get:function(){return this.multiline;},set:function(){}});
    Object.defineProperty(RegExp.prototype,"sjs_lastIndex",{get:function(){return this.lastIndex;},set:function(v){this.lastIndex=v;}});
  }
  sjs_init();
  // sjs global object or function
  var sjs_getDate=function(){var args=Array.prototype.slice.call(arguments);args.unshift(Date);return new(Function.prototype.bind.apply(Date,args));}
  var sjs_getRegExp=function(){var args=Array.prototype.slice.call(arguments);args.unshift(RegExp);return new(Function.prototype.bind.apply(RegExp,args));}
  var sjs_console={sjs_log:function(){if(window.__layer__==='view'){var res="[SJS runtime info] ";for(var i=0;i<arguments.length;++i)res+=arguments[i]+" ";console.log(res);}}}
  var sjs_parseInt=parseInt,sjs_parseFloat=parseFloat,sjs_isNaN=isNaN,sjs_isFinite=isFinite,sjs_decodeURI=decodeURI,sjs_decodeURIComponent=decodeURIComponent,sjs_encodeURI=encodeURI,sjs_encodeURIComponent=encodeURIComponent;
  var sjs_JSON={
    sjs_stringify:function(o){return JSON.stringify($gdc(o));},
    sjs_parse:function(s){
      if(s===undefined)return undefined;
      return $gdc(JSON.parse(s),'sjs_');
    }
  }
  function _ck(k){return null==k?undefined:'number'===typeof k?k:"sjs_"+k} // compute key for sjs a[key]

  function _grp(path,e,me){if(path[0]!='/'){var mepart=me.split('/');mepart.pop();var ppart=path.split('/');for(var index=0;index<ppart.length;index++){if(ppart[index]=='..')mepart.pop();else if(ppart[index]=='.'||!ppart[index])continue;else mepart.push(ppart[index]);}path=mepart.join('/');}if(me[0]=='.'&&path[0]=='/')path='.'+path;if(e[path])return path;if(e[path+'.maml'])return path+'.maml';} // getRelativePath

  function _ai(i,path,e,me,r,c){var rp=_grp(path,e,me);if(rp)i.push(rp);else{i.push('');_rtw(me+':import:'+r+':'+c+': Path `'+path+'` not found from `'+me+'`.')}} // import

  function _gapi(e, path) {
    if (!path) return [];
    if ($gaic[path]) {
      return $gaic[path];
    }
    var ret = [],
      qq = [],
      hh = 0,
      tt = 0,
      put = {},
      visited = {};
    qq.push(path);
    visited[path] = true;
    tt++;
    while (hh < tt) {
      var a = qq[hh++];
      for (var index = 0; index < e[a].ic.length; index++) {
        var nd = e[a].ic[index];
        var np = _grp(nd, e, a);
        if (np && !visited[np]) {
          visited[np] = true;
          qq.push(np);
          tt++;
        }
      }
      for (var index = 0; a != path && index < e[a].ti.length; index++) {
        var ni = e[a].ti[index];
        var nm = _grp(ni, e, a);
        if (nm && !put[nm]) {
        }
      }
    }
    $gaic[path] = ret;
    return ret;
  }

  function _gd(p, c, e, d) {
    if (!c) return;
    if (d[p][c]) return d[p][c];
    for (var index = e[p].i.length - 1; index >= 0; index--) {
      if (e[p].i[index] && d[e[p].i[index]][c]) return d[e[p].i[index]][c];
    }
    for (var index = e[p].ti.length - 1; index >= 0; index--) {
      var q = _grp(e[p].ti[index], e, p);
      if (q && d[q][c]) return d[q][c];
    }
    var api = _gapi(e, p);
    for (var index = 0; index < api.length; index++) {
      if (api[index] && d[api[index]][c]) return d[api[index]][c];
    }
    for (var key = e[p].j.length - 1; key >= 0; key--)
      if (e[p].j[key]) {
        for (var qlen = e[e[p].j[key]].ti.length - 1; qlen >= 0; qlen--) {
          var tt = _grp(e[e[p].j[key]].ti[qlen], e, p);
          if (tt && d[tt][c]) {
            return d[tt][c];
          }
        }
      }
  }
  
  var $ixc = {};
  function _ic(p,ent,me,e,s,r,gg){var x=_grp(p,ent,me);ent[me].j.push(x);if(x){if($ixc[x]){_rtw('-1:include:-1:-1: `'+p+'` is being included in a loop, will be stop.');return;}$ixc[x]=true;try{ent[x].f(e,s,r,gg)}catch(e){}$ixc[x]=false;}else{_rtw(me+':include:-1:-1: Included path `'+p+'` not found from `'+me+'`.')}} // include
  function _w(tn,f,line,c){_rtw(f+':template:'+line+':'+c+': Template `'+tn+'` not found.');}

  var e_=__MAML_GLOBAL__.entrys||{},d_=__MAML_GLOBAL__.defines||{},f_=__MAML_GLOBAL__.modules||{},p_={};
  if(window.i18n&&!f_.i18n){ // init sjs i18n api, remove arguments property sjs prefix
    f_.i18n={}
    for(var k in i18n){
      (function(k){ // simulate for loop let
        var key=k
        i18n['sjs_'+k]=i18n[k]
        if(typeof i18n[k]==="function"){
          i18n['sjs_'+k]=function(){return i18n[key].apply(null,$gdc(Array.prototype.slice.call(arguments)))}
          f_.i18n[k]=i18n['sjs_'+k]
        }else{
          i18n['sjs_'+k]=i18n[k]
          f_.i18n[k]=i18n[k]
        }
      })(k)
    }
  }
  __MAML_GLOBAL__.ops_cached=__MAML_GLOBAL__.ops_cached||{};
  __MAML_GLOBAL__.ops_set=__MAML_GLOBAL__.ops_set||{};
  __MAML_GLOBAL__.ops_init=__MAML_GLOBAL__.ops_init||{};
  var z=__MAML_GLOBAL__.ops_set.$gma||[];
  
  function gz$gma_1(){
    if(__MAML_GLOBAL__.ops_cached.$gma_1)return __MAML_GLOBAL__.ops_cached.$gma_1
    __MAML_GLOBAL__.ops_cached.$gma_1=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'openProduct']);
      Z([3,'product']);
      Z([[7],[3,"product"]]);
      Z([[6],[[7],[3,"product"]],[3,"id"]]);
      Z([3,'product-image-container']);
      Z([3,' product-image-1']);
      Z([[6],[[6],[[7],[3,"product"]],[3,"image_paths"]],[1,0]]);
      Z([3,'product-name']);
      Z([3,'product-font']);
      Z([11,[[6],[[7],[3,"product"]],[3,"name"]]]);
      Z([11,[[6],[[7],[3,"product"]],[3,"price"]],[3,' birr']]);
      Z([3,'24']);
      Z([3,'0 0 24 24']);
      Z([3,'http://www.w3.org/2000/svg']);
      Z([3,'none']);
      Z([3,'evenodd']);
      Z([3,'feAddCart0']);
      Z([3,'1']);
      Z([3,'currentColor']);
      Z([3,'feAddCart1']);
      Z([3,'M8 16h8a1 1 0 0 1 0 2H7a1 1 0 0 1-1-1V4H5a1 1 0 1 1 0-2h2a1 1 0 0 1 1 1v9h8.775L18 7V5.001c1.145 0 2 .894 2 1.999c0 .146-.017.291-.05.434l-1.151 5c-.21.915-1.052 1.566-2.024 1.566H8.073L8 13.999V16Zm-.5 6a1.5 1.5 0 1 1 0-3a1.5 1.5 0 0 1 0 3Zm9 0a1.5 1.5 0 1 1 0-3a1.5 1.5 0 0 1 0 3ZM14 5h1a1 1 0 0 1 0 2h-1v1a1 1 0 0 1-2 0V7h-1a1 1 0 0 1 0-2h1V4a1 1 0 0 1 2 0v1Z']);
      Z([3,'feAddCart2'])
    })(__MAML_GLOBAL__.ops_cached.$gma_1);
    return __MAML_GLOBAL__.ops_cached.$gma_1
  }
  function gz$gma_2(){
    if(__MAML_GLOBAL__.ops_cached.$gma_2)return __MAML_GLOBAL__.ops_cached.$gma_2
    __MAML_GLOBAL__.ops_cached.$gma_2=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'categories-container']);
      Z([3,'categories-search']);
      Z([3,'24']);
      Z([3,'0 0 24 24']);
      Z([3,'http://www.w3.org/2000/svg']);
      Z([3,'m12 20l-8-8l8-8l1.425 1.4l-5.6 5.6H20v2H7.825l5.6 5.6Z']);
      Z([3,'currentColor']);
      Z([3,'bindSearchInput']);
      Z([3,'categories-search-input']);
      Z([3,'What do you need?']);
      Z([3,'M15.5 14h-.79l-.28-.27A6.471 6.471 0 0 0 16 9.5A6.5 6.5 0 1 0 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5S14 7.01 14 9.5S11.99 14 9.5 14z']);
      Z([3,'categories-list']);
      Z([[7],[3,"categories"]]);
      Z([[7],[3,"id"]]);
      Z([3,'getSubcategoriesProducts']);
      Z([[2,'?:'],[[2,"=="], [[7],[3,"subcategoriesId"]], [[6],[[7],[3,"item"]],[3,"id"]]],[1,"categories-list-item-active"],[1,"categories-list-item"]]);
      Z([[6],[[7],[3,"item"]],[3,"id"]]);
      Z([11,[[6],[[7],[3,"item"]],[3,"name"]]]);
      Z([3,'Category Name']);
      Z([[2,">"], [[6],[[7],[3,"products"]],[3,"length"]], [1,0]]);
      Z([3,'products-grid']);
      Z([[7],[3,"products"]]);
      Z([3,'openProduct']);
      Z([3,'product']);
      Z([[7],[3,"item"]]);
      Z([3,'product-image-container']);
      Z([3,' product-image-1']);
      Z([[6],[[6],[[7],[3,"item"]],[3,"image_paths"]],[1,0]]);
      Z([3,'product-name']);
      Z([3,'product-font']);
      Z([11,[[6],[[7],[3,"item"]],[3,"price"]],[3,' birr']]);
      Z([3,'none']);
      Z([3,'evenodd']);
      Z([3,'feAddCart0']);
      Z([3,'1']);
      Z([3,'feAddCart1']);
      Z([3,'M8 16h8a1 1 0 0 1 0 2H7a1 1 0 0 1-1-1V4H5a1 1 0 1 1 0-2h2a1 1 0 0 1 1 1v9h8.775L18 7V5.001c1.145 0 2 .894 2 1.999c0 .146-.017.291-.05.434l-1.151 5c-.21.915-1.052 1.566-2.024 1.566H8.073L8 13.999V16Zm-.5 6a1.5 1.5 0 1 1 0-3a1.5 1.5 0 0 1 0 3Zm9 0a1.5 1.5 0 1 1 0-3a1.5 1.5 0 0 1 0 3ZM14 5h1a1 1 0 0 1 0 2h-1v1a1 1 0 0 1-2 0V7h-1a1 1 0 0 1 0-2h1V4a1 1 0 0 1 2 0v1Z']);
      Z([3,'feAddCart2']);
      Z([3,'empty-message']);
      Z([3,'This Category is empty']);
      Z([3,'pagination']);
      Z([11,[[7],[3,"leftSign"]]]);
      Z([[7],[3,"pages"]]);
      Z([[7],[3,"index"]]);
      Z([3,'changePage']);
      Z([[2,'?:'],[[2,"=="], [[7],[3,"currentPage"]], [[2,"+"], [[7],[3,"index"]], [1,1]]],[1,"pagination-item-active"],[1,"pagination-item"]]);
      Z([[2,"+"], [[7],[3,"index"]], [1,1]]);
      Z([11,[[2,"+"], [[7],[3,"index"]], [1,1]]]);
      Z([3,'\x3e\x3e'])
    })(__MAML_GLOBAL__.ops_cached.$gma_2);
    return __MAML_GLOBAL__.ops_cached.$gma_2
  }
  function gz$gma_3(){
    if(__MAML_GLOBAL__.ops_cached.$gma_3)return __MAML_GLOBAL__.ops_cached.$gma_3
    __MAML_GLOBAL__.ops_cached.$gma_3=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'checkout']);
      Z([[7],[3,"deliveryTypes"]]);
      Z([[7],[3,"id"]]);
      Z([3,'chooseDeliveryType']);
      Z([3,'deliveryTypes']);
      Z([[6],[[7],[3,"item"]],[3,"id"]]);
      Z([[2,'?:'],[[2,"=="], [[7],[3,"choosedDeliveryId"]], [[6],[[7],[3,"item"]],[3,"id"]]],[1,"deliveryTypes-active"],[1,"deliveryTypes-item"]]);
      Z([3,'deliveryTypes-name']);
      Z([11,[[6],[[7],[3,"item"]],[3,"name"]]]);
      Z([3,'deliveryTypes-name-sub']);
      Z([11,[[6],[[7],[3,"item"]],[3,"description"]]]);
      Z([3,'1%']);
      Z([3,'delivery-fields']);
      Z([3,'delivery-fields-field']);
      Z([3,'delivery-field-text']);
      Z([3,'Neighborhood']);
      Z([3,'addNeighborhood']);
      Z([3,'delivery-input']);
      Z([3,'Kazanchiz, bole ...']);
      Z([3,'text']);
      Z([3,'delivery-fields-field-2']);
      Z([3,'Home Add.']);
      Z([[7],[3,"homeNumber"]]);
      Z([3,'1010']);
      Z([3,'checkout-bottom']);
      Z([3,'checkout-price']);
      Z([3,'Total']);
      Z([11,[[7],[3,"totalPrice"]],[3,' birr']]);
      Z([3,'makeOrder']);
      Z([3,'delivery-button']);
      Z([3,'Pay'])
    })(__MAML_GLOBAL__.ops_cached.$gma_3);
    return __MAML_GLOBAL__.ops_cached.$gma_3
  }
  function gz$gma_4(){
    if(__MAML_GLOBAL__.ops_cached.$gma_4)return __MAML_GLOBAL__.ops_cached.$gma_4
    __MAML_GLOBAL__.ops_cached.$gma_4=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'notifications']);
      Z([3,'title']);
      Z([3,'Notifications']);
      Z([[2,">"], [[6],[[7],[3,"notifications"]],[3,"length"]], [1,0]]);
      Z([[7],[3,"notifications"]]);
      Z([[7],[3,"index"]]);
      Z([3,'notification-items']);
      Z([3,'notification-title']);
      Z([11,[[6],[[6],[[7],[3,"item"]],[3,"data"]],[3,"title"]]]);
      Z([3,'notification-message']);
      Z([11,[[6],[[6],[[7],[3,"item"]],[3,"data"]],[3,"message"]]]);
      Z([3,'no-notification']);
      Z([3,'No Notifications'])
    })(__MAML_GLOBAL__.ops_cached.$gma_4);
    return __MAML_GLOBAL__.ops_cached.$gma_4
  }
  function gz$gma_5(){
    if(__MAML_GLOBAL__.ops_cached.$gma_5)return __MAML_GLOBAL__.ops_cached.$gma_5
    __MAML_GLOBAL__.ops_cached.$gma_5=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'product-main']);
      Z([3,'product-image']);
      Z([[6],[[6],[[7],[3,"package"]],[3,"image_paths"]],[1,0]]);
      Z([3,'product-title']);
      Z([11,[[6],[[7],[3,"package"]],[3,"name"]]]);
      Z([3,'price']);
      Z([3,'price-tag']);
      Z([3,'Price:']);
      Z([11,[[2,"-"], [[6],[[7],[3,"package"]],[3,"price"]], [[6],[[7],[3,"package"]],[3,"discount"]]],[3,'birr']]);
      Z([3,'cart-button']);
      Z([3,'addCart']);
      Z([3,'cart-button-add']);
      Z([3,'24']);
      Z([3,'0 0 24 24']);
      Z([3,'http://www.w3.org/2000/svg']);
      Z([3,'M18 20H6V8h2v2c0 .55.45 1 1 1s1-.45 1-1V8h4v2c0 .55.45 1 1 1s1-.45 1-1V8h2v12z']);
      Z([3,'currentColor']);
      Z([3,'.3']);
      Z([3,'M18 6h-2c0-2.21-1.79-4-4-4S8 3.79 8 6H6c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V8c0-1.1-.9-2-2-2zm-6-2c1.1 0 2 .9 2 2h-4c0-1.1.9-2 2-2zm6 16H6V8h2v2c0 .55.45 1 1 1s1-.45 1-1V8h4v2c0 .55.45 1 1 1s1-.45 1-1V8h2v12z']);
      Z([3,'Add to cart']);
      Z([3,'m12 21.35l-1.45-1.32C5.4 15.36 2 12.27 2 8.5C2 5.41 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.08C13.09 3.81 14.76 3 16.5 3C19.58 3 22 5.41 22 8.5c0 3.77-3.4 6.86-8.55 11.53L12 21.35Z']);
      Z([3,'gray']);
      Z([3,'Products']);
      Z([3,'product-list']);
      Z([[6],[[7],[3,"package"]],[3,"products"]]);
      Z([[7],[3,"id"]]);
      Z([3,'product-list-item']);
      Z([11,[[6],[[7],[3,"item"]],[3,"name"]]]);
      Z([11,[[6],[[6],[[7],[3,"item"]],[3,"pivot"]],[3,"quantity"]]])
    })(__MAML_GLOBAL__.ops_cached.$gma_5);
    return __MAML_GLOBAL__.ops_cached.$gma_5
  }
  function gz$gma_6(){
    if(__MAML_GLOBAL__.ops_cached.$gma_6)return __MAML_GLOBAL__.ops_cached.$gma_6
    __MAML_GLOBAL__.ops_cached.$gma_6=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'product-main']);
      Z([3,'product-image']);
      Z([[6],[[7],[3,"product"]],[3,"imageurl"]]);
      Z([3,'product-title']);
      Z([11,[[6],[[7],[3,"product"]],[3,"name"]]]);
      Z([3,'price']);
      Z([3,'price-tag']);
      Z([3,'Price:']);
      Z([11,[[2,"-"], [[6],[[7],[3,"product"]],[3,"price"]], [[6],[[7],[3,"product"]],[3,"discount"]]],[3,'birr']]);
      Z([3,'cart-button']);
      Z([3,'addCart']);
      Z([3,'cart-button-add']);
      Z([3,'24']);
      Z([3,'0 0 24 24']);
      Z([3,'http://www.w3.org/2000/svg']);
      Z([3,'M18 20H6V8h2v2c0 .55.45 1 1 1s1-.45 1-1V8h4v2c0 .55.45 1 1 1s1-.45 1-1V8h2v12z']);
      Z([3,'currentColor']);
      Z([3,'.3']);
      Z([3,'M18 6h-2c0-2.21-1.79-4-4-4S8 3.79 8 6H6c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V8c0-1.1-.9-2-2-2zm-6-2c1.1 0 2 .9 2 2h-4c0-1.1.9-2 2-2zm6 16H6V8h2v2c0 .55.45 1 1 1s1-.45 1-1V8h4v2c0 .55.45 1 1 1s1-.45 1-1V8h2v12z']);
      Z([3,'Add to cart']);
      Z([[2,">"], [[6],[[6],[[7],[3,"product"]],[3,"description"]],[3,"length"]], [1,0]]);
      Z([3,'Description']);
      Z([11,[[6],[[7],[3,"product"]],[3,"description"]]])
    })(__MAML_GLOBAL__.ops_cached.$gma_6);
    return __MAML_GLOBAL__.ops_cached.$gma_6
  }
  function gz$gma_7(){
    if(__MAML_GLOBAL__.ops_cached.$gma_7)return __MAML_GLOBAL__.ops_cached.$gma_7
    __MAML_GLOBAL__.ops_cached.$gma_7=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'btn1']);
      Z([3,'language']);
      Z([[7],[3,"background"]]);
      Z([3,'*this']);
      Z([3,'chooseImage']);
      Z([11,[3,'/images/'],[[7],[3,"item"]],[3,'.png']]);
      Z([3,'input']);
      Z([3,'bindSearchInput']);
      Z([3,'ipt']);
      Z([3,'User Name']);
      Z([3,'text']);
      Z([3,'First Name']);
      Z([3,'Last Name']);
      Z([3,'Phone Number']);
      Z([3,'number']);
      Z([3,'City']);
      Z([3,'Sub-city']);
      Z([3,'Woreda']);
      Z([3,'Neighborhood']);
      Z([3,'House Number']);
      Z([3,'btn']);
      Z([3,'Finish'])
    })(__MAML_GLOBAL__.ops_cached.$gma_7);
    return __MAML_GLOBAL__.ops_cached.$gma_7
  }
  function gz$gma_8(){
    if(__MAML_GLOBAL__.ops_cached.$gma_8)return __MAML_GLOBAL__.ops_cached.$gma_8
    __MAML_GLOBAL__.ops_cached.$gma_8=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([[7],[3,"cart"]]);
      Z([[7],[3,"id"]]);
      Z([3,'cart-item']);
      Z([[6],[[7],[3,"item"]],[3,"imageurl"]]);
      Z([3,'cart-item-info']);
      Z([3,'product-name']);
      Z([11,[[6],[[7],[3,"item"]],[3,"name"]]]);
      Z([3,'cost_details']);
      Z([3,'Price:']);
      Z([[2,"!=="], [[12],[[6],[[6],[[7],[3,"item"]],[3,"originalPrice"]],[3,"toString"]],[[5]]], [[12],[[6],[[6],[[7],[3,"item"]],[3,"price"]],[3,"toString"]],[[5]]]]);
      Z([3,'price']);
      Z([11,[[6],[[7],[3,"item"]],[3,"originalPrice"]],[3,' Br']]);
      Z([3,'pricewithDiscount']);
      Z([11,[[6],[[7],[3,"item"]],[3,"price"]],[3,' Br']]);
      Z([3,'cart-quantity']);
      Z([3,'label']);
      Z([3,'Quantity:']);
      Z([3,'decrementQuantity']);
      Z([3,'decrement']);
      Z([[6],[[7],[3,"item"]],[3,"id"]]);
      Z([3,'mini']);
      Z([3,'-']);
      Z([3,'quantity']);
      Z([11,[[6],[[7],[3,"item"]],[3,"quantity"]]]);
      Z([3,'incrementQuantity']);
      Z([3,'increment']);
      Z([3,'+']);
      Z([[2,">"], [[7],[3,"totalPrice"]], [1,0]]);
      Z([3,'cart-footer']);
      Z([3,'cart-total']);
      Z([11,[3,'Total: '],[[7],[3,"totalPrice"]],[3,' Br']]);
      Z([3,'checkout']);
      Z([3,'purchase-button']);
      Z([3,'Checkout'])
    })(__MAML_GLOBAL__.ops_cached.$gma_8);
    return __MAML_GLOBAL__.ops_cached.$gma_8
  }
  function gz$gma_9(){
    if(__MAML_GLOBAL__.ops_cached.$gma_9)return __MAML_GLOBAL__.ops_cached.$gma_9
    __MAML_GLOBAL__.ops_cached.$gma_9=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'bindSearchInput']);
      Z([3,'What do you need?']);
      Z([3,'true']);
      Z([3,'500']);
      Z([3,'default']);
      Z([3,'#000000']);
      Z([3,'rgba(0, 0, 0, .3)']);
      Z([3,'3000']);
      Z([3,'false']);
      Z([[7],[3,"background"]]);
      Z([3,'*this']);
      Z([11,[3,'swiper-item '],[[7],[3,"item"]]]);
      Z([3,'swiper-image']);
      Z([3,'heightFix']);
      Z([11,[3,'/images/'],[[7],[3,"item"]],[3,'.jpg']]);
      Z([3,'Categories']);
      Z([3,'categories']);
      Z([[7],[3,"categories"]]);
      Z([[7],[3,"id"]]);
      Z([3,'openCategory']);
      Z([3,'categories-item']);
      Z([[7],[3,"item"]]);
      Z([[6],[[7],[3,"item"]],[3,"id"]]);
      Z([3,' categories-image']);
      Z([[6],[[7],[3,"item"]],[3,"image_path"]]);
      Z([11,[[6],[[7],[3,"item"]],[3,"name"]]]);
      Z([3,'Frequently purchased items']);
      Z([3,'products-scroll']);
      Z([[7],[3,"popularProducts"]]);
      Z([3,'openProduct']);
      Z([3,'product-image']);
      Z([[6],[[6],[[7],[3,"item"]],[3,"image_paths"]],[1,0]]);
      Z([3,'product-item']);
      Z([11,[[6],[[7],[3,"item"]],[3,"price"]]]);
      Z([3,'Packages']);
      Z([[7],[3,"packages"]]);
      Z([3,'openPackage'])
    })(__MAML_GLOBAL__.ops_cached.$gma_9);
    return __MAML_GLOBAL__.ops_cached.$gma_9
  }
  function gz$gma_10(){
    if(__MAML_GLOBAL__.ops_cached.$gma_10)return __MAML_GLOBAL__.ops_cached.$gma_10
    __MAML_GLOBAL__.ops_cached.$gma_10=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'profile']);
      Z([3,'btn1']);
      Z([3,'language']);
      Z([3,'btns']);
      Z([3,'openProfile']);
      Z([3,'btn2']);
      Z([[7],[3,"item"]]);
      Z([3,'Edit profile']);
      Z([3,'openNotification']);
      Z([3,'Notification']);
      Z([3,'Powered by']);
      Z([3,'nbsp']);
      Z([3,'Zowi tech'])
    })(__MAML_GLOBAL__.ops_cached.$gma_10);
    return __MAML_GLOBAL__.ops_cached.$gma_10
  }
  function gz$gma_11(){
    if(__MAML_GLOBAL__.ops_cached.$gma_11)return __MAML_GLOBAL__.ops_cached.$gma_11
    __MAML_GLOBAL__.ops_cached.$gma_11=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([[7],[3,"orders"]]);
      Z([[7],[3,"id"]]);
      Z([3,'item']);
      Z([[2,"||"],[[6],[[6],[[6],[[6],[[7],[3,"item"]],[3,"products"]],[1,0]],[3,"image_paths"]],[1,0]],[[6],[[6],[[6],[[6],[[7],[3,"item"]],[3,"packages"]],[1,0]],[3,"image_paths"]],[1,0]]]);
      Z([3,'item-info']);
      Z([3,'product-name']);
      Z([11,[[2,'?:'],[[6],[[6],[[6],[[7],[3,"item"]],[3,"products"]],[1,0]],[3,"name"]],[[6],[[6],[[6],[[7],[3,"item"]],[3,"products"]],[1,0]],[3,"name"]],[[6],[[6],[[6],[[7],[3,"item"]],[3,"packages"]],[1,0]],[3,"name"]]]]);
      Z([3,'further-info']);
      Z([[2,'?:'],[[2,"==="], [[6],[[7],[3,"item"]],[3,"status"]], [1,"payment-rejected"]],[1,"payment-rejected"],[1,"payment"]]);
      Z([11,[[6],[[7],[3,"item"]],[3,"status"]]]);
      Z([11,[3,'Delivery Type :'],[[6],[[6],[[7],[3,"item"]],[3,"delivery_type"]],[3,"slug"]]]);
      Z([3,'price']);
      Z([11,[3,'Total Cost: '],[[6],[[7],[3,"item"]],[3,"total_cost"]],[3,' Br']])
    })(__MAML_GLOBAL__.ops_cached.$gma_11);
    return __MAML_GLOBAL__.ops_cached.$gma_11
  }
  __MAML_GLOBAL__.ops_set.$gma=z;
  __MAML_GLOBAL__.ops_init.$gma=true;
  
  var sjs_require=function(){
    var smm={}; // sjs modules map
    var smem={}; // sjs modules exports map
    return function(mp){ // module path
      if(mp[0]==='p'&&mp[1]==='_'&&f_[mp.slice(2)])return f_[mp.slice(2)];
      return function(){
        if(!smm[mp]) return undefined;
        try{
          if(!smem[mp])smem[mp]=smm[mp]();
          return smem[mp];
        }catch(e){
          e.message=e.message.replace(/sjs_/g,'');
          var t = e.stack.substring(0,e.stack.lastIndexOf(mp));
          e.stack = t.substring(0,t.lastIndexOf('\n'));
          e.stack = e.stack.replace(/\ssjs_/g,' ');
          e.stack = $gstack(e.stack);
          e.stack += '\n    at ' + mp.substring(2);
          console.error(e);
        }
      }
    }
  }()

  
  d_["./components/product-card/product-card.maml"]={};
  var m0=function(e,s,r,gg){
    var z=gz$gma_1()
    var ofg=_setAttrs(z,"view",["bindtap",0,"class",1,"data-product",1,"id",2],e,s,gg);var ogg=_ctn("view");_setAttr(z,ogg,'class',4,e,s,gg);var ohg=_setAttrs(z,"image",["class",5,"src",1],e,s,gg);_ac(ogg,ohg);_ac(ofg,ogg);var oig=_ctn("view");_setAttr(z,oig,'class',7,e,s,gg);var ojg=_ctn("view");_setAttr(z,ojg,'class',8,e,s,gg);var okg=_o(z,9,e,s,gg);_ac(ojg,okg);_ac(oig,ojg);var olg=_ctn("view");var omg=_o(z,10,e,s,gg);_ac(olg,omg);_ac(oig,olg);var ong=_setAttrs(z,"svg",["height",11,"width",0,"viewBox",1,"xmlns",2],e,s,gg);var oog=_setAttrs(z,"g",["fill",14,"stroke",0,"fillRule",1,"id",2,"strokeWidth",3],e,s,gg);var opg=_setAttrs(z,"g",["fill",18,"id",1],e,s,gg);var oqg=_setAttrs(z,"path",["d",20,"id",1],e,s,gg);_ac(opg,oqg);_ac(oog,opg);_ac(ong,oog);_ac(oig,ong);_ac(ofg,oig);_ac(r,ofg);
    return r;
  };
  e_["./components/product-card/product-card.maml"]={f:m0,j:[],i:[],ti:[],ic:[]};

  d_["./pages/sub_pages/categories-view/categories-view.maml"]={};
  var m1=function(e,s,r,gg){
    var z=gz$gma_2()
    var osg=_ctn("view");_setAttr(z,osg,'class',0,e,s,gg);var otg=_ctn("view");_setAttr(z,otg,'class',1,e,s,gg);var oug=_setAttrs(z,"svg",["height",2,"width",0,"viewBox",1,"xmlns",2],e,s,gg);var ovg=_setAttrs(z,"path",["d",5,"fill",1],e,s,gg);_ac(oug,ovg);_ac(otg,oug);var owg=_setAttrs(z,"input",["bindinput",7,"class",1,"placeholder",2],e,s,gg);_ac(otg,owg);var oxg=_setAttrs(z,"svg",["height",2,"width",0,"viewBox",1,"xmlns",2],e,s,gg);var oyg=_setAttrs(z,"path",["fill",6,"d",4],e,s,gg);_ac(oxg,oyg);_ac(otg,oxg);_ac(osg,otg);var ozg=_ctn("view");_setAttr(z,ozg,'class',11,e,s,gg);var o_g=_cvn();var oAh=function(oEh,oDh,oCh,gg){var oBh=_setAttrs(z,"button",["bindtap",14,"class",1,"id",2],oEh,oDh,gg);var oGh=_o(z,17,oEh,oDh,gg);_ac(oBh,oGh);_ac(oCh,oBh);return oCh;};_2(z,12,oAh,e,s,gg,o_g,"item","index",'{{id}}');_ac(ozg,o_g);_ac(osg,ozg);var oHh=_ctn("view");var oIh=_o(z,18,e,s,gg);_ac(oHh,oIh);_ac(osg,oHh);var oJh=_cvn();if(_o(z,19,e,s,gg)){oJh.maVkey=1;var oKh=_ctn("view");_setAttr(z,oKh,'class',20,e,s,gg);var oMh=_cvn();var oNh=function(oRh,oQh,oPh,gg){var oOh=_setAttrs(z,"view",["id",16,"bindtap",6,"class",7,"data-product",8],oRh,oQh,gg);var oTh=_ctn("view");_setAttr(z,oTh,'class',25,oRh,oQh,gg);var oUh=_setAttrs(z,"image",["class",26,"src",1],oRh,oQh,gg);_ac(oTh,oUh);_ac(oOh,oTh);var oVh=_ctn("view");_setAttr(z,oVh,'class',28,oRh,oQh,gg);var oWh=_ctn("view");_setAttr(z,oWh,'class',29,oRh,oQh,gg);var oXh=_o(z,17,oRh,oQh,gg);_ac(oWh,oXh);_ac(oVh,oWh);var oYh=_ctn("view");var oZh=_o(z,30,oRh,oQh,gg);_ac(oYh,oZh);_ac(oVh,oYh);var oah=_setAttrs(z,"svg",["height",2,"width",0,"viewBox",1,"xmlns",2],oRh,oQh,gg);var obh=_setAttrs(z,"g",["fill",31,"stroke",0,"fillRule",1,"id",2,"strokeWidth",3],oRh,oQh,gg);var och=_setAttrs(z,"g",["fill",6,"id",29],oRh,oQh,gg);var odh=_setAttrs(z,"path",["d",36,"id",1],oRh,oQh,gg);_ac(och,odh);_ac(obh,och);_ac(oah,obh);_ac(oVh,oah);_ac(oOh,oVh);_ac(oPh,oOh);return oPh;};_2(z,21,oNh,e,s,gg,oMh,"item","index",'{{id}}');_ac(oKh,oMh);_ac(oJh,oKh);}else{oJh.maVkey=2;var oeh=_ctn("view");_setAttr(z,oeh,'class',38,e,s,gg);var ogh=_ctn("view");var ohh=_o(z,39,e,s,gg);_ac(ogh,ohh);_ac(oeh,ogh);_ac(oJh,oeh);}_ac(osg,oJh);var oih=_ctn("view");_setAttr(z,oih,'class',40,e,s,gg);var ojh=_ctn("view");var okh=_o(z,41,e,s,gg);_ac(ojh,okh);_ac(oih,ojh);var olh=_cvn();var omh=function(oqh,oph,ooh,gg){var onh=_setAttrs(z,"view",["bindtap",44,"class",1,"id",2],oqh,oph,gg);var osh=_o(z,47,oqh,oph,gg);_ac(onh,osh);_ac(ooh,onh);return ooh;};_2(z,42,omh,e,s,gg,olh,"item","index",'{{index}}');_ac(oih,olh);var oth=_ctn("view");var ouh=_o(z,48,e,s,gg);_ac(oth,ouh);_ac(oih,oth);_ac(osg,oih);_ac(r,osg);
    return r;
  };
  e_["./pages/sub_pages/categories-view/categories-view.maml"]={f:m1,j:[],i:[],ti:[],ic:[]};

  d_["./pages/sub_pages/checkout/checkout.maml"]={};
  var m2=function(e,s,r,gg){
    var z=gz$gma_3()
    var owh=_ctn("view");_setAttr(z,owh,'class',0,e,s,gg);var oxh=_ctn("view");var oyh=_cvn();var ozh=function(oCi,oBi,oAi,gg){var o_h=_setAttrs(z,"view",["bindtap",3,"class",1,"id",2],oCi,oBi,gg);var oEi=_ctn("view");_setAttr(z,oEi,'class',6,oCi,oBi,gg);var oFi=_ctn("view");_setAttr(z,oFi,'class',7,oCi,oBi,gg);var oGi=_ctn("view");var oHi=_o(z,8,oCi,oBi,gg);_ac(oGi,oHi);_ac(oFi,oGi);var oIi=_ctn("view");_setAttr(z,oIi,'class',9,oCi,oBi,gg);var oJi=_o(z,10,oCi,oBi,gg);_ac(oIi,oJi);_ac(oFi,oIi);_ac(oEi,oFi);var oKi=_ctn("view");var oLi=_o(z,11,oCi,oBi,gg);_ac(oKi,oLi);_ac(oEi,oKi);_ac(o_h,oEi);_ac(oAi,o_h);return oAi;};_2(z,1,ozh,e,s,gg,oyh,"item","index",'{{id}}');_ac(oxh,oyh);var oMi=_ctn("view");_setAttr(z,oMi,'class',12,e,s,gg);var oNi=_ctn("view");_setAttr(z,oNi,'class',13,e,s,gg);var oOi=_ctn("view");_setAttr(z,oOi,'class',14,e,s,gg);var oPi=_o(z,15,e,s,gg);_ac(oOi,oPi);_ac(oNi,oOi);var oQi=_setAttrs(z,"input",["bindinput",16,"class",1,"placeholder",2,"type",3],e,s,gg);_ac(oNi,oQi);_ac(oMi,oNi);var oRi=_ctn("view");_setAttr(z,oRi,'class',20,e,s,gg);var oSi=_ctn("view");_setAttr(z,oSi,'class',14,e,s,gg);var oTi=_o(z,21,e,s,gg);_ac(oSi,oTi);_ac(oRi,oSi);var oUi=_setAttrs(z,"input",["class",17,"type",2,"bindinput",5,"placeholder",6],e,s,gg);_ac(oRi,oUi);_ac(oMi,oRi);_ac(oxh,oMi);_ac(owh,oxh);var oVi=_ctn("view");_setAttr(z,oVi,'class',24,e,s,gg);var oWi=_ctn("view");_setAttr(z,oWi,'class',25,e,s,gg);var oXi=_ctn("view");var oYi=_o(z,26,e,s,gg);_ac(oXi,oYi);_ac(oWi,oXi);var oZi=_ctn("view");var oai=_o(z,27,e,s,gg);_ac(oZi,oai);_ac(oWi,oZi);_ac(oVi,oWi);var obi=_setAttrs(z,"button",["bindtap",28,"class",1],e,s,gg);var oci=_o(z,30,e,s,gg);_ac(obi,oci);_ac(oVi,obi);_ac(owh,oVi);_ac(r,owh);
    return r;
  };
  e_["./pages/sub_pages/checkout/checkout.maml"]={f:m2,j:[],i:[],ti:[],ic:[]};

  d_["./pages/sub_pages/Notfication/notification-view.maml"]={};
  var m3=function(e,s,r,gg){
    var z=gz$gma_4()
    var oei=_ctn("view");_setAttr(z,oei,'class',0,e,s,gg);var ofi=_ctn("view");_setAttr(z,ofi,'class',1,e,s,gg);var ogi=_o(z,2,e,s,gg);_ac(ofi,ogi);_ac(oei,ofi);var ohi=_cvn();if(_o(z,3,e,s,gg)){ohi.maVkey=1;var oii=_ctn("view");_setAttr(z,oii,'class',0,e,s,gg);var oki=_cvn();var oli=function(opi,ooi,oni,gg){var omi=_ctn("view");_setAttr(z,omi,'class',6,opi,ooi,gg);var ori=_ctn("view");_setAttr(z,ori,'class',7,opi,ooi,gg);var osi=_o(z,8,opi,ooi,gg);_ac(ori,osi);_ac(omi,ori);var oti=_ctn("view");_setAttr(z,oti,'class',9,opi,ooi,gg);var oui=_o(z,10,opi,ooi,gg);_ac(oti,oui);_ac(omi,oti);_ac(oni,omi);return oni;};_2(z,4,oli,e,s,gg,oki,"item","index",'{{index}}');_ac(oii,oki);_ac(ohi,oii);}else{ohi.maVkey=2;var ovi=_ctn("view");_setAttr(z,ovi,'class',11,e,s,gg);var oxi=_ctn("view");var oyi=_o(z,12,e,s,gg);_ac(oxi,oyi);_ac(ovi,oxi);_ac(ohi,ovi);}_ac(oei,ohi);_ac(r,oei);
    return r;
  };
  e_["./pages/sub_pages/Notfication/notification-view.maml"]={f:m3,j:[],i:[],ti:[],ic:[]};

  d_["./pages/sub_pages/package-view/package-view.maml"]={};
  var m4=function(e,s,r,gg){
    var z=gz$gma_5()
    var o_i=_ctn("view");_setAttr(z,o_i,'class',0,e,s,gg);var oAj=_setAttrs(z,"image",["class",1,"src",1],e,s,gg);_ac(o_i,oAj);var oBj=_ctn("view");_setAttr(z,oBj,'class',3,e,s,gg);var oCj=_o(z,4,e,s,gg);_ac(oBj,oCj);_ac(o_i,oBj);var oDj=_ctn("view");_setAttr(z,oDj,'class',5,e,s,gg);var oEj=_ctn("view");_setAttr(z,oEj,'class',6,e,s,gg);var oFj=_o(z,7,e,s,gg);_ac(oEj,oFj);_ac(oDj,oEj);var oGj=_ctn("view");var oHj=_o(z,8,e,s,gg);_ac(oGj,oHj);_ac(oDj,oGj);_ac(o_i,oDj);var oIj=_ctn("view");_setAttr(z,oIj,'class',9,e,s,gg);var oJj=_setAttrs(z,"button",["bindtap",10,"class",1],e,s,gg);var oKj=_setAttrs(z,"svg",["height",12,"width",0,"viewBox",1,"xmlns",2],e,s,gg);var oLj=_setAttrs(z,"path",["d",15,"fill",1,"opacity",2],e,s,gg);_ac(oKj,oLj);var oMj=_setAttrs(z,"path",["fill",16,"d",2],e,s,gg);_ac(oKj,oMj);_ac(oJj,oKj);var oNj=_ctn("view");var oOj=_o(z,19,e,s,gg);_ac(oNj,oOj);_ac(oJj,oNj);_ac(oIj,oJj);var oPj=_ctn("button");var oQj=_setAttrs(z,"svg",["height",12,"width",0,"viewBox",1,"xmlns",2],e,s,gg);var oRj=_setAttrs(z,"path",["d",20,"fill",1],e,s,gg);_ac(oQj,oRj);_ac(oPj,oQj);_ac(oIj,oPj);_ac(o_i,oIj);var oSj=_ctn("view");_setAttr(z,oSj,'class',6,e,s,gg);var oTj=_o(z,22,e,s,gg);_ac(oSj,oTj);_ac(o_i,oSj);var oUj=_ctn("view");_setAttr(z,oUj,'class',23,e,s,gg);var oVj=_cvn();var oWj=function(oaj,oZj,oYj,gg){var oXj=_ctn("view");_setAttr(z,oXj,'class',26,oaj,oZj,gg);var ocj=_ctn("view");var odj=_o(z,27,oaj,oZj,gg);_ac(ocj,odj);_ac(oXj,ocj);var oej=_ctn("view");var ofj=_o(z,28,oaj,oZj,gg);_ac(oej,ofj);_ac(oXj,oej);_ac(oYj,oXj);return oYj;};_2(z,24,oWj,e,s,gg,oVj,"item","index",'{{id}}');_ac(oUj,oVj);_ac(o_i,oUj);_ac(r,o_i);
    return r;
  };
  e_["./pages/sub_pages/package-view/package-view.maml"]={f:m4,j:[],i:[],ti:[],ic:[]};

  d_["./pages/sub_pages/product-view/product-view.maml"]={};
  var m5=function(e,s,r,gg){
    var z=gz$gma_6()
    var ohj=_ctn("view");_setAttr(z,ohj,'class',0,e,s,gg);var oij=_setAttrs(z,"image",["class",1,"src",1],e,s,gg);_ac(ohj,oij);var ojj=_ctn("view");_setAttr(z,ojj,'class',3,e,s,gg);var okj=_o(z,4,e,s,gg);_ac(ojj,okj);_ac(ohj,ojj);var olj=_ctn("view");_setAttr(z,olj,'class',5,e,s,gg);var omj=_ctn("view");_setAttr(z,omj,'class',6,e,s,gg);var onj=_o(z,7,e,s,gg);_ac(omj,onj);_ac(olj,omj);var ooj=_ctn("view");var opj=_o(z,8,e,s,gg);_ac(ooj,opj);_ac(olj,ooj);_ac(ohj,olj);var oqj=_ctn("view");_setAttr(z,oqj,'class',9,e,s,gg);var orj=_setAttrs(z,"button",["bindtap",10,"class",1],e,s,gg);var osj=_setAttrs(z,"svg",["height",12,"width",0,"viewBox",1,"xmlns",2],e,s,gg);var otj=_setAttrs(z,"path",["d",15,"fill",1,"opacity",2],e,s,gg);_ac(osj,otj);var ouj=_setAttrs(z,"path",["fill",16,"d",2],e,s,gg);_ac(osj,ouj);_ac(orj,osj);var ovj=_ctn("view");var owj=_o(z,19,e,s,gg);_ac(ovj,owj);_ac(orj,ovj);_ac(oqj,orj);_ac(ohj,oqj);var oxj=_cvn();if(_o(z,20,e,s,gg)){oxj.maVkey=1;var oyj=_ctn("view");_setAttr(z,oyj,'class',6,e,s,gg);var o_j=_o(z,21,e,s,gg);_ac(oyj,o_j);_ac(oxj,oyj);} _ac(ohj,oxj);var oAk=_ctn("view");var oBk=_o(z,22,e,s,gg);_ac(oAk,oBk);_ac(ohj,oAk);_ac(r,ohj);
    return r;
  };
  e_["./pages/sub_pages/product-view/product-view.maml"]={f:m5,j:[],i:[],ti:[],ic:[]};

  d_["./pages/sub_pages/profile-view/profile-view.maml"]={};
  var m6=function(e,s,r,gg){
    var z=gz$gma_7()
    var oDk=_ctn("view");var oEk=_ctn("button");_setAttr(z,oEk,'id',0,e,s,gg);var oFk=_o(z,1,e,s,gg);_ac(oEk,oFk);_ac(oDk,oEk);_ac(r,oDk);var oGk=_cvn();var oHk=function(oLk,oKk,oJk,gg){var oIk=_ctn("view");var oNk=_setAttrs(z,"image",["bindtap",4,"src",1],oLk,oKk,gg);_ac(oIk,oNk);_ac(oJk,oIk);return oJk;};_2(z,2,oHk,e,s,gg,oGk,"item","index",'*this');_ac(r,oGk);var oOk=_ctn("view");_setAttr(z,oOk,'class',6,e,s,gg);var oPk=_setAttrs(z,"input",["bindinput",7,"class",1,"placeholder",2,"type",3],e,s,gg);_ac(oOk,oPk);var oQk=_setAttrs(z,"input",["bindinput",7,"class",1,"type",3,"placeholder",4],e,s,gg);_ac(oOk,oQk);var oRk=_setAttrs(z,"input",["bindinput",7,"class",1,"type",3,"placeholder",5],e,s,gg);_ac(oOk,oRk);var oSk=_setAttrs(z,"input",["bindinput",7,"class",1,"placeholder",6,"type",7],e,s,gg);_ac(oOk,oSk);var oTk=_setAttrs(z,"input",["bindinput",7,"class",1,"type",3,"placeholder",8],e,s,gg);_ac(oOk,oTk);var oUk=_setAttrs(z,"input",["bindinput",7,"class",1,"type",3,"placeholder",9],e,s,gg);_ac(oOk,oUk);var oVk=_setAttrs(z,"input",["bindinput",7,"class",1,"type",3,"placeholder",10],e,s,gg);_ac(oOk,oVk);var oWk=_setAttrs(z,"input",["bindinput",7,"class",1,"type",3,"placeholder",11],e,s,gg);_ac(oOk,oWk);var oXk=_setAttrs(z,"input",["bindinput",7,"class",1,"type",7,"placeholder",12],e,s,gg);_ac(oOk,oXk);_ac(r,oOk);var oYk=_ctn("button");_setAttr(z,oYk,'id',20,e,s,gg);var oZk=_o(z,21,e,s,gg);_ac(oYk,oZk);_ac(r,oYk);
    return r;
  };
  e_["./pages/sub_pages/profile-view/profile-view.maml"]={f:m6,j:[],i:[],ti:[],ic:[]};

  d_["./pages/tabBar/cart/index.maml"]={};
  var m7=function(e,s,r,gg){
    var z=gz$gma_8()
    var obk=_cvn();var ock=function(ogk,ofk,oek,gg){var odk=_ctn("view");_setAttr(z,odk,'class',2,ogk,ofk,gg);var oik=_ctn("image");_setAttr(z,oik,'src',3,ogk,ofk,gg);_ac(odk,oik);var ojk=_ctn("view");_setAttr(z,ojk,'class',4,ogk,ofk,gg);var okk=_ctn("view");_setAttr(z,okk,'class',5,ogk,ofk,gg);var olk=_o(z,6,ogk,ofk,gg);_ac(okk,olk);_ac(ojk,okk);var omk=_ctn("view");_setAttr(z,omk,'class',7,ogk,ofk,gg);var onk=_o(z,8,ogk,ofk,gg);_ac(omk,onk);var ook=_cvn();if(_o(z,9,ogk,ofk,gg)){ook.maVkey=1;var opk=_ctn("view");_setAttr(z,opk,'class',10,ogk,ofk,gg);var ork=_o(z,11,ogk,ofk,gg);_ac(opk,ork);_ac(ook,opk);} _ac(omk,ook);var osk=_ctn("view");_setAttr(z,osk,'class',12,ogk,ofk,gg);var otk=_o(z,13,ogk,ofk,gg);_ac(osk,otk);_ac(omk,osk);_ac(ojk,omk);var ouk=_ctn("view");_setAttr(z,ouk,'class',14,ogk,ofk,gg);var ovk=_ctn("view");_setAttr(z,ovk,'class',15,ogk,ofk,gg);var owk=_o(z,16,ogk,ofk,gg);_ac(ovk,owk);_ac(ouk,ovk);var oxk=_setAttrs(z,"button",["bindtap",17,"class",1,"id",2,"size",3],ogk,ofk,gg);var oyk=_o(z,21,ogk,ofk,gg);_ac(oxk,oyk);_ac(ouk,oxk);var ozk=_ctn("view");_setAttr(z,ozk,'class',22,ogk,ofk,gg);var o_k=_o(z,23,ogk,ofk,gg);_ac(ozk,o_k);_ac(ouk,ozk);var oAl=_setAttrs(z,"button",["id",19,"size",1,"bindtap",5,"class",6],ogk,ofk,gg);var oBl=_o(z,26,ogk,ofk,gg);_ac(oAl,oBl);_ac(ouk,oAl);_ac(ojk,ouk);_ac(odk,ojk);_ac(oek,odk);return oek;};_2(z,0,ock,e,s,gg,obk,"item","index",'{{id}}');_ac(r,obk);var oCl=_cvn();if(_o(z,27,e,s,gg)){oCl.maVkey=1;var oDl=_ctn("view");_setAttr(z,oDl,'class',28,e,s,gg);var oFl=_ctn("view");_setAttr(z,oFl,'class',29,e,s,gg);var oGl=_o(z,30,e,s,gg);_ac(oFl,oGl);_ac(oDl,oFl);var oHl=_ctn("view");_setAttr(z,oHl,'bindtap',31,e,s,gg);var oIl=_setAttrs(z,"button",["size",20,"class",12],e,s,gg);var oJl=_o(z,33,e,s,gg);_ac(oIl,oJl);_ac(oHl,oIl);_ac(oDl,oHl);_ac(oCl,oDl);} _ac(r,oCl);
    return r;
  };
  e_["./pages/tabBar/cart/index.maml"]={f:m7,j:[],i:[],ti:[],ic:[]};

  d_["./pages/tabBar/component/index.maml"]={};
  var m8=function(e,s,r,gg){
    var z=gz$gma_9()
    var oLl=_ctn("view");var oMl=_setAttrs(z,"input",["bindinput",0,"placeholder",1],e,s,gg);_ac(oLl,oMl);var oNl=_ctn("view");var oOl=_setAttrs(z,"swiper",["autoplay",2,"circular",0,"indicatorDots",0,"duration",1,"easingFunction",2,"indicatorActiveColor",3,"indicatorColor",4,"interval",5,"vertical",6],e,s,gg);var oPl=_cvn();var oQl=function(oUl,oTl,oSl,gg){var oWl=_ctn("swiper-item");var oXl=_ctn("view");_setAttr(z,oXl,'class',11,oUl,oTl,gg);var oYl=_setAttrs(z,"image",["class",12,"mode",1,"src",2],oUl,oTl,gg);_ac(oXl,oYl);_ac(oWl,oXl);_ac(oSl,oWl);return oSl;};_2(z,9,oQl,e,s,gg,oPl,"item","index",'*this');_ac(oOl,oPl);_ac(oNl,oOl);_ac(oLl,oNl);var oZl=_ctn("view");var oal=_ctn("view");var obl=_o(z,15,e,s,gg);_ac(oal,obl);_ac(oZl,oal);var ocl=_ctn("view");_setAttr(z,ocl,'class',16,e,s,gg);var odl=_cvn();var oel=function(oil,ohl,ogl,gg){var ofl=_setAttrs(z,"view",["bindtap",19,"class",1,"data-category",2,"id",3],oil,ohl,gg);var okl=_setAttrs(z,"image",["class",23,"src",1],oil,ohl,gg);_ac(ofl,okl);var oll=_ctn("view");var oml=_o(z,25,oil,ohl,gg);_ac(oll,oml);_ac(ofl,oll);_ac(ogl,ofl);return ogl;};_2(z,17,oel,e,s,gg,odl,"item","index",'{{id}}');_ac(ocl,odl);_ac(oZl,ocl);var onl=_ctn("view");var ool=_o(z,26,e,s,gg);_ac(onl,ool);_ac(oZl,onl);var opl=_ctn("view");_setAttr(z,opl,'class',27,e,s,gg);var oql=_cvn();var orl=function(ovl,oul,otl,gg){var osl=_setAttrs(z,"view",["class",20,"data-product",1,"id",2,"bindtap",9],ovl,oul,gg);var oxl=_setAttrs(z,"image",["class",30,"src",1],ovl,oul,gg);_ac(osl,oxl);var oyl=_ctn("view");_setAttr(z,oyl,'class',32,ovl,oul,gg);var ozl=_ctn("view");var o_l=_o(z,25,ovl,oul,gg);_ac(ozl,o_l);_ac(oyl,ozl);var oAm=_ctn("view");var oBm=_o(z,33,ovl,oul,gg);_ac(oAm,oBm);_ac(oyl,oAm);_ac(osl,oyl);_ac(otl,osl);return otl;};_2(z,28,orl,e,s,gg,oql,"item","index",'{{id}}');_ac(opl,oql);_ac(oZl,opl);var oCm=_ctn("view");var oDm=_o(z,34,e,s,gg);_ac(oCm,oDm);_ac(oZl,oCm);var oEm=_ctn("view");_setAttr(z,oEm,'class',27,e,s,gg);var oFm=_cvn();var oGm=function(oKm,oJm,oIm,gg){var oHm=_setAttrs(z,"view",["class",20,"data-package",1,"id",2,"bindtap",16],oKm,oJm,gg);var oMm=_setAttrs(z,"image",["src",24,"class",6],oKm,oJm,gg);_ac(oHm,oMm);var oNm=_ctn("view");_setAttr(z,oNm,'class',32,oKm,oJm,gg);var oOm=_ctn("view");var oPm=_o(z,25,oKm,oJm,gg);_ac(oOm,oPm);_ac(oNm,oOm);var oQm=_ctn("view");var oRm=_o(z,33,oKm,oJm,gg);_ac(oQm,oRm);_ac(oNm,oQm);_ac(oHm,oNm);_ac(oIm,oHm);return oIm;};_2(z,35,oGm,e,s,gg,oFm,"item","index",'{{id}}');_ac(oEm,oFm);var oSm=_setAttrs(z,"swiper",["circular",2,"duration",1,"easingFunction",2,"indicatorActiveColor",3,"indicatorColor",4,"interval",5,"autoplay",6,"indicatorDots",6,"vertical",6],e,s,gg);var oUm=_ctn("swiper-item");_ac(oSm,oUm);_ac(oEm,oSm);_ac(oZl,oEm);_ac(oLl,oZl);_ac(r,oLl);
    return r;
  };
  e_["./pages/tabBar/component/index.maml"]={f:m8,j:[],i:[],ti:[],ic:[]};

  d_["./pages/tabBar/menu/index.maml"]={};
  var m9=function(e,s,r,gg){
    var z=gz$gma_10()
    var oWm=_ctn("view");_setAttr(z,oWm,'class',0,e,s,gg);var oXm=_ctn("view");var oYm=_ctn("button");_setAttr(z,oYm,'id',1,e,s,gg);var oZm=_o(z,2,e,s,gg);_ac(oYm,oZm);_ac(oXm,oYm);_ac(oWm,oXm);var oam=_ctn("view");_ac(oWm,oam);var obm=_ctn("view");_setAttr(z,obm,'class',3,e,s,gg);var ocm=_ctn("view");var odm=_setAttrs(z,"button",["bindtap",4,"class",1,"data-cat",2],e,s,gg);var oem=_o(z,7,e,s,gg);_ac(odm,oem);_ac(ocm,odm);_ac(obm,ocm);var ofm=_ctn("view");var ogm=_setAttrs(z,"button",["class",5,"data-cat",1,"bindtap",3],e,s,gg);var ohm=_o(z,9,e,s,gg);_ac(ogm,ohm);_ac(ofm,ogm);_ac(obm,ofm);_ac(oWm,obm);var oim=_ctn("footer");var ojm=_o(z,10,e,s,gg);_ac(oim,ojm);var okm=_ctn("text");_setAttr(z,okm,'space',11,e,s,gg);var olm=_o(z,12,e,s,gg);_ac(okm,olm);_ac(oim,okm);_ac(oWm,oim);_ac(r,oWm);
    return r;
  };
  e_["./pages/tabBar/menu/index.maml"]={f:m9,j:[],i:[],ti:[],ic:[]};

  d_["./pages/tabBar/orders/index.maml"]={};
  var m10=function(e,s,r,gg){
    var z=gz$gma_11()
    var onm=_cvn();var oom=function(osm,orm,oqm,gg){var opm=_ctn("view");_setAttr(z,opm,'class',2,osm,orm,gg);var oum=_ctn("image");_setAttr(z,oum,'src',3,osm,orm,gg);_ac(opm,oum);var ovm=_ctn("view");_setAttr(z,ovm,'class',4,osm,orm,gg);var owm=_ctn("view");_setAttr(z,owm,'class',5,osm,orm,gg);var oxm=_o(z,6,osm,orm,gg);_ac(owm,oxm);_ac(ovm,owm);var oym=_ctn("view");_setAttr(z,oym,'class',7,osm,orm,gg);var ozm=_ctn("view");_setAttr(z,ozm,'class',8,osm,orm,gg);var o_m=_o(z,9,osm,orm,gg);_ac(ozm,o_m);_ac(oym,ozm);var oAn=_ctn("view");var oBn=_o(z,10,osm,orm,gg);_ac(oAn,oBn);_ac(oym,oAn);_ac(ovm,oym);var oCn=_ctn("view");_setAttr(z,oCn,'class',11,osm,orm,gg);var oDn=_o(z,12,osm,orm,gg);_ac(oCn,oDn);_ac(ovm,oCn);_ac(opm,ovm);_ac(oqm,opm);return oqm;};_2(z,0,oom,e,s,gg,onm,"item","index",'{{id}}');_ac(r,onm);
    return r;
  };
  e_["./pages/tabBar/orders/index.maml"]={f:m10,j:[],i:[],ti:[],ic:[]};

  if(path&&e_[path]){
    return function(env,dd,global){
      $gmac=0;
      var root={"tag":"ma-page","children":[]};
      var main=e_[path].f;
      if(typeof global==="undefined")global={};
      global.f=$gdc(f_[path],"",1)||{};
      global.f.i18n=f_['i18n']
      if(window.__mergeData__)env=window.__mergeData__(env,dd);
      try{
        main(env,{},root,global);
      }catch(e){
        console.log(e)
      }
      return root;
    }
  }
}

__maAppCode__['app.json']={"pages":["pages/tabBar/component/index","pages/tabBar/cart/index","pages/tabBar/orders/index","pages/tabBar/menu/index","pages/sub_pages/product-view/product-view","pages/sub_pages/categories-view/categories-view","pages/sub_pages/package-view/package-view","pages/sub_pages/checkout/checkout","pages/sub_pages/Notfication/notification-view","pages/sub_pages/profile-view/profile-view"],"window":{"backgroundTextStyle":"light","navigationBarBackgroundColor":"#AE7F2D","navigationBarTitleText":"Macle","navigationBarTextStyle":"black","capsuleTheme":"light"},"tabBar":{"color":"#1E1E1E","selectedColor":"#B37D2B","borderStyle":"black","backgroundColor":"#000000","list":[{"pagePath":"pages/tabBar/component/index","iconPath":"images/home-1.png","selectedIconPath":"images/home.png","text":"Home"},{"pagePath":"pages/tabBar/cart/index","iconPath":"images/cart-1.png","selectedIconPath":"images/cart.png","text":"Cart"},{"pagePath":"pages/tabBar/orders/index","iconPath":"images/delivery.png","selectedIconPath":"images/delivery-1.png","text":"Delivery"},{"pagePath":"pages/tabBar/menu/index","iconPath":"images/menu-1.png","selectedIconPath":"images/menu.png","text":"Menu"}]},"style":"v2","sitemapLocation":"sitemap.json","entryPagePath":"pages/tabBar/component/index"};
__maAppCode__['components/product-card/product-card.json']={"component":true,"usingComponents":{}};
__maAppCode__['components/product-card/product-card.maml']=$gma('./components/product-card/product-card.maml');
__maAppCode__['pages/sub_pages/categories-view/categories-view.json']={"navigationBarTitleText":"","usingComponents":{"product-card":"components/product-card/product-card"}};
__maAppCode__['pages/sub_pages/categories-view/categories-view.maml']=$gma('./pages/sub_pages/categories-view/categories-view.maml');
__maAppCode__['pages/sub_pages/checkout/checkout.json']={"navigationBarTitleText":"Seregela Gebeya","usingComponents":{}};
__maAppCode__['pages/sub_pages/checkout/checkout.maml']=$gma('./pages/sub_pages/checkout/checkout.maml');
__maAppCode__['pages/sub_pages/Notfication/notification-view.json']={"navigationBarTitleText":"Seregela Gebeya menu"};
__maAppCode__['pages/sub_pages/Notfication/notification-view.maml']=$gma('./pages/sub_pages/Notfication/notification-view.maml');
__maAppCode__['pages/sub_pages/package-view/package-view.json']={"navigationBarTitleText":"Seregela Gebeya","usingComponents":{}};
__maAppCode__['pages/sub_pages/package-view/package-view.maml']=$gma('./pages/sub_pages/package-view/package-view.maml');
__maAppCode__['pages/sub_pages/product-view/product-view.json']={"navigationBarTitleText":"Seregela Gebeya","usingComponents":{}};
__maAppCode__['pages/sub_pages/product-view/product-view.maml']=$gma('./pages/sub_pages/product-view/product-view.maml');
__maAppCode__['pages/sub_pages/profile-view/profile-view.json']={"navigationBarTitleText":"Seregela Gebeya profile"};
__maAppCode__['pages/sub_pages/profile-view/profile-view.maml']=$gma('./pages/sub_pages/profile-view/profile-view.maml');
__maAppCode__['pages/tabBar/cart/index.json']={"navigationBarTitleText":"Cart"};
__maAppCode__['pages/tabBar/cart/index.maml']=$gma('./pages/tabBar/cart/index.maml');
__maAppCode__['pages/tabBar/component/index.json']={"navigationBarTitleText":"Seregela Gebeya","usingComponents":{"product-cart":"components/product-card/product-card"}};
__maAppCode__['pages/tabBar/component/index.maml']=$gma('./pages/tabBar/component/index.maml');
__maAppCode__['pages/tabBar/menu/index.json']={"navigationBarTitleText":"Seregela Gebeya menu"};
__maAppCode__['pages/tabBar/menu/index.maml']=$gma('./pages/tabBar/menu/index.maml');
__maAppCode__['pages/tabBar/orders/index.json']={"navigationBarTitleText":"Seregela Gebeya orders"};
__maAppCode__['pages/tabBar/orders/index.maml']=$gma('./pages/tabBar/orders/index.maml');

define("app.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
initI18n({defaultLocale:"am"});const e=getI18nInstance();App({onLaunch(){window.ma.getMiniAppToken({appId:" ca50ac72-d212-4c18-9f92-6a43b0aa1771",success:e=>{ma.request({url:"https://seregelagebeya.com/api/v1/customer/telebirr-login",data:e.token,get:"POST",header:{"content-type":"application/json"},success(e){ma.setStorage({key:"user",data:JSON.stringify(e.data.data),success(e){},fail(e){}}),ma.setStorage({key:"token",data:e.data.access_token,success(e){},fail(e){}})},fail(e){}})},fail(e){}}),ma.getSystemInfo({success:a=>{e.setLocale(a.language),ma.setTabBarItem({index:0,text:e.t("home")}),ma.setTabBarItem({index:0,text:e.t("cart")}),ma.setTabBarItem({index:0,text:e.t("delivery")}),ma.setTabBarItem({index:0,text:e.t("menu")})}})},onShow(){ma.setTabBarStyle({backgroundColor:"#000000",borderStyle:"black",success(e){},fail(e){},complete(){}})}});
});
define("components/product-card/product-card.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
Component({behaviors:[],properties:{product:Object,imageFlag:String},data:{quantity:1},created(){},attached(){},ready(){},detached(){},methods:{addToCart:function(t){}}});
});
define("pages/sub_pages/categories-view/categories-view.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
Page({data:{searchInput:"",categoryId:"",baseUrl:"https://seregelagebeya.com/api/v1/customer/",categories:[],products:[],nextPageURL:"",previousPageURL:"",pages:0,currentPage:0,leftSign:"<<",subcategoriesId:0,nextPageURL:"",previousPageURL:"",pages:0},onLoad(e){ma.getStorage({key:"categoryID",success(e){this.setData({categoryId:e.data}),this.getCategoryProducts(e.data)}})},onReady(){},onShow(){},onHide(){},onUnload(){},onShareAppMessage:()=>({title:""}),bindSearchInput:function(e){this.setData({searchInput:e.detail.value})},changePage:function(e){let t=this.data.baseUrl,a=e.currentTarget.id;ma.request({url:`${t}categories/${this.data.categoryId}/products?page=${a}`,timeout:5e3,header:{"content-type":"application/json"},method:"GET",success:function(e){this.setData({products:e.data.data,nextPageURL:e.data.links.next,previousPageURL:e.data.links.prev,pages:e.data.meta.last_page,currentPage:e.data.meta.current_page})}})},getSubcategoriesProducts:function(e){let t=e.currentTarget.id,a=this.data.baseUrl;ma.request({url:`${a}subcategories/${t}/products`,timeout:5e3,header:{"content-type":"application/json"},method:"GET",success(e){this.setData({subcategoriesId:t,products:e.data.data,nextPageURL:e.data.links.next,previousPageURL:e.data.links.prev,pages:e.data.meta.last_page,currentPage:e.data.meta.current_page})}})},getCategory:function(e){let t=this.data.baseUrl;ma.request({url:`${t}categories/${e}`,timeout:5e3,header:{"content-type":"application/json"},method:"GET",success:function(e){this.setData({categories:e.data.data.subcategories})}})},getCategoryProducts:function(e){let t=this.data.baseUrl;ma.request({url:`${t}categories/${e}/products`,timeout:5e3,header:{"content-type":"application/json"},method:"GET",success:function(t){this.setData({products:t.data.data,nextPageURL:t.data.links.next,previousPageURL:t.data.links.prev,pages:t.data.meta.last_page,currentPage:t.data.meta.current_page}),this.getCategory(e)}})},openProduct:function(e){let t=e.currentTarget.dataset.product;var a={};a.id=t.id,a.quantity=1,a.name=t.name,a.price=t.price,a.discount=t.discount,a.imageurl=t.image_paths[0],a.originalPrice=parseFloat(t.price)+parseFloat(t.discount),ma.setStorage({key:"product",data:JSON.stringify(a),success(e){ma.navigateTo({url:"/pages/sub_pages/product-view/product-view",events:{acceptDataFromOpenedPage:function(e){}},success(e){e.eventChannel.emit("acceptDataFromOpenerPage",{data:"example3"})}})}})}});
});
define("pages/sub_pages/checkout/checkout.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
Page({data:{baseUrl:"https://seregelagebeya.com/api/v1/customer/",deliveryTypes:[],neighborhood:null,phone_number:null,homeNumber:"",long:null,lat:null,choosedDeliveryId:null,choosenDeliveryClass:"",token:"",cart:[],totalPrice:0},onLoad(e){this.loadDeliveryTypes(),ma.getLocation({success(e){this.setData({lat:e.latitude,long:e.longitude})},fail(e){}}),ma.getStorage({key:"user",success(e){let t=JSON.parse(e.data);this.setData({phone_number:t.phone_number})}}),ma.getStorage({key:"totalPrice",success(e){this.setData({totalPrice:e.data})}}),ma.getStorage({key:"token",success(e){this.setData({token:e.data})}})},onReady(){ma.getStorage({key:"cart",success(e){this.setData({cart:JSON.parse(e.data)})}})},onShow(){},onHide(){},onUnload(){},loadDeliveryTypes:function(){let e=this.data.baseUrl;ma.request({url:`${e}delivery-types`,method:"GET",timeout:5e3,header:{"content-type":"application/json"},success(e){this.setData({deliveryTypes:e.data.data})}})},chooseDeliveryType:function(e){this.setData({choosedDeliveryId:e.currentTarget.id,choosenDeliveryClass:"deliveryTypes-active"})},addNeighborhood:function(e){this.setData({neighborhood:e.detail.value})},makeOrder:function(){if(null!=this.data.neighborhood&&null!=this.data.long&&null!=this.data.lat&&null!=this.data.choosedDeliveryId){var e={};e.delivery_type_id=this.data.choosedDeliveryId,e.payment_method="telebirr-super-app",e.shipping_detail={longitude:this.data.long,latitude:this.data.lat,neighborhood:this.data.neighborhood,phone_number:this.data.phone_number},e.packages=[],e.products=[],this.data.cart.map((t=>{"isPackage"in t?e.packages.push({id:t.id,quantity:t.quantity}):e.products.push({id:t.id,quantity:t.quantity})})),this.payOrder(e)}},payOrder:function(e){let t=this.data.baseUrl;ma.request({url:`${t}orders`,data:{delivery_type_id:e.delivery_type_id,payment_method:e.payment_method,shipping_detail:{longitude:e.shipping_detail.longitude,latitude:e.shipping_detail.latitude,neighborhood:e.shipping_detail.neighborhood,phone_number:e.shipping_detail.phone_number},products:e.products,packages:e.packages},method:"POST",timeout:5e3,header:{"content-type":"application/json",Authorization:`Bearer ${this.data.token}`},success(e){ma.startpay({rawRequest:e.data.data.invoice.telebirr_super_pay_order_request})},fail(e){}})},onShareAppMessage:()=>({title:""})});
});
define("pages/sub_pages/Notfication/notification-view.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
Page({data:{notifications:[]},onLoad(){ma.getStorage({key:"token",success(t){this.getNotifications(t.data)},fail(t){}})},getNotifications:function(t){ma.request({url:"https://seregelagebeya.com/api/v1/customer/notifications",timeout:5e3,header:{"content-type":"application/json",Authorization:`Bearer ${t}`},method:"GET",success(t){this.setData({notifications:t.data.data})},fail(t){}})}});
});
define("pages/sub_pages/package-view/package-view.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
Page({data:{package:{},baseURL:"https://seregelagebeya.com/api/v1/customer/"},onLoad(a){ma.getStorage({key:"packageID",success(a){this.getPackage(a.data)}})},onReady(){},onShow(){},onHide(){},onUnload(){},addCart:function(){var a=[],t={};t.id=this.data.package.id,t.name=this.data.package.name,t.price=this.data.package.price,t.discount=this.data.package.discount,t.imageurl=this.data.package.image_paths[0],t.originalPrice=parseFloat(this.data.package.price)+parseFloat(this.data.package.discount),t.quantity=1,t.isPackage=!0,ma.getStorage({key:"cart",success(e){(a=JSON.parse(e.data)).map((a=>{a.name==t.name&&a.id.toString()==t.id.toString()&&(t.quantity=a.quantity+1,this.setData({package:this.data.package}))})),(a=a.filter((a=>a.id.toString()!=t.id.toString()))).push(t),this.setCart(a),this.updateTotalPrice(a)},fail(e){a.push(t),this.setCart(a),this.updateTotalPrice(a)}})},setCart:function(a){ma.setStorage({key:"cart",data:JSON.stringify(a),success(a){ma.showToast({title:`${this.data.package.name} added to cart`,duration:1500,success(a){ma.navigateBack({delta:1,complete:a=>{}})}})},fail(a){}})},updateTotalPrice:function(a){let t=0;a.map((a=>{t+=parseFloat(a.price)*parseInt(a.quantity)})),ma.setStorage({key:"totalPrice",data:JSON.stringify(t),success(a){},fail(a){}})},getPackage:function(a){let t=this.data.baseURL;ma.request({url:`${t}packages/${a}`,method:"GET",timeout:7e3,header:{"content-type":"application/json"},success(a){this.setData({package:a.data.data})},fail(a){}})},onShareAppMessage:()=>({title:""})});
});
define("pages/sub_pages/product-view/product-view.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
Page({data:{product:{}},onLoad:function(t){ma.getStorage({key:"product",success(t){this.setData({product:JSON.parse(t.data)})}})},onReady(){},onShow(){},onHide(){},onUnload(){ma.getStorage({key:"product",success(t){this.setData({product:JSON.parse(t.data)})}})},addCart:function(){var t=[];ma.getStorage({key:"cart",success(a){(t=JSON.parse(a.data)).map((t=>{t.id.toString()==this.data.product.id.toString()&&(this.data.product.quantity=t.quantity+1,this.setData({product:this.data.product}))})),(t=t.filter((t=>t.id.toString()!=this.data.product.id.toString()))).push(this.data.product),this.setCart(t),this.updateTotalPrice(t)},fail(a){t.push(this.data.product),this.setCart(t),this.updateTotalPrice(t)}})},setCart:function(t){ma.setStorage({key:"cart",data:JSON.stringify(t),success(t){ma.showToast({title:`${this.data.product.name} added to cart`,duration:1500,success(t){ma.navigateBack({delta:1,complete:t=>{}})}})},fail(t){}})},updateTotalPrice:function(t){let a=0;t.map((t=>{a+=parseFloat(t.price)*parseInt(t.quantity)})),ma.setStorage({key:"totalPrice",data:JSON.stringify(a),success(t){},fail(t){}})},onShareAppMessage:()=>({title:""})});
});
define("pages/sub_pages/profile-view/profile-view.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
Page({data:{background:["profile"],ProfileInfo:[],categoryId:"",baseUrl:"https://seregelagebeya.com/api/v1/customer/",categories:[],products:[],nextPageURL:"",previousPageURL:"",pages:0,filePath:"",imageList:[],info:""},bindSearchInput:function(e){this.setData({ProfileInfo:e.detail.value})},chooseImage:function(){const e=this;ma.chooseImage({success(t){e.setData({imageList:t.tempFilePaths,info:this.format(t.tempFilePaths)})},fail:e=>{this.setData({info:this.format(e)})}})},format:e=>"{\n"+Object.keys(e).map((function(t){return"  "+t+": "+e[t]+","})).join("\n")+"\n}"});
});
define("pages/tabBar/cart/index.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
Page({onLoad(){ma.getStorage({key:"cart",success(t){this.setData({cart:JSON.parse(t.data)})}}),ma.getStorage({key:"totalPrice",success(t){this.setData({totalPrice:JSON.parse(t.data)})}})},onReady(){ma.getStorage({key:"cart",success(t){this.setData({cart:JSON.parse(t.data)})}}),ma.getStorage({key:"totalPrice",success(t){this.setData({totalPrice:JSON.parse(t.data)})}})},onShow(){ma.getStorage({key:"cart",success(t){this.setData({cart:JSON.parse(t.data)})}}),ma.getStorage({key:"totalPrice",success(t){this.setData({totalPrice:JSON.parse(t.data)})}})},onHide(){this.updateCart(this.data.cart),this.updateTotalPrice(this.data.totalPrice)},data:{totalPrice:0,cart:[]},incrementQuantity:function(t){this.data.cart.map((a=>{a.id.toString()===t.target.id&&(a.quantity=parseInt(a.quantity)+1,this.data.totalPrice+=parseFloat(a.price))})),this.setData({totalPrice:this.data.totalPrice,cart:this.data.cart}),this.updateCart(this.data.cart),this.updateTotalPrice(this.data.totalPrice)},decrementQuantity:function(t){this.data.cart.map((a=>{a.id.toString()===t.target.id&&(a.quantity=parseInt(a.quantity)-1,this.data.totalPrice-=parseFloat(a.price),0===a.quantity&&this.removeZeroQuantityFromCart())})),this.setData({totalPrice:this.data.totalPrice,cart:this.data.cart}),this.updateCart(this.data.cart),this.updateTotalPrice(this.data.totalPrice)},removeZeroQuantityFromCart:function(){var t=this.data.cart.filter((t=>0!==t.quantity));this.setData({cart:t})},checkout:function(){ma.navigateTo({url:"/pages/sub_pages/checkout/checkout"})},updateTotalPrice:function(t){ma.setStorage({key:"totalPrice",data:JSON.stringify(t),success(t){},fail(t){}})},updateCart(t){ma.setStorage({key:"cart",data:JSON.stringify(t),success(t){},fail(t){}})},getCartValueFromStorage(){ma.getStorage({key:"cart",success:t=>JSON.parse(t.data),fail(t){}})}});
});
define("pages/tabBar/component/index.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
Page({data:{background:["carousel_image_1","carousel_image_2","carousel_image_3"],searchInput:"",baseUrl:"https://seregelagebeya.com/api/v1/customer/",categories:[],popularProducts:[],packages:[]},bindSearchInput:function(e){this.setData({searchInput:e.detail.value})},onLoad(){ma.getStorage({key:"categories",success(e){this.setData({categories:JSON.parse(e.data)})},fail(e){this.getCategories()}}),this.getPopularProducts(),this.getPackages()},getCategories:function(){var e=this;let a=e.data.baseUrl;ma.request({url:a+"categories",timeout:7e3,header:{"content-type":"application/json"},method:"GET",success:function(a){let t=a.data;e.setData({categories:t.data}),ma.setStorage({key:"categories",data:JSON.stringify(t.data),success(e){},fail(e){}})},fail:function(e){}})},getPopularProducts:function(){var e=this;let a=e.data.baseUrl;ma.request({url:a+"popular-products",timeout:7e3,header:{"content-type":"application/json"},method:"GET",success:function(a){e.setData({popularProducts:a.data.data})},fail:function(e){}})},getPackages:function(){var e=this;let a=e.data.baseUrl;ma.request({url:a+"packages",timeout:7e3,header:{"content-type":"application/json"},method:"GET",success:function(a){e.setData({packages:a.data.data})},fail:function(e){}})},openCategory:function(e){ma.setStorage({data:e.currentTarget.id,key:"categoryID",success(e){ma.navigateTo({url:"/pages/sub_pages/categories-view/categories-view"})}})},openProduct:function(e){let a=e.currentTarget.dataset.product;var t={};t.id=a.id,t.quantity=1,t.name=a.name,t.price=a.price,t.discount=a.discount,t.imageurl=a.image_paths[0],t.originalPrice=parseFloat(a.price)+parseFloat(a.discount),ma.setStorage({key:"product",data:JSON.stringify(t),success(e){ma.navigateTo({url:"/pages/sub_pages/product-view/product-view",events:{acceptDataFromOpenedPage:function(e){}},success(e){e.eventChannel.emit("acceptDataFromOpenerPage",{data:"example3"})}})},fail(e){}})},openPackage:function(e){ma.setStorage({key:"packageID",data:e.currentTarget.id,success(e){ma.navigateTo({url:"/pages/sub_pages/package-view/package-view",events:{acceptDataFromOpened:function(e){}},success(e){e.eventChannel.emit("acceptDataFromOpenerPage",{data:"example3"})}})},fail(e){}})}});
});
define("pages/tabBar/menu/index.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
Page({data:{background:["profile"],searchInput:"",baseUrl:"https://seregelagebeya.com/api/v1/customer/",categories:[],popularProducts:[],packages:[],tempFilePath:"",imageList:[],info:"",filePath:""},openProfile:function(e){ma.setStorage({data:e.currentTarget.id,key:"ProfileID",success(e){ma.navigateTo({url:"/pages/sub_pages/profile-view/profile-view"})}})},openNotification:function(e){ma.setStorage({data:e.currentTarget.id,key:"NotificationID",success(e){ma.navigateTo({url:"/pages/sub_pages/Notfication/notification-view"})}})}});
});
define("pages/tabBar/orders/index.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
Page({data:{baseUrl:"https://seregelagebeya.com/api/v1/customer/",orders:[],token:""},onLoad(){ma.getStorage({key:"token",success(e){this.getOrders(e.data)}})},onReady(){},getOrders:function(e){ma.showLoading({title:"loading",mask:!0}),ma.request({url:`${this.data.baseUrl}/orders?all`,timeout:7e3,header:{"content-type":"application/json",Authorization:`Bearer ${e}`},method:"GET",success(e){this.setData({orders:e.data.data}),setTimeout((function(){ma.hideLoading()}),1e3)},fail(e){}})}});
});
__maRoute='app';require("app.js");
__maRoute='components/product-card/product-card';require("components/product-card/product-card.js");
__maRoute='pages/sub_pages/categories-view/categories-view';require("pages/sub_pages/categories-view/categories-view.js");
__maRoute='pages/sub_pages/checkout/checkout';require("pages/sub_pages/checkout/checkout.js");
__maRoute='pages/sub_pages/Notfication/notification-view';require("pages/sub_pages/Notfication/notification-view.js");
__maRoute='pages/sub_pages/package-view/package-view';require("pages/sub_pages/package-view/package-view.js");
__maRoute='pages/sub_pages/product-view/product-view';require("pages/sub_pages/product-view/product-view.js");
__maRoute='pages/sub_pages/profile-view/profile-view';require("pages/sub_pages/profile-view/profile-view.js");
__maRoute='pages/tabBar/cart/index';require("pages/tabBar/cart/index.js");
__maRoute='pages/tabBar/component/index';require("pages/tabBar/component/index.js");
__maRoute='pages/tabBar/menu/index';require("pages/tabBar/menu/index.js");
__maRoute='pages/tabBar/orders/index';require("pages/tabBar/orders/index.js");
